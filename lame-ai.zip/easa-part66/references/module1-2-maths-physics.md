# Module 1 & 2 — Mathematics & Physics (B1/B2)
## Sources: EASA Part-66 Syllabus, FAA AMT Handbook General

---

# MODULE 1 — MATHEMATICS

## 1.1 Arithmetic

### Number Systems
- Integer, rational, irrational, real numbers
- **Order of operations**: BODMAS/PEMDAS — Brackets, Orders, Division, Multiplication, Addition, Subtraction
- Fractions: add/subtract = common denominator; multiply = top×top / bottom×bottom; divide = multiply by reciprocal
- Percentages: x% of y = (x/100) × y
- Ratios and proportions: a:b = c:d → a×d = b×c (cross multiply)

### Powers and Roots
- aⁿ × aᵐ = aⁿ⁺ᵐ
- aⁿ / aᵐ = aⁿ⁻ᵐ
- (aⁿ)ᵐ = aⁿˣᵐ
- a⁰ = 1 (any number to power zero = 1)
- a⁻ⁿ = 1/aⁿ
- √a = a^(1/2); ∛a = a^(1/3)
- Scientific notation: 3.5 × 10⁴ = 35,000

### Logarithms
- log₁₀(x) = common logarithm
- ln(x) = natural logarithm (base e = 2.718)
- log(a×b) = log a + log b
- log(a/b) = log a − log b
- log(aⁿ) = n × log a
- **dB (decibels)**: dB = 20 log(V₂/V₁) for voltage; dB = 10 log(P₂/P₁) for power
  - 3 dB = double/half power; 6 dB = double/half voltage
  - 20 dB = ×10 voltage; −20 dB = ÷10

---

## 1.2 Algebra

### Basic Operations
- Solving linear equations: isolate variable (same operation both sides)
- Simultaneous equations: substitution or elimination method
- **Quadratic**: ax² + bx + c = 0 → x = (−b ± √(b²−4ac)) / 2a

### Transposition of Formulae
- **V = IR** → I = V/R → R = V/I
- **P = I²R** → I = √(P/R) → R = P/I²
- **C = Q/V** → Q = C×V → V = Q/C
- Practice: always write steps, one operation at a time

### Number Bases (Module 5 link)
- Binary → Decimal: sum of (bit × 2^position)
  - 1011₂ = 1×8 + 0×4 + 1×2 + 1×1 = 11₁₀
- Decimal → Binary: repeated division by 2, remainders read upward
- Hex → Binary: each hex digit = 4 binary bits
  - A=1010, B=1011, C=1100, D=1101, E=1110, F=1111

---

## 1.3 Geometry and Trigonometry

### Areas and Volumes
| Shape | Area | Volume |
|-------|------|--------|
| Rectangle | l × w | — |
| Triangle | ½ × b × h | — |
| Circle | π × r² | — |
| Cylinder | 2πr² + 2πrh | π × r² × h |
| Sphere | 4πr² | (4/3)πr³ |

π = 3.14159...

### Trigonometry
In a right-angled triangle:
- **sin θ = opposite/hypotenuse** (SOH)
- **cos θ = adjacent/hypotenuse** (CAH)
- **tan θ = opposite/adjacent** (TOA)

Memory: **SOH CAH TOA**

Key values:
| Angle | sin | cos | tan |
|-------|-----|-----|-----|
| 0° | 0 | 1 | 0 |
| 30° | 0.5 | 0.866 | 0.577 |
| 45° | 0.707 | 0.707 | 1 |
| 60° | 0.866 | 0.5 | 1.732 |
| 90° | 1 | 0 | ∞ |

**Pythagoras**: a² + b² = c² (c = hypotenuse)

### Graphs
- Straight line: y = mx + c (m = slope, c = y-intercept)
- Slope = rise/run = Δy/Δx
- Exponential: y = eˣ (growth); y = e⁻ˣ (decay) — RC/RL circuits

---

## Key Exam Traps — Module 1
1. **BODMAS**: multiplication before addition — 2 + 3 × 4 = 14 (not 20)
2. **a⁰ = 1** always, including 0⁰ (in engineering context)
3. **dB power**: 3 dB = ×2 power; **voltage**: 6 dB = ×2 voltage
4. **Quadratic**: memorise formula, used in filter/resonance calculations
5. **sin 45° = cos 45° = 0.707** — appears in AC phasor calculations (RMS = 0.707 × peak)

---

# MODULE 2 — PHYSICS

## 2.1 Matter

### States of Matter
- **Solid**: fixed shape, fixed volume — strong intermolecular forces
- **Liquid**: fixed volume, no fixed shape — weaker forces
- **Gas**: no fixed shape, no fixed volume — very weak forces
- **Plasma**: ionised gas — not tested at Part-66 level

### Properties
- **Density**: ρ = m/V (kg/m³) — water = 1000 kg/m³; aluminium ≈ 2700; steel ≈ 7800
- **Relative density (SG)**: density compared to water — pure water SG = 1.0
- **Viscosity**: resistance to flow — oil has high viscosity; water low
  - Dynamic viscosity: absolute measure (Pa·s)
  - Kinematic viscosity: dynamic/density (m²/s) — used for hydraulic fluids

---

## 2.2 Statics and Dynamics

### Newton's Laws
1. **Inertia**: body remains at rest or uniform motion unless acted on by force
2. **F = ma**: force = mass × acceleration (N = kg × m/s²)
3. **Action-Reaction**: equal and opposite forces

### Work, Energy, Power
- **Work**: W = F × d × cos θ (Joules)
- **Kinetic Energy**: KE = ½mv²
- **Potential Energy**: PE = mgh
- **Power**: P = W/t = F×v (Watts)
- **Efficiency**: η = (output/input) × 100%

### Friction
- **Static friction** > kinetic friction
- F_friction = μ × N (μ = coefficient of friction, N = normal force)

### Moments and Torque
- **Moment = Force × perpendicular distance** (N·m)
- Equilibrium: sum of clockwise moments = sum of anticlockwise moments
- **Torque**: rotational equivalent of force

### Simple Machines (Mechanical Advantage)
- Lever: MA = effort arm / load arm
- Pulley: MA = number of supporting ropes
- Inclined plane: MA = length / height
- Gear ratio: output teeth / input teeth

---

## 2.3 Fluid Dynamics

### Pressure
- **Pressure = Force / Area** (Pa = N/m²)
- **Atmospheric pressure**: 101,325 Pa = 1013.25 hPa = 14.7 psi at sea level
- **Gauge pressure**: above atmospheric (tyre pressure)
- **Absolute pressure**: gauge + atmospheric

### Bernoulli's Principle
- Along a streamline: P + ½ρV² + ρgh = constant
- Faster flow = lower static pressure (wing lift principle)
- Venturi: constriction → speed increases → pressure decreases

### Pascal's Law
- Pressure applied to enclosed fluid transmits equally in all directions
- **Hydraulic leverage**: F₁/A₁ = F₂/A₂ → F₂ = F₁ × (A₂/A₁)
- Foundation of all aircraft hydraulic systems

---

## 2.4 Thermodynamics

### Temperature Scales
- °C to °F: F = (C × 9/5) + 32
- °F to °C: C = (F − 32) × 5/9
- °C to K: K = C + 273.15
- Absolute zero: −273.15°C = 0 K

### Gas Laws
- **Boyle's Law**: P₁V₁ = P₂V₂ (constant temperature) — pressure ↑, volume ↓
- **Charles' Law**: V₁/T₁ = V₂/T₂ (constant pressure) — temperature ↑, volume ↑
- **Gay-Lussac's Law**: P₁/T₁ = P₂/T₂ (constant volume) — temperature ↑, pressure ↑
- **Combined Gas Law**: P₁V₁/T₁ = P₂V₂/T₂
- **Ideal Gas Law**: PV = nRT (n = moles, R = 8.314 J/mol·K)

**Aircraft application**: tyre inflation — pressure rises with temperature; must use nitrogen to minimise moisture effects.

### Heat Transfer
- **Conduction**: through solid material — metals have high conductivity
- **Convection**: through fluid movement — natural and forced
- **Radiation**: electromagnetic waves — no medium required (solar heating of aircraft)

### Specific Heat
- **Q = m × c × ΔT** (Joules)
- c_water = 4186 J/kg·K (high — good coolant)
- c_aluminium = 900 J/kg·K
- c_steel = 500 J/kg·K

### Latent Heat
- **Latent heat of vaporisation**: energy to change liquid → gas (without temperature change)
- Used in air conditioning refrigeration cycle

---

## 2.5 Optics

### Light Properties
- Speed of light: c = 3 × 10⁸ m/s
- **Refraction**: bending of light at interface — Snell's Law: n₁ sin θ₁ = n₂ sin θ₂
- **Total internal reflection**: light trapped in denser medium — **fibre optics** principle
  - Occurs when angle exceeds critical angle
- **Reflection**: angle of incidence = angle of reflection

---

## 2.6 Wave Motion and Sound

### Wave Properties
- **Frequency (f)**: cycles per second (Hz)
- **Wavelength (λ)**: distance per cycle (m)
- **Wave equation**: v = f × λ
- **Speed of sound**: ~340 m/s in air at sea level, 20°C
  - Increases with temperature: v ≈ 331 + 0.6T (m/s, T in °C)
  - Sound travels faster in solids than liquids than gas

### Sound Levels
- **Decibel scale**: logarithmic
- 0 dB = threshold of hearing
- 120 dB = threshold of pain
- Every **10 dB** = perceived twice as loud
- Aircraft engine: ~140 dB at 1m

### Ultrasound (NDT link)
- Frequencies > 20 kHz (beyond human hearing)
- Ultrasonic NDT: typically 1–15 MHz
- Reflects from internal defects → displayed as peaks on oscilloscope

---

## 2.7 Electricity and Magnetism (Link to Module 3)

### Electromagnetic Induction (Faraday's Law)
- EMF = −N × dΦ/dt (rate of change of flux)
- Lenz's Law: induced current opposes change causing it

### Electromagnetic Spectrum
| Type | Frequency Range | Use |
|------|----------------|-----|
| Radio | 3 Hz – 300 GHz | Navigation, comms |
| Microwave | 300 MHz – 300 GHz | Weather radar, DME |
| Infrared | 300 GHz – 400 THz | Thermal imaging |
| Visible | 400–700 THz | Optical instruments |
| UV | 700 THz – 30 PHz | — |
| X-ray | 30 PHz – 30 EHz | NDT radiography |
| Gamma | > 30 EHz | NDT radiography |

---

## Key Exam Traps — Module 2
1. **Boyle's Law**: P and V inversely proportional at constant T
2. **Gay-Lussac**: pressure and temperature directly proportional at constant V — aircraft tyres
3. **Pascal's Law**: basis of ALL hydraulic systems — know the force multiplication formula
4. **Bernoulli**: faster flow = LOWER pressure — wing lift, venturi, carburettors
5. **Newton's 2nd Law**: F = ma — heavier aircraft needs more thrust for same acceleration
6. **Torque = Force × distance** — torque wrench principle
7. **Total internal reflection** = fibre optics principle
8. **Speed of sound**: ~340 m/s in air — increases with temperature
9. **1 atmosphere = 101,325 Pa = 14.7 psi = 1013.25 mbar/hPa**
10. **Latent heat**: temperature DOES NOT change during phase change — all energy goes to phase change

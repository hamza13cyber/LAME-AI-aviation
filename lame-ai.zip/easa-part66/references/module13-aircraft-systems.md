# Module 13 — Aircraft Aerodynamic Structures & Systems (B2)
## Sources: EASA Part-66 Syllabus, FAA AMT Airframe Handbook (FAA-H-8083-31), AC 43.13-1B

---

## 13.1 Theory of Flight (Advanced)

*(See Module 11B 11.1 for basics — this covers B2-specific depth)*

### Mach Effects
- **Mach number**: ratio of aircraft speed to local speed of sound
- **Critical Mach (Mcrit)**: airspeed at which local airflow on wing first reaches Mach 1
- **Coffin corner**: altitude where Mach limit and stall speed converge — limited manoeuvre margin
- **Mach tuck**: pitch-down tendency at high Mach — rearward shift of centre of pressure
- **Transonic**: 0.75–1.2 Mach — mixed sub/supersonic flow, shock waves
- **Swept wings**: delay onset of compressibility effects — most jet aircraft

### Stability
- **Static stability**: initial tendency to return to equilibrium after disturbance
  - Positive = tends to return (desired)
  - Neutral = no tendency
  - Negative = diverges (dangerous)
- **Dynamic stability**: behaviour over time after disturbance
  - Positive = oscillations dampen out
  - Neutral = continuous oscillation
  - Negative = oscillations increase
- **Longitudinal (pitch) stability**: horizontal stabiliser — most critical
- **Lateral (roll) stability**: dihedral, sweep, high wing position
- **Directional (yaw) stability**: vertical fin

### Control Axes
- Roll: about longitudinal axis — ailerons
- Pitch: about lateral axis — elevator
- Yaw: about normal (vertical) axis — rudder

---

## 13.2 Airframe Structures

### Pressure Vessel Design
- Fuselage designed as pressure vessel
- Hoop stress = longitudinal stress × 2 (circumferential stress twice axial)
- Pressurisation cycles = fatigue loading → damage tolerance design mandatory
- **Fail-safe**: multiple load paths — widespread fatigue damage (WFD) considered
- Skin doubler repairs: restore structural integrity

### Fatigue
- **S-N curve**: stress vs number of cycles to failure
- **Fatigue life**: number of cycles before cracks initiate
- **Crack propagation**: growth rate increases as crack grows
- **NDT intervals**: calculated to detect cracks before they reach critical size

### Composites in Structures
*(See Module 6.3 for materials; this covers structural design)*
- Carbon fibre fuselages: B787, A350 — entire fuselage barrel
- Advantages: corrosion-free, high fatigue life, weight saving (~20% vs aluminium)
- Repair classification:
  - Cosmetic: surface only, no structural significance
  - Minor: small area, simple wet layup repair
  - Major: large area, core damage, complex repair, engineering sign-off required
- Bonded repairs: temperature-controlled cure, vacuum bagging essential

---

## 13.3 Air Conditioning and Pressurisation

*(Expanded from Module 11B 11.9)*

### Pack Valve
- Controls bleed air flow to air conditioning pack
- Automatically closes on: pack overheat, engine fire, ditching (water entry prevention)

### Recirculation
- Cabin air partially recirculated through HEPA filters (~50% recirculated)
- Reduces bleed air demand → fuel savings
- HEPA filter: removes particles >0.3 μm (bacteria, viruses)

### Pressurisation Control
- **Automatic mode**: DPC (Digital Pressurisation Controller) — 2 channels
- **Manual mode**: pilot manually controls outflow valve
- **Dump valve**: rapid depressurisation (emergency only)

### Altitude Warning
- Cabin altitude warning: activates at typically **10,000 ft cabin altitude**
- EICAS/ECAM warning displayed
- MEL procedures for partial pressurisation loss

---

## 13.4 Instruments and Avionics

### Air Data System
- **Pitot probe**: measures total (stagnation) pressure
- **Static port**: measures static pressure
- **Air Data Computer (ADC)/ADIRU**: computes: IAS, TAS, Mach, altitude, VSI, TAT, SAT
- **Angle of Attack (AoA) sensor**: vane type — feeds to stall warning, flight computers
- **Total Air Temperature (TAT) probe**: heated to prevent icing

### Primary Flight Instruments
- **ASI (Airspeed Indicator)**: pitot − static pressure → airspeed (IAS)
- **Altimeter**: static pressure → altitude; subscale setting = QNH, QFE, STD (1013.25 hPa)
- **VSI (Vertical Speed Indicator)**: rate of static pressure change → climb/descent rate
  - **IVSI**: instantaneous VSI — uses accelerometer for faster response
- **Attitude Indicator (AI)**: gyroscope — pitch and roll
- **Heading Indicator (DI/HSI)**: directional gyro — needs periodic synchronisation with compass
- **Turn Coordinator**: rate gyro — bank angle + rate of turn + ball (slip/skid)

### Gyroscope Properties
- **Rigidity in space** (gyroscopic inertia): spinning gyro resists change in orientation
- **Precession**: applied force causes 90° delayed movement
- Powered: electrically (AC or DC) or pneumatically (vacuum pump)
- **AHRS** (Attitude and Heading Reference System): solid-state, uses MEMS accelerometers + gyros

### Magnetic Compass
- **Compass errors**:
  - **Variation**: angle between true north and magnetic north (chart correction)
  - **Deviation**: local aircraft magnetic field affecting compass (deviation card)
  - **Turning error**: in turns, compass leads in N hemisphere on S headings, lags on N
  - **Acceleration error**: in E/W flight, acceleration shows false N, deceleration false S

### EFIS (Electronic Flight Instrument System)
- PFD (Primary Flight Display): airspeed, altitude, attitude, heading, flight director
- ND (Navigation Display): map, VOR/ILS deviation, weather radar, traffic
- Symbol Generator: processes data from sensors → drives displays
- DU (Display Unit): active matrix LCD

### ACARS (Aircraft Communications Addressing and Reporting System)
- Digital datalink: VHF primary, HF/SATCOM secondary
- Functions: ATIS, clearances, position reports, maintenance data, AOC messages
- VHF ACARS frequency: 129.125 MHz (primary in Europe)

### FDR / CVR ("Black Boxes")
- **FDR** (Flight Data Recorder):
  - Records minimum 88 EASA-required parameters (modern: 1000+)
  - Duration: minimum **25 hours** of flight data
  - Location: aft fuselage (lowest impact probability)
  - Construction: crash-survivable — withstand 3400G, 1100°C for 30 min, 6000 m depth
  - Underwater locator beacon: 37.5 kHz, active for 30 days
- **CVR** (Cockpit Voice Recorder):
  - Records: cockpit audio, crew interphone, radio calls
  - Duration: **2 hours** minimum (some 25 hours now)
  - Erased: pilot can erase on ground only (after shutdown)
  - Same survivability requirements as FDR

### Weather Radar
- **Frequency**: X-band (9.3 GHz, ~3 cm wavelength) — standard
- Detects: rainfall, hail, turbulence (Doppler)
- Colour coding:
  - Green: light rain (safe)
  - Yellow: moderate (caution)
  - Red: heavy rain (avoid)
  - Magenta: severe, hail (definitely avoid — turn at least 20 nm before)
- **Tilt angle**: must be adjusted with altitude — no tilt = ground return, too high = miss threats
- **Beam width**: ~3°–5° — not suitable for navigation, only weather

### EGPWS/TAWS (Enhanced Ground Proximity Warning System)
- Modes 1–7 (classic GPWS) + database terrain (EGPWS)
- **Mode 1**: excessive descent rate ("SINK RATE, PULL UP")
- **Mode 2**: excessive terrain closure ("TERRAIN, TERRAIN")
- **Mode 3**: loss of altitude after takeoff ("DON'T SINK")
- **Mode 4**: unsafe terrain clearance ("TOO LOW TERRAIN")
- **Mode 5**: below glideslope ("GLIDESLOPE")
- **Mode 6**: callouts (altitude, bank)
- **Mode 7**: windshear ("WINDSHEAR, WINDSHEAR")
- EGPWS adds: forward-looking terrain avoidance using GPS + terrain database

---

## 13.5 Electrical Systems (Advanced)

*(See Module 11B 11.7 — this covers B2 depth)*

### Generator Control Unit (GCU)
- Controls output voltage, frequency, parallel operation
- Protection: overcurrent, undervoltage, overvoltage, differential protection
- **Differential protection**: detects internal winding fault — disconnects instantly

### Bus Protection
- **BTB (Bus Tie Breaker)**: automatically parallels generators if one fails
- **GCB (Generator Circuit Breaker)**: connects/disconnects generator from busbar
- **AC Essential bus**: shed during major power loss — only flight-critical loads

### Constant Frequency Systems
- IDG (Integrated Drive Generator): CSD + generator in one unit
- Hydraulic constant speed drive maintains generator at constant speed regardless of engine RPM
- Output: **115/200V AC, 3-phase, 400 Hz**
- IDG oil temperature: monitored — high temp → auto disconnect
- IDG disconnect: thermal or manual (NOT reconnectable in flight)

### Variable Frequency Systems
- B787, A350: no CSD — engine direct-drives generator
- Generator output varies with engine RPM (360–800 Hz)
- All major loads converted to DC or regulated AC — frequency not critical for most systems
- Lighter, simpler, more reliable than IDG

### HVDC (High Voltage DC)
- B787: 270V DC distribution — more efficient over long distances
- Traditional aircraft: 28V DC from TRU

---

## 13.6 Fire Protection

### Detection Systems
**Thermal detection**:
- **Spot detector**: bimetallic or thermocouple — detects at one point
- **Continuous loop detector**: wire runs through zone — any hot point triggers alarm
  - Fenwal: fuse-type
  - Kidde/Lincoln: resistance-bridge
  - Kidde Graviner: electrical resistance change with temperature

**Smoke detection**:
- **Photoelectric** (optical): smoke particles scatter light beam
- **Ionisation**: radioactive source ionises air — smoke disrupts ion current
- **CO2 detector**: detects combustion products

### Extinguishing Systems
- **Engine/APU fire**: Halon 1301 or HFC (Halon replacement) — stored in spherical bottles
  - Primary + reserve shots (one bottle each)
  - One-shot agent (cannot refill in air)
- **Cargo compartment**: Halon or HFC — continuous suppression capability
- **Lavatory**: automatic BCF extinguisher in waste bins

### Engine Fire Procedure (general)
1. Thrust lever — IDLE
2. Fire handle — PULL (closes fuel, hydraulic, bleed, electrical isolates engine)
3. After 10 seconds — ROTATE (discharges extinguisher)
4. If fire continues — rotate other handle (second shot)

---

## 13.7 Flight Control — Advanced

### Artificial Feel Systems
- FBW aircraft: no aerodynamic feedback → artificial feel required
- **Q-feel**: feel force proportional to dynamic pressure (q = ½ρV²) — realistic at all speeds
- **Spring feel**: simple constant resistance

### High-Lift Devices
- **Fowler flap**: most efficient — increases area AND camber → large C_L max increase
- **Krüger flap**: leading edge device, underside folds down
- **Variable-camber slat**: integral with leading edge, extends and droops

### Spoilers
- Roll spoilers: differential deployment — assist ailerons at high speed
- Ground spoilers (lift dumpers): deploy on touchdown — dump lift, improve braking
- Speedbrakes (flight spoilers): symmetrical deployment — airbraking in flight

### Trimmable Horizontal Stabiliser (THS)
- Entire horizontal stabiliser moves — more effective than trim tab at high speeds
- Powered by: electrical actuators (primary) + hydraulic
- Runaway stabiliser: most serious trim malfunction — must apply counter-control

---

## Key Exam Traps — Module 13

1. **FDR records 25 hours minimum** (not 2 hours — that's CVR older standard)
2. **CVR records 2 hours** (mandatory minimum; some aircraft 25 hours)
3. **ULB frequency = 37.5 kHz**, active 30 days (new: 90 days)
4. **Weather radar = X-band (9.3 GHz)** — not navigation radar
5. **Magenta on weather radar = avoid** (severe, hail)
6. **EGPWS Mode 5 = below glideslope** ("GLIDESLOPE")
7. **Altimeter setting QNH**: MSL pressure; **QFE**: aerodrome elevation = 0; **STD**: 1013.25 hPa
8. **Mach tuck**: pitch-down tendency at high Mach — rearward CP shift
9. **IDG oil disconnect**: cannot reconnect in flight — thermal protection
10. **Differential protection** on generator: detects internal fault — instantaneous trip
11. **Halon**: best extinguishing agent — but environmental concerns, being replaced by HFC alternatives
12. **Fire handle pull**: closes ALL isolating valves (fuel, hyd, bleed, elec) before agent discharged
13. **Continuous loop detector**: detects heat at any point along its length
14. **Smoke detector ionisation type**: uses small radioactive source (usually Americium-241)
15. **Q-feel**: artificial feel proportional to dynamic pressure (realistic flight feel in FBW aircraft)

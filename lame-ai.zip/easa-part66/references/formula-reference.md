# EASA Part-66 B2 — Master Formula & Calculation Reference
## All key formulas with worked examples — exam-ready

---

## ELECTRICITY (Module 3)

### Ohm's Law Triangle
```
    V
   ___
  I × R
```
- V = I × R
- I = V / R
- R = V / I

**Example**: 24V supply, 6Ω resistance → I = 24/6 = **4A**

### Power Formulas
- P = V × I
- P = I² × R
- P = V² / R

**Example**: 4A through 6Ω → P = 4² × 6 = 16 × 6 = **96W**

### Energy
- W = P × t (Joules = Watts × seconds)
- W = P × t/3600 (Watt-hours)

### Resistors in Series
R_total = R₁ + R₂ + R₃

**Example**: 10Ω + 15Ω + 25Ω = **50Ω**

### Resistors in Parallel
1/R_total = 1/R₁ + 1/R₂ + 1/R₃

**Two resistors**: R_total = (R₁ × R₂) / (R₁ + R₂)

**Example**: 6Ω ∥ 12Ω = (6×12)/(6+12) = 72/18 = **4Ω**

### Kirchhoff's Voltage Law
Sum of all voltages around a loop = 0
(Supply voltage = sum of voltage drops)

### Kirchhoff's Current Law
Current in = Current out at any node

---

## CAPACITORS (Module 3)

### Capacitance
C = Q / V (Farads = Coulombs / Volts)

### Capacitors in Series
1/C_total = 1/C₁ + 1/C₂ (total LESS than smallest — opposite to resistors)

### Capacitors in Parallel
C_total = C₁ + C₂ + C₃ (total MORE — same as resistors in series)

### Time Constant (RC Circuit)
τ = R × C (seconds)
- At 1τ: charged to **63.2%**
- At 2τ: 86.5%
- At 3τ: 95.0%
- At 5τ: 99.3% (fully charged for practical purposes)

**Example**: R = 10kΩ, C = 100μF → τ = 10,000 × 0.0001 = **1 second**

---

## INDUCTORS (Module 3)

### Inductive Reactance
X_L = 2π × f × L (Ohms)

**Example**: f = 400 Hz, L = 0.1H → X_L = 2π × 400 × 0.1 = **251 Ω**

### Capacitive Reactance
X_C = 1 / (2π × f × C)

**Example**: f = 400 Hz, C = 10μF → X_C = 1/(2π × 400 × 0.00001) = **39.8 Ω**

### Resonant Frequency
f_r = 1 / (2π × √(LC))

At resonance: X_L = X_C, minimum impedance (series), maximum impedance (parallel)

### Impedance (Series RLC)
Z = √(R² + (X_L − X_C)²)

**Example**: R=30Ω, X_L=60Ω, X_C=20Ω → Z = √(30² + (60-20)²) = √(900+1600) = √2500 = **50Ω**

### Phase Angle
tan φ = (X_L − X_C) / R

### Power Factor
PF = cos φ = R / Z = True Power / Apparent Power

---

## AC VALUES (Module 3)

| Value | Relationship | Formula |
|-------|-------------|---------|
| Peak (Vp) | — | — |
| RMS | = 0.707 × Vp | = Vp / √2 |
| Average | = 0.637 × Vp | = (2/π) × Vp |
| Peak-to-Peak | = 2 × Vp | — |

**Example**: UK 230V RMS → Vp = 230/0.707 = **325V peak**
**Aircraft**: 115V RMS → Vp = 115/0.707 = **162.6V peak**

### Three-Phase Star (Y)
- V_line = √3 × V_phase = **1.732 × V_phase**
- I_line = I_phase

### Three-Phase Delta (Δ)
- V_line = V_phase
- I_line = √3 × I_phase = **1.732 × I_phase**

### True / Reactive / Apparent Power
- True Power (P) = V × I × cos φ (Watts)
- Reactive Power (Q) = V × I × sin φ (VAR)
- Apparent Power (S) = V × I (VA)
- S² = P² + Q²
- Power Factor = P/S = cos φ

---

## TRANSFORMERS (Module 3)

### Turns Ratio
V₁/V₂ = N₁/N₂ = I₂/I₁

**Step-up**: N₂ > N₁ → V₂ > V₁, I₂ < I₁
**Step-down**: N₂ < N₁ → V₂ < V₁, I₂ > I₁

**Example**: 230V primary, 10:1 ratio step-down → V₂ = 230/10 = **23V**
Current: I₂ = I₁ × (N₁/N₂) = 2A × 10 = **20A**

### Efficiency
η = (P_output / P_input) × 100%
P_input = P_output + losses

---

## DIGITAL / DATA CONVERSION (Module 5)

### Number Conversion

**Binary to Decimal**:
1101₂ = (1×8) + (1×4) + (0×2) + (1×1) = 8+4+0+1 = **13₁₀**

**Decimal to Binary** (repeated division by 2):
13 ÷ 2 = 6 rem **1**
6 ÷ 2 = 3 rem **0**
3 ÷ 2 = 1 rem **1**
1 ÷ 2 = 0 rem **1**
Read remainders bottom to top: **1101₂** ✓

**Binary to Hex** (group 4 bits):
10110110₂ → 1011 | 0110 → B | 6 → **0xB6**

**Hex to Decimal**:
B6₁₆ = (11×16) + 6 = 176+6 = **182₁₀**

**Octal** (group 3 bits):
101110₂ → 101 | 110 → 5 | 6 → **56₈**

### ADC Resolution
- n-bit ADC → 2ⁿ levels
- 8-bit → 256 levels; 12-bit → 4096; 16-bit → 65536

### Nyquist Sampling
f_sample ≥ 2 × f_signal_max

**Example**: audio up to 20 kHz → minimum 40 kHz sampling rate
**Example**: ARINC 429 parameter at 100 Hz → minimum 200 Hz sampling

---

## WEIGHT AND BALANCE (Module 7/11)

### Centre of Gravity
CG = Total Moment / Total Weight
Moment = Weight × Arm (distance from datum)

**Example**:
| Item | Weight (kg) | Arm (m) | Moment (kg·m) |
|------|------------|---------|--------------|
| Empty aircraft | 5000 | 12.5 | 62,500 |
| Fuel | 800 | 14.0 | 11,200 |
| Passengers | 400 | 16.0 | 6,400 |
| **TOTAL** | **6200** | — | **80,100** |

CG = 80,100 / 6,200 = **12.92 m from datum**

Check: within forward limit (e.g., 12.0 m) and aft limit (e.g., 13.5 m) ✓

### Effect of Moving Weight
Change in CG = (Weight moved × Distance moved) / Total weight

**Example**: Move 100 kg baggage 3 m aft, aircraft weight 5000 kg
ΔCG = (100 × 3) / 5000 = **0.06 m aft**

---

## GAS LAWS (Module 2)

### Boyle's Law (constant T)
P₁V₁ = P₂V₂

**Example**: Tyre inflated to 200 psi at 20°C, compressed to half volume:
P₂ = P₁V₁/V₂ = 200 × 1/0.5 = **400 psi**

### Charles' Law (constant P)
V₁/T₁ = V₂/T₂ (T in Kelvin!)

### Gay-Lussac's Law (constant V)
P₁/T₁ = P₂/T₂ (T in Kelvin!)

**Example**: Tyre 200 psi at 20°C (293K), heated to 60°C (333K):
P₂ = 200 × 333/293 = **227 psi** — tyres inflate with temperature!

---

## HYDRAULIC CALCULATIONS (Module 11)

### Pascal's Law
P = F / A → F = P × A → A = F / P

**Force multiplication**:
F₂ = F₁ × (A₂/A₁)

**Example**: Piston 1 = 1 cm² with 100 N force, Piston 2 = 10 cm²:
F₂ = 100 × (10/1) = **1000 N** (mechanical advantage = 10)

**Pressure**: P = F/A = 100 N / 0.0001 m² = **1,000,000 Pa = 1 MPa = 145 psi**

---

## AMPLIFIER CALCULATIONS (Module 4)

### Op-Amp Gains
**Inverting**: Gain = −R_f / R_in

**Example**: R_f = 100kΩ, R_in = 10kΩ → Gain = −10 (10× amplification, 180° phase shift)

**Non-inverting**: Gain = 1 + (R_f / R_in)

**Example**: R_f = 90kΩ, R_in = 10kΩ → Gain = 1 + 9 = **10** (no phase shift)

### Transistor Current Gain
β (hFE) = I_C / I_B

**Example**: β = 100, I_B = 50μA → I_C = 100 × 50μA = **5mA**
I_E = I_C + I_B = 5mA + 0.05mA = **5.05 mA**

---

## DECIBEL CALCULATIONS

### Voltage/Current
dB = 20 × log₁₀(V₂/V₁)

| Ratio | dB |
|-------|-----|
| ×2 | +6 dB |
| ×10 | +20 dB |
| ×100 | +40 dB |
| ÷2 | −6 dB |
| ÷10 | −20 dB |

### Power
dB = 10 × log₁₀(P₂/P₁)

| Ratio | dB |
|-------|-----|
| ×2 | +3 dB |
| ×10 | +10 dB |
| ÷2 | −3 dB |

**Example**: amplifier gain of +26 dB voltage → 20 dB = ×10, 6 dB = ×2 → total ×20

---

## AERODYNAMICS (Module 8/11/13)

### Lift Formula
L = ½ × ρ × V² × S × C_L

**Effect of speed doubling**: L increases by **4×** (V² relationship)
**Effect of altitude doubling**: density halves → L halves at same speed

### Load Factor
n = L/W = 1/cos(bank angle)

| Bank angle | Load factor |
|-----------|------------|
| 0° | 1.0 G |
| 30° | 1.15 G |
| 45° | 1.41 G |
| 60° | 2.0 G |
| 75° | 3.86 G |
| 80° | 5.76 G |

**Stall speed in turn**: V_s_banked = V_s × √n

**Example**: V_s = 70 kt at 60° bank → V_s_banked = 70 × √2 = 70 × 1.414 = **99 kt**

### Mach Number
M = V_aircraft / V_sound

V_sound at sea level ISA = 340 m/s = 661 kt
V_sound decreases with altitude (as temperature decreases)

---

## QUICK UNIT CONVERSIONS

| From | To | Multiply by |
|------|----|------------|
| inches | mm | × 25.4 |
| feet | metres | × 0.3048 |
| nm (nautical miles) | km | × 1.852 |
| knots | km/h | × 1.852 |
| psi | bar | × 0.06895 |
| psi | kPa | × 6.895 |
| bar | psi | × 14.504 |
| lb | kg | × 0.4536 |
| kg | lb | × 2.205 |
| US gal | litres | × 3.785 |
| lb/hr | kg/hr | × 0.4536 |
| °F to °C | — | (F−32) × 5/9 |
| °C to K | — | C + 273.15 |

### Common Values to Memorise
- π = 3.14159
- √2 = 1.414
- √3 = 1.732
- 1/√2 = 0.707
- e = 2.718
- 1 atmosphere = 101,325 Pa = 1013.25 hPa = 14.696 psi = 29.92 inHg
- Speed of light = 3 × 10⁸ m/s
- Speed of sound (ISA SL) = 340 m/s = 661 kt

# EASA Part 66 — Module Syllabus Quick Reference

## B2 Licence Modules (Avionics)

| Module | Title | B2 Level |
|--------|-------|----------|
| 1 | Mathematics | 2 |
| 2 | Physics | 2 |
| 3 | Electrical Fundamentals | 2 |
| 4 | Electronic Fundamentals | 2 |
| 5 | Digital Techniques / Electronic Instrument Systems | 2 |
| 6 | Materials and Hardware | 1 |
| 7 | Maintenance Practices | 2 |
| 8 | Basic Aerodynamics | 2 |
| 9 | Human Factors | 2 |
| 10 | Aviation Legislation | 2 |
| 11B | Turbine Aeroplane — Aerodynamics, Structures & Systems (B2) | 2 |
| 13 | Aircraft Aerodynamic Structures & Systems | 2 |
| 15 | Gas Turbine Engine | 1 |

## B1.1 Licence Modules (Turbine Mechanical)

| Module | Title | B1.1 Level |
|--------|-------|------------|
| 1 | Mathematics | 2 |
| 2 | Physics | 2 |
| 3 | Electrical Fundamentals | 1 |
| 4 | Electronic Fundamentals | 1 |
| 5 | Digital Techniques | 1 |
| 6 | Materials and Hardware | 2 |
| 7 | Maintenance Practices | 2 |
| 8 | Basic Aerodynamics | 2 |
| 9 | Human Factors | 2 |
| 10 | Aviation Legislation | 2 |
| 11A | Turbine Aeroplane — Aerodynamics, Structures & Systems (B1) | 2 |
| 15 | Gas Turbine Engine | 2 |

## Knowledge Levels
- **Level 1**: Familiarization — know the topic exists, basic recognition
- **Level 2**: Working knowledge — understand principles, can apply
- **Level 3**: Detailed knowledge — can analyze, diagnose, repair (only in some B1 modules)

---

## Module 5 — Digital Techniques (Key Topics)

### 5.1 Electronic Instrument Systems
- Typical systems in aircraft: EFIS, ECAM, EICAS, FMS
- EFIS components: EADI, EHSI, symbol generator, display units
- ECAM: warning/caution system, synoptic pages (A320 family)
- EICAS (Boeing): primary and secondary engine displays

### 5.2 Number Systems & Codes
- Binary, octal, hexadecimal conversions
- BCD (Binary Coded Decimal)
- Gray code — used in encoders (only 1 bit changes at a time)
- Two's complement for negative numbers

### 5.3 Data Conversion
- ADC (Analogue to Digital): sampling, quantization, encoding
- DAC (Digital to Analogue): R-2R ladder, binary weighted
- Nyquist sampling theorem: fs ≥ 2 × fmax
- Aliasing: occurs when sampling rate is too low

### 5.4 Data Buses
| Bus | Speed | Direction | Used on |
|-----|-------|-----------|---------|
| ARINC 429 | 12.5 / 100 kbps | Unidirectional | Most commercial aircraft |
| ARINC 629 | 2 Mbps | Bidirectional | B777 |
| MIL-STD-1553 | 1 Mbps | Bidirectional | Military |
| AFDX (ARINC 664) | 100 Mbps | Bidirectional | A380, A350, B787 |
| CAN Bus | up to 1 Mbps | Bidirectional | Some systems |

### 5.5 Logic Gates & Boolean Algebra
- AND: output 1 only if ALL inputs = 1
- OR: output 1 if ANY input = 1
- NOT: inverter
- NAND = AND + NOT (universal gate)
- NOR = OR + NOT (universal gate)
- XOR: output 1 if inputs are DIFFERENT
- De Morgan's theorem: Ā·B̄ = (A+B)̄

### 5.6 Flip-Flops & Sequential Logic
- SR flip-flop (Set-Reset)
- D flip-flop (Data/Delay)
- JK flip-flop — eliminates invalid state of SR
- T flip-flop (Toggle) — used in counters
- Registers: shift registers (SIPO, SISO, PIPO, PISO)
- Counters: ripple (asynchronous) vs synchronous

### 5.7 Multiplexing
- Time Division Multiplexing (TDM): time slots
- Frequency Division Multiplexing (FDM): frequency bands
- Used to reduce wiring weight in aircraft

### 5.8 Fibre Optics
- Advantages: immune to EMI, lightweight, high bandwidth, secure
- Types: single-mode (long range), multi-mode (short range)
- Connectors: ST, SC, LC types
- Testing: optical power meter, OTDR

### 5.9 Software
- DO-178B / DO-178C software levels:
  - Level A: Catastrophic — most rigorous
  - Level B: Hazardous
  - Level C: Major
  - Level D: Minor
  - Level E: No safety effect — least rigorous
- DO-254: Hardware equivalent of DO-178

### 5.10 ESD Precautions
- Electrostatic sensitive devices (ESSD)
- ESD damage can occur at voltages below human perception
- Handling: wrist strap, ESD mat, conductive packaging
- Yellow triangle with hand symbol = ESSD label

---

## Module 7 — Maintenance Practices (Key Topics)

### 7.1 Safety Precautions
- Aircraft and workshop safety
- Fire categories: A (solids), B (liquids), C (gases), D (metals), E (electrical)
- Correct extinguisher selection per fire category
- LOTO (Lockout/Tagout) procedures

### 7.2 Workshop Practices
- Hand tools: files, drills, taps and dies
- Measuring tools: vernier caliper (0.02mm), micrometer (0.01mm), dial gauge
- Torque wrench: types (click, beam, digital), calibration
- Precision measurement and limits/fits

### 7.3 Riveting
- Rivet types: solid, blind (pop), drive screw
- Materials: aluminium alloy (most common), steel, titanium
- Head types: universal, countersunk, brazier
- Rivet inspection: correct shop head dimensions

### 7.4 Pipes, Hoses and Unions
- Rigid pipes: aluminium, titanium, steel
- Flexible hoses: pressure ratings, bend radius limits
- Flareless vs flared fittings
- Identification: colour coding, pressure markings

### 7.5 Springs
- Compression, extension, torsion types
- Materials: spring steel, stainless steel
- Checking: free length, rate, squareness

### 7.6 Bearings
- Ball, roller, needle, plain (journal) bearings
- Inspection: noise, play, corrosion, contamination
- Lubrication requirements

### 7.7 Transmissions
- Gears, belts, chains
- Backlash measurement
- Gear ratios

### 7.8 Control Cables
- Types: 7×7, 7×19 construction
- Inspection: broken wires, corrosion, kinks
- Turnbuckles: safety wiring, locking clip
- Tensioning and rigging

### 7.9 Electrical Wiring
- AWG (American Wire Gauge) — lower number = thicker
- Colour coding per EASA/manufacturer standards
- Crimping: correct tool, die, inspection
- Circuit breakers vs fuses
- Bonding and shielding

### 7.10 Riveted and Bonded Joints
- Lap joint, butt joint, stepped lap
- Adhesive bonding: surface preparation, cure conditions
- Delamination inspection methods

### 7.11 Pipes and Ducting Systems
- Bleed air ducts: high temperature, inspection for leaks
- Hydraulic lines: visual inspection, pressure testing

### 7.12 Aircraft Weighing
- Equipment: load cells or platform scales
- Datum, moment arm, CG calculation
- Levelling the aircraft before weighing
- Empty weight vs operating weight

### 7.13 Aircraft Ground Handling and Storage
- Towing: nose/main gear steering, speed limits
- Mooring: tie-down points, wind limits
- Jacking: jack points, safety locks
- Storage: flyable vs flyable storage vs long-term storage

### 7.14 Disassembly, Inspection, Repair, Assembly
- AMM reference: chapter/section/subject (ATA numbering)
- NDT methods: visual, dye penetrant, magnetic particle, eddy current, ultrasonic, X-ray
- Damage limits: dents, scratches, corrosion classification
- Documentation: work order, tech log, defect reporting

---

## Exam Statistics Reference
See `exam-stats.md` for question counts and pass marks.

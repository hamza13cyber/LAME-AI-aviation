# EASA Part-66 B2 — Common Mistakes & Confusion Pairs
## The most frequently wrong answers in EASA exams — study this the week before your exam

---

## MODULE 3 — ELECTRICAL FUNDAMENTALS

### ❌ Most Confused Pairs

**Capacitors vs Resistors in Series/Parallel** — OPPOSITE rules
- Resistors in series: R_total = R₁ + R₂ (increases)
- Capacitors in series: 1/C = 1/C₁ + 1/C₂ (decreases — OPPOSITE!)
- Resistors in parallel: decreases | Capacitors in parallel: increases ✓

**NiCd vs Lead-Acid electrolyte**
- NiCd = **potassium hydroxide (KOH)** — alkaline
- Lead-acid = **sulphuric acid (H₂SO₄)** — acidic
- NEVER add acid to NiCd or alkali to lead-acid

**ELI the ICE man (phase relationships)**
- ELI: in an inductor (L), voltage (E) leads current (I)
- ICE: in a capacitor (C), current (I) leads voltage (E)
- Mistake: many students reverse this

**IDG disconnect**
- Can be disconnected in flight ✓
- CANNOT be reconnected in flight ✗ — thermal protection mechanism
- Must be serviced on ground

**RMS vs Peak voltage**
- RMS = 0.707 × Peak
- Peak = 1.414 × RMS
- Aircraft 115V AC = **RMS**, peak = **162.6V** (not 115V!)

---

## MODULE 4 — ELECTRONIC FUNDAMENTALS

### ❌ Most Confused Pairs

**Common Emitter vs Common Collector**
- Common Emitter: highest gain (voltage AND current), 180° phase inversion — most used
- Common Collector (emitter follower): current gain only, NO voltage gain, NO phase shift — buffer
- Common Base: voltage gain only, no current gain — high frequency

**Zener diode orientation**
- Operates in **REVERSE BREAKDOWN** (not forward bias like rectifier)
- Maintains constant voltage = regulation
- Mistake: students say "forward bias like normal diode"

**Class A vs Class C efficiency**
- Class A: ~25% efficient, LOWEST distortion — audio quality
- Class C: >90% efficient, HIGHEST distortion — RF/tuned circuits only
- Mistake: confusing which is most efficient with which sounds best

**NPN vs PNP**
- NPN: base current turns it ON, current flows collector→emitter
- PNP: base current turns it OFF (current flows from base), emitter→collector
- Arrow on emitter: points INTO base for NPN, points OUT for PNP
- Memory: NPN = "Not Pointing iN"

**Op-amp inverting gain sign**
- Inverting: Gain = **-Rf/Rin** (negative sign = 180° phase inversion)
- Non-inverting: Gain = **1 + Rf/Rin** (always positive, always ≥1)
- Never forgets the minus sign for inverting

**Synchro null**
- Null = zero output voltage = ALIGNED position (not "error")
- Mistake: students think null means something is wrong

---

## MODULE 5 — DIGITAL TECHNIQUES

### ❌ Most Confused Pairs

**ARINC 429 vs ARINC 629 direction**
- ARINC 429 = **UNIDIRECTIONAL** (1 transmitter, up to 20 receivers)
- ARINC 629 = **BIDIRECTIONAL** (B777 only)
- AFDX = bidirectional, Ethernet-based (A380, A350, B787)
- Mistake: calling ARINC 429 "bidirectional" = WRONG

**DO-178 Levels — direction**
- Level A = **Catastrophic** = MOST testing required
- Level E = No safety effect = LEAST testing
- Mistake: many reverse this (Level A seems like "basic" but it's most rigorous)

**Gray code vs BCD**
- Gray code: only 1 bit changes between adjacent values — used in **shaft encoders** (prevents glitch errors)
- BCD: each decimal digit coded in 4 binary bits — used in numeric displays
- Mistake: using Gray code for arithmetic (it's not for calculations)

**Nyquist rate**
- Must sample at **MINIMUM 2×** the highest signal frequency
- Sample at LESS than 2× → aliasing (signal distortion)
- Sample at exactly 2× = theoretically sufficient but not practical
- Real systems sample at 5–10× for safety

**NAND vs NOR as universal gates**
- BOTH NAND and NOR are universal — each can implement ANY logic function
- Mistake: saying only one is universal

**ESD damage voltage**
- Human FEELS static at ~3,000V
- CMOS damage can occur at <**100V** (below human perception!)
- Mistake: assuming you'd notice if you damaged a component

---

## MODULE 6 — MATERIALS & HARDWARE

### ❌ Most Confused Pairs

**Aluminium alloy 2024 vs 7075**
- 2024-T3: high strength, POOR corrosion (needs Alclad) — fuselage skins, stringers
- 7075-T6: HIGHEST strength of all Al alloys, moderate corrosion — wing spars
- Mistake: saying 7075 is "the best for everything" — it has worse corrosion than 2024 in some environments

**Self-locking nut reuse**
- Nylock (nylon insert): **SINGLE USE ONLY** — nylon crushed
- All-metal (Stover, Philidas): **REUSABLE** — used in high-temp (no nylon)
- Critical exam question: "can this nut be reused?"

**Bolt head markings (AN vs NAS)**
- AN bolt: no special marking = standard strength
- Close-tolerance bolt: **triangle** on head — used in shear joints
- Mistake: not knowing what triangle means

**7×7 vs 7×19 cable**
- 7×7: 49 wires, less flexible — general control use
- 7×19: 133 wires, MOST flexible — tight radius pulleys
- Mistake: thinking more wires = less flexible (OPPOSITE)

**Turnbuckle threads showing**
- Minimum **4 threads** showing through safety hole AFTER adjustment
- NOT 3, not 2 — specifically 4 minimum
- Then: safety wire or clip locking required

**Class D fire**
- Metal fires (magnesium, titanium, lithium)
- Extinguisher: **dry sand or special DPX powder**
- NEVER use water — violent steam explosion
- Mistake: using CO₂ or foam on metal fires

---

## MODULE 7 — MAINTENANCE PRACTICES

### ❌ Most Confused Pairs

**CRS vs EASA Form 1**
- **CRS** (Certificate of Release to Service): for **aircraft** — issued by B1/B2 licence holder
- **EASA Form 1**: for **components/parts** — approved release document
- FAA equivalent of EASA Form 1 = FAA 8130-3
- Mistake: saying Form 1 releases an aircraft

**AD vs Service Bulletin**
- **AD (Airworthiness Directive)**: MANDATORY — issued by authority (EASA/FAA)
- **SB (Service Bulletin)**: manufacturer recommendation — NOT mandatory unless adopted as AD
- Mistake: saying SBs are mandatory without qualification

**De-icing vs Anti-icing**
- **De-icing**: REMOVES existing ice (Type I fluid — orange)
- **Anti-icing**: PREVENTS ice formation (Type II/IV fluid — green/colourless)
- You can do both: first de-ice (Type I), then anti-ice (Type IV)
- Mistake: using terms interchangeably

**Dye penetrant limitations**
- Only works on **non-porous, accessible surfaces**
- Will NOT detect: subsurface cracks, cracks in composites, internal defects
- Mistake: using PT on porous materials or expecting subsurface detection

**Magnetic particle inspection limitations**
- Only works on **ferromagnetic materials** (iron, cobalt, nickel, some steels)
- WILL NOT work on: aluminium, titanium, composites, austenitic stainless steel
- Mistake: applying MT to aluminium airframe components

**Wire AWG — direction**
- AWG: **lower number = THICKER wire**
- AWG 4 is THICKER than AWG 22
- Mistake: thinking higher AWG = thicker (OPPOSITE of metric)

**Bonding resistance vs insulation resistance**
- **Bonding**: should be very LOW (<5 mΩ = 0.005 Ω)
- **Insulation**: should be very HIGH (>1 MΩ = 1,000,000 Ω)
- Mistake: confusing which should be high and which low

---

## MODULE 9 — HUMAN FACTORS

### ❌ Most Confused Pairs

**Slip vs Mistake vs Violation**
- **Slip**: correct intention, wrong execution (put right part in wrong place)
- **Lapse**: memory failure (forgot a step)
- **Mistake**: wrong plan entirely (used wrong procedure)
- **Violation**: deliberate deviation from rules
- Mistake: calling violations "mistakes" — they are deliberate

**Complacency — who is most at risk?**
- **Experienced technicians** are MORE at risk than novices
- Experience creates automation → less conscious attention → more errors
- Mistake: thinking inexperience is the biggest complacency risk

**Authority gradient — which is dangerous?**
- **HIGH** authority gradient = dangerous (junior won't challenge senior)
- **LOW** (flat) gradient = safer — challenges accepted, errors caught
- Mistake: thinking high authority (strong leader) is always good

**Dirty Dozen number 4 = Distraction** (not fatigue, not pressure)
- Distraction is #4: interruption causes step omission — most common maintenance error cause
- Fatigue is #6
- Pressure is #8
- Know the ORDER if exam asks for specific numbers

---

## MODULE 10 — AVIATION LEGISLATION

### ❌ Most Confused Pairs

**ICAO founding year**
- ICAO founded **1944** (Chicago Convention)
- Convention entered into force: 1947
- Mistake: saying ICAO founded 1947

**EASA location**
- EASA headquartered in **Cologne, Germany** (not Brussels, not Paris)

**AMC vs GM vs Regulation**
- **Regulation**: legally binding (e.g., EU 2018/1139)
- **AMC** (Acceptable Means of Compliance): shows ONE way to comply — not mandatory
- **GM** (Guidance Material): explanatory — not mandatory
- Mistake: thinking AMC is mandatory (it's just one acceptable way)

**Part-66 experience requirements**
- With Part-147 approved training: **2 years** practical experience
- Without approved training: **5 years** practical experience
- Mistake: saying 3 years for all

**B1 vs B2 scope**
- B1 = mechanical licence (engines, airframe, mechanical systems)
- B2 = avionics/electrical licence (avionic and electrical systems)
- B1 CANNOT certify avionics work without B2 or additional rating
- B2 CANNOT certify engine/mechanical work

---

## MODULE 11/13 — AIRCRAFT SYSTEMS

### ❌ Most Confused Pairs

**FDR vs CVR duration**
- **FDR** minimum: **25 hours** of flight data
- **CVR** minimum: **2 hours** (older standard) — newer: 25 hours
- Mistake: saying both record 2 hours

**ULB (Underwater Locator Beacon)**
- Frequency: **37.5 kHz**
- Duration: **30 days** (newer requirement: 90 days for CVR)
- Mistake: saying 406 MHz (that's ELT frequency)

**Stall = AoA, not airspeed**
- Stall occurs when **critical AoA exceeded** (not below a specific airspeed)
- Stall can occur at ANY speed (even high speed in turns with high load factor)
- Mistake: saying "aircraft stalls at Vs" without qualifying level flight

**Hydraulic system pressure (commercial)**
- Most airliners (A320, B737): **3000 psi** (207 bar)
- Some newer (A380 yellow+green): **5000 psi**
- Mistake: saying 1500 psi (too low) or 10,000 psi (way too high)

**Positive vs Negative pressure relief valve**
- **Positive relief valve**: prevents cabin pressure EXCEEDING structural limits (over-pressurisation)
- **Negative relief valve**: prevents cabin pressure EXCEEDING ambient (structural damage on descent/impact)
- Mistake: mixing up which valve does which job

**IDG vs CSD**
- **CSD** (Constant Speed Drive): drive unit only
- **IDG** (Integrated Drive Generator): CSD + generator combined in one unit
- Modern aircraft use IDG — IDG replaced CSD+generator as separate units
- Mistake: saying CSD = IDG

**Mach tuck direction**
- Mach tuck = pitch **DOWN** (nose drops)
- Caused by: rearward shift of centre of pressure at transonic speeds
- Correction: apply nose-UP elevator, reduce speed
- Mistake: saying aircraft pitches UP at high Mach

---

## CROSS-MODULE CONFUSION

### Numbers That Appear Across Multiple Modules

| Value | Context | Common Wrong Answer |
|-------|---------|-------------------|
| 400 Hz | Aircraft AC frequency | 50 Hz (household) or 60 Hz (US) |
| 115V | Aircraft AC RMS voltage | 120V (US household) or 230V (EU) |
| 28V DC | Aircraft DC bus voltage | 12V (automotive) or 24V |
| 3000 psi | Hydraulic system pressure | 1500 psi or 5000 psi |
| 75% | EASA pass mark | 70% or 80% |
| 1090 MHz | Transponder REPLY frequency | 1030 MHz (that's interrogation!) |
| 1030 MHz | Transponder INTERROGATION frequency | 1090 MHz (reversed!) |
| 37.5 kHz | ULB (underwater locator beacon) | 406 MHz (that's ELT) |
| 75 MHz | Marker beacon ALL types | Different frequency per marker (WRONG — all same) |
| 108-118 MHz | VOR/ILS frequency range | Wrong range |

---

## LAST-WEEK REVISION CHECKLIST

Before your exam, verify you know:
- [ ] ELI the ICE man (inductor/capacitor phase)
- [ ] ARINC 429 = unidirectional
- [ ] DO-178 Level A = most critical
- [ ] Nylock nut = single use only
- [ ] CRS = aircraft; Form 1 = component
- [ ] AD = mandatory; SB = not mandatory (unless made so)
- [ ] FDR = 25 hours; CVR = 2 hours minimum
- [ ] Transponder: receives 1030 MHz, replies 1090 MHz
- [ ] All marker beacons on 75 MHz
- [ ] ILS 90 Hz = left/above; 150 Hz = right/below
- [ ] Positive pressure relief = over-pressurisation protection
- [ ] ESD damage below human perception threshold
- [ ] AWG lower number = thicker wire
- [ ] IDG cannot be reconnected in flight

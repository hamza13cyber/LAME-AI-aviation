# Module 8 — Basic Aerodynamics (B1/B2)
## Module 15 — Gas Turbine Engine (B2 Level 1)
## Sources: EASA Part-66 Syllabus, FAA PHAK, FAA AMT Powerplant Handbook

---

# MODULE 8 — BASIC AERODYNAMICS

## 8.1 Physics of the Atmosphere

### ICAO Standard Atmosphere (ISA)
| Parameter | Sea Level (ISA) |
|-----------|----------------|
| Temperature | 15°C (288.15 K) |
| Pressure | 1013.25 hPa (101,325 Pa / 14.7 psi) |
| Density | 1.225 kg/m³ |
| Speed of sound | 340 m/s (661 knots) |

**Lapse rates (troposphere)**:
- Temperature: −2°C per 1000 ft (−6.5°C per 1000 m) up to tropopause
- Tropopause: ~36,089 ft (11,000 m) — temperature constant at −56.5°C above this
- Pressure: halves approximately every 18,000 ft
- Density: decreases with altitude — reduces lift AND engine performance

**ISA deviation**: ISA+10 means temperature is 10°C above standard for that altitude

### Atmospheric Layers
- **Troposphere**: 0–11 km — weather, most aviation
- **Stratosphere**: 11–50 km — supersonic, some commercial cruise
- **Ozone layer**: 15–35 km — absorbs UV

---

## 8.2 Aerodynamics of Flight

### Aerofoil Shape and Function
- **Chord**: straight line LE to TE
- **Camber**: curvature — more camber = more lift at same AoA
- **Thickness**: structural strength vs drag trade-off
- **Span**: wing tip to tip
- **Aspect ratio (AR)**: span²/area — high AR = less induced drag (gliders); low AR = high speed (jets)

### Four Forces
- **Lift** (L): perpendicular to relative wind
- **Drag** (D): parallel to relative wind, opposing flight
- **Thrust** (T): forward — from engine
- **Weight** (W): downward — through CG

**Equilibrium flight**: L = W and T = D

### Lift Equation
**L = ½ × ρ × V² × S × C_L**
- Doubling speed = **4× lift** (V² relationship)
- Doubling density = double lift
- C_L increases with AoA up to critical angle (~15°)

### Drag Equation
**D = ½ × ρ × V² × S × C_D**

### Induced Drag
- **Caused by lift** — tip vortices from pressure differential between upper/lower wing
- High at **low speed** (high AoA) — most critical at takeoff/landing
- Reduced by: high aspect ratio, winglets, washout

### Parasite/Profile Drag
- **Form drag**: pressure drag from aircraft shape
- **Skin friction drag**: boundary layer friction
- **Interference drag**: where surfaces meet
- Increases with V²

### Total Drag Curve
- L/D ratio maximum = best glide speed (V_MD) = most efficient airspeed
- Below V_MD: induced drag dominates
- Above V_MD: parasite drag dominates

---

## 8.3 Flight Theory

### Angle of Attack vs Angle of Incidence
- **AoA**: angle between chord line and relative airflow — PILOT CONTROLLED
- **Angle of incidence**: fixed angle between chord line and aircraft longitudinal axis — FIXED

### Stall
- Occurs when **critical AoA exceeded** (typically ~15–16°)
- **Boundary layer separation** from upper surface → sudden loss of lift
- Stall occurs at **same AoA regardless of speed** — just at different airspeeds depending on weight/load factor
- **Stall speed increases** with: weight ↑, bank angle ↑, load factor ↑
  - V_s in banked turn: V_s_banked = V_s_level × √(load factor)
  - 60° bank: load factor = 2 → stall speed × √2 = ×1.41

### Load Factor
- **n = Lift/Weight** — in straight level flight, n = 1G
- 60° bank: n = 1/cos 60° = 2G
- 75° bank: n = 3.86G
- **Manoeuvre speed (V_A)**: below this speed, aircraft stalls before structural limit

### Stability

**Static stability**: initial response to displacement
- Positive: returns toward equilibrium ✓
- Neutral: stays displaced
- Negative: diverges ✗

**Dynamic stability**: subsequent behaviour
- Positive: oscillations dampen ✓
- Neutral: phugoid constant oscillation
- Negative: oscillations grow ✗

**Longitudinal (pitch) stability**: horizontal stabiliser — most important
- CG aft of neutral point = unstable
- CG too far forward = too stable, heavy elevator, poor performance
- Optimal: CG slightly forward of neutral point

**Lateral (roll) stability**:
- **Dihedral**: wings angled upward → sideslip creates restoring roll
- **Sweepback**: increases effective span on leading wing in sideslip
- **High wing** position: pendulum effect — naturally more stable

**Directional (yaw) stability**:
- Vertical fin (keel effect)
- More fin area = more directional stability

### Control Surfaces
- **Ailerons**: roll — differential (one up, one down)
- **Elevator**: pitch — hinged on horizontal stabiliser
- **Rudder**: yaw — hinged on vertical stabiliser
- **Adverse yaw**: aileron creates drag → yaw toward raised wing → corrected by rudder
- **Frise aileron**: reduces adverse yaw by using geometry

### Trim
- **Trim tabs**: secondary surface on control surface — relieves stick force
- **All-moving tailplane (THS)**: entire stabiliser moves — more powerful at high speed

---

## 8.4 High-Speed Flight

### Subsonic, Transonic, Supersonic
- Subsonic: M < 0.75
- Transonic: M 0.75–1.2 (mixed flow)
- Supersonic: M > 1.2
- Hypersonic: M > 5

### Compressibility Effects
- **Critical Mach (Mcrit)**: first point where local flow reaches M1.0
- Above Mcrit: shock waves form → drag rise, control problems
- **Mach tuck**: pitch-down tendency above Mcrit (CP moves aft)
- **Swept wings**: delay Mcrit — most jet transports swept 25–35°
- **Supercritical aerofoil**: designed to minimise shock wave formation

### Shock Waves
- **Normal shock**: perpendicular to flow — subsonic behind it, total pressure loss
- **Oblique shock**: at angle — still supersonic behind
- **Expansion fan**: speed increase around convex surface

---

## Key Exam Traps — Module 8
1. **Lift varies with V²** — double speed = 4× lift
2. **Stall always at same AoA** (~15°) — not same airspeed
3. **Induced drag dominant at LOW speed** — parasite dominant at HIGH speed
4. **60° bank = 2G load factor** — stall speed × 1.41
5. **Dihedral**: primary means of lateral stability
6. **High aspect ratio** = less induced drag (gliders, not jet fighters)
7. **Mach tuck**: pitch DOWN at high Mach — forward yoke required
8. **ISA**: 15°C, 1013.25 hPa, 1.225 kg/m³ at sea level
9. **Tropopause at ~36,000 ft** — temperature stops decreasing above this
10. **Adverse yaw**: aileron creates yaw toward RISING wing (corrected by rudder)

---

# MODULE 15 — GAS TURBINE ENGINE (B2 Level 1)

## 15.1 Fundamentals

### Brayton Cycle (Gas Turbine Thermodynamic Cycle)
1. **Intake**: ram air enters intake
2. **Compression**: axial/centrifugal compressor raises pressure (~40:1 modern engines)
3. **Combustion**: fuel added, burns at constant pressure — temperature rises to ~1500–1700°C
4. **Expansion (Turbine)**: hot gases expand through turbine — extract energy to drive compressor
5. **Exhaust**: remaining energy provides thrust

**Work output** = turbine work − compressor work

### Engine Types
| Type | Principle | Aircraft |
|------|-----------|---------|
| **Turbojet** | All thrust from jet exhaust | Early jets, Concorde |
| **Turbofan** | Fan bypasses core — efficient subsonic | A320, B737, B777 |
| **Turboprop** | Most energy extracted by turbine → drives propeller | ATR72, C130 |
| **Turboshaft** | All power to shaft → drives rotors | Helicopters |

**Bypass ratio (BPR)**:
- Ratio of bypass airflow to core airflow
- High BPR (>5): modern efficient turbofan (CFM56 BPR~5.5; GEnx BPR~9)
- Low BPR (<2): military/older turbofan
- High BPR = lower fuel burn, lower noise, lower specific thrust

---

## 15.2 Engine Components

### Intake
- **Subsonic intake**: divergent duct — slows air, raises pressure (ram recovery)
- **Supersonic intake**: variable geometry — manages shock waves
- **Inlet guide vanes (IGV)**: direct airflow to compressor at correct angle

### Compressor
**Centrifugal compressor**:
- Radial flow outward through impeller
- Simple, robust, high pressure ratio per stage (~5:1)
- Used in: APU, small turboprops, helicopters

**Axial compressor**:
- Multiple alternating rotor and stator stages
- Each stage: rotor accelerates air → stator decelerates (converts velocity to pressure)
- High efficiency, high mass flow
- Pressure ratio: ~1.2:1 per stage → 16–20 stages for 40:1 overall

**Compressor stall**:
- Local AoA on blade exceeds stall angle → airflow separation
- Causes: rapid throttle movement, FOD ingestion, damaged blades, icing
- Symptoms: bang, vibration, EGT/N2 fluctuation
- Recovery: reduce throttle

**Surge**:
- Complete breakdown of airflow through compressor — very damaging
- Prevention: bleed valves (dump air at intermediate stages), variable stator vanes

### Combustion Chamber
Types:
- **Can type**: individual cans around engine — easy to remove/replace
- **Annular**: single ring — lighter, more efficient, best flame stability (modern standard)
- **Can-annular**: hybrid — B747 JT9D era

**Primary zone**: rich mixture, flame stability
**Secondary zone**: additional air for complete combustion
**Dilution zone**: cooling air added, reduces temperature to turbine limits

### Turbine
- **High Pressure Turbine (HPT)**: drives HP compressor — hottest, most stressed
- **Low Pressure Turbine (LPT)**: drives LP compressor/fan — more stages, extracts remaining energy
- **Turbine Entry Temperature (TET/TIT)**: typically 1300–1700°C — limits performance
- **Turbine Blade Cooling**: internal air passages, film cooling, thermal barrier coating
- **Turbine blade creep**: permanent elongation under sustained high temperature + stress

### Exhaust
- Convergent nozzle: subsonic exhaust (most commercial)
- Convergent-divergent nozzle: supersonic exhaust (military/Concorde)
- **Thrust reversers**: redirect exhaust forward to decelerate on landing
  - Cascade type (most turbofans)
  - Clamshell type (turboprops)

---

## 15.3 Engine Performance Parameters

### Thrust
**F = ṁ(V_exit − V_inlet)**
- ṁ = mass flow rate (kg/s)
- V_exit = jet velocity
- V_inlet = intake velocity (aircraft speed)

**Factors affecting thrust**:
- Temperature ↑ → density ↓ → thrust ↓ (hot day = longer takeoff)
- Altitude ↑ → density ↓ → thrust ↓
- Speed ↑ → ram recovery ↑ → thrust increases (initially)

### Efficiency
- **Thermal efficiency**: heat released by fuel → work done
- **Propulsive efficiency**: work done on aircraft → total kinetic energy of jet
  - High jet velocity = lower propulsive efficiency (turbofan better than turbojet)
- **Overall efficiency**: product of both

### Engine Ratings
- **Maximum (Take-off) thrust**: 5-minute limit
- **Maximum continuous**: no time limit
- **Maximum climb**: cruise climb
- **Idle**: ground idle and flight idle (different settings)

---

## 15.4 Engine Instruments (B2 Focus)

### N1 (Low Pressure Spool Speed)
- Fan/LP compressor speed — expressed as % of rated RPM
- Primary thrust setting parameter on turbofan
- Typical cruise: 85–90% N1

### N2 (High Pressure Spool Speed)
- HP compressor speed — expressed as %
- Used for engine health monitoring

### EGT/TGT (Exhaust Gas Temperature / Turbine Gas Temperature)
- Critical limit — exceeding causes turbine blade damage
- Monitored: start (limit), climb, cruise, go-around
- High EGT at start: hot start (improper start)

### Fuel Flow
- kg/h or lb/hr
- **TSFC** (Thrust Specific Fuel Consumption): fuel per unit thrust — efficiency measure

### EPR (Engine Pressure Ratio)
- Ratio of turbine exit total pressure to compressor inlet total pressure
- Used as thrust setting on some engines (JT9D, PW4000)

### Oil System Monitoring
- Oil pressure: must be within limits at all power settings
- Oil temperature: limits for different phases
- Oil quantity: preflight check
- Chip detectors: magnetic plugs detect metallic particles → early warning of internal wear

---

## 15.5 Engine Starting

### Start Sequence
1. **N2 rotation** begins (pneumatic starter)
2. At 15–20% N2: **ignition ON**
3. At 20–25% N2: **fuel ON** (fuel/start valve open)
4. EGT rises — light-off
5. Starter cuts out ~50–55% N2
6. Engine accelerates to idle under own power

### Abnormal Starts
- **Hot start**: EGT exceeds limit during start — abort immediately
- **Hung start**: N2 doesn't accelerate to idle — fuel but no increase in RPM
- **No-light/False start**: no EGT rise after fuel introduction

### Ignition System
- **High energy ignition**: capacitor discharge, ~4–20 Joules per spark
- Two igniters per engine — checked per task card
- Used: engine start, takeoff/landing (precautionary), icing conditions, heavy rain
- Continuous ignition: selected by crew for specific conditions

---

## 15.6 Lubrication System
- Closed-loop system: reservoir → pressure pump → bearings → scavenge pumps → cooler → filter → reservoir
- Oil type: synthetic (MIL-PRF-23699 Type II most common)
- **Never mix oil types** — may cause seal/bearing damage
- Breather pressurisation: prevents oil foaming at altitude
- Magnetic chip detector: checks for metallic contamination before every flight or per schedule

---

## Key Exam Traps — Module 15
1. **Brayton cycle**: compression → combustion → expansion — NOT Carnot cycle
2. **High BPR turbofan** = most fuel-efficient for subsonic transport
3. **Annular combustion chamber**: lightest, most efficient — standard on modern engines
4. **Compressor stall**: blade AoA exceeded — reduce throttle to recover
5. **HPT**: hottest, most highly stressed turbine stage
6. **EGT limit during start**: hot start if exceeded — must follow AMM limits
7. **N1 = primary thrust parameter** on turbofan (not N2)
8. **EPR**: used on some Pratt & Whitney engines for thrust setting
9. **Turbine blade creep**: permanent elongation — life-limited part
10. **Ignition during takeoff**: standard procedure on most operators — wet/icy runway, heavy rain
11. **Oil: never mix types** — synthetic turbine oil only, per type certificate
12. **Thrust reduces in hot/high conditions** — density effect on mass flow

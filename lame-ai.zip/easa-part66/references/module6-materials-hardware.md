# Module 6 — Materials and Hardware (B1 & B2)
## Sources: EASA Part-66 Syllabus, FAA AMT Handbook General, AC 43.13-1B

---

## 6.1 Aircraft Materials — Ferrous

### Steel Identification and Properties
- **Carbon steel**: iron + carbon (0.1–1.5%)
  - Low carbon (<0.3%): soft, weldable — structural tubes, bolts
  - Medium carbon (0.3–0.6%): stronger — cranks, gears
  - High carbon (0.6–1.5%): hard, brittle — springs, cutting tools
- **Alloy steel**: carbon steel + alloying elements
  - Chromium (Cr): corrosion resistance, hardness
  - Nickel (Ni): toughness, impact resistance
  - Molybdenum (Mo): high-temperature strength
  - Vanadium (V): fatigue resistance

### AISI/SAE Steel Coding (4-digit system)
- **13xx**: Manganese steels
- **41xx**: Chromium-molybdenum (chrome-moly) — most common in aircraft tubing
- **43xx**: Nickel-chrome-moly — high strength aircraft parts
- **51xx**: Chromium steel
- Example: **4130** = chrome-moly steel (Cr 0.8–1.1%, Mo 0.15–0.25%) — standard aircraft tube

### Stainless Steel
- Contains minimum 11% chromium — forms passive oxide layer
- **300 series** (austenitic): non-magnetic, excellent corrosion resistance, not heat-treatable
  - 304: general purpose
  - 321: titanium-stabilised for welding
- **400 series** (martensitic/ferritic): magnetic, can be heat-treated
  - 410: general, can be hardened
  - 440C: high hardness, bearings, cutlery

---

## 6.2 Aircraft Materials — Non-Ferrous

### Aluminium Alloys
Most common aircraft structural material — lightweight + corrosion resistant

**Designations** (4-digit):
- First digit = major alloying element:
  - **1xxx**: pure aluminium (>99%)
  - **2xxx**: copper — high strength, poor corrosion resistance (needs clad/anodise) — **structural**
  - **3xxx**: manganese
  - **4xxx**: silicon (welding wire)
  - **5xxx**: magnesium — good corrosion, marine use
  - **6xxx**: magnesium + silicon — good all-round, weldable
  - **7xxx**: zinc — highest strength, aircraft structures — **2024, 7075 most common**

**Key alloys**:
| Alloy | Properties | Use |
|-------|-----------|-----|
| **2024-T3** | High strength, poor corrosion | Wing skins, fuselage |
| **6061-T6** | Good strength, weldable, corrosion resistant | General structure |
| **7075-T6** | Highest strength | Wing spars, critical structures |
| **2017/2117** | Rivet alloys | Structural rivets |

**Temper designations**:
- **-O**: annealed (softest)
- **-T3**: solution treated + cold worked + natural aging
- **-T4**: solution treated + natural aged
- **-T6**: solution treated + artificial aged (peak strength)
- **-T73**: overaged (better stress corrosion resistance than T6)

**Alclad**: aluminium alloy clad with pure aluminium layer for corrosion protection

### Magnesium Alloys
- Lightest structural metal (density ~1.74 g/cm³ vs aluminium 2.7 g/cm³)
- Very fire risk — burns intensely if ignited (Class D fire)
- Poor corrosion resistance — requires protective coating
- Used in: gearboxes, helicopter transmission housings

### Titanium Alloys
- Excellent strength-to-weight ratio
- Outstanding corrosion resistance (even saltwater)
- High-temperature capability (up to ~600°C)
- Expensive and difficult to machine
- Not magnetic — no magnetic particle inspection possible
- Used in: engine compressor blades, airframe fittings, fasteners
- **Ti-6Al-4V (Grade 5)**: most common titanium alloy in aerospace

### Copper and Alloys
- Pure copper: high electrical/thermal conductivity — wiring, heat exchangers
- **Brass**: copper + zinc — corrosion resistant, easy to machine — fittings, valves
- **Bronze**: copper + tin — bushings, bearings
- **Beryllium copper**: high strength, non-sparking — used in tools for fuel tank work

---

## 6.3 Composite Materials

### Types
- **Carbon Fibre Reinforced Polymer (CFRP)**: high strength-to-weight, used structurally
- **Glass Fibre Reinforced Polymer (GFRP)**: radar-transparent (radomes), cost-effective
- **Kevlar (AFRP)**: high impact resistance, poor compression strength
- **Hybrid composites**: combination (carbon + Kevlar) for balanced properties

### Matrix Systems
- **Epoxy**: most common, excellent strength, cures 120–180°C (prepreg) or room temp
- **Bismaleimide (BMI)**: higher temperature capability than epoxy
- **Polyimide**: highest temperature, used in engine areas

### Construction Types
- **Laminate**: layers (plies) of fibre in matrix, bonded together
- **Sandwich**: lightweight core (Nomex honeycomb, foam) between face skins
  - Very stiff, lightweight — used in control surfaces, floor panels

### Damage Assessment
- **Barely Visible Impact Damage (BVID)**: invisible or barely visible — still structurally significant
- Inspection methods: visual, coin tap, ultrasonic, thermography
- Coin tap: dull sound = delamination; sharp sound = good bond
- **Repair**: requires hot bond repair or wet layup as per SRM

### Health and Safety with Composites
- Carbon fibres are conductive — risk of electrical short circuits
- Dust hazard: wear P3 respirator, avoid skin contact
- Epoxy resins: sensitiser — wear gloves, eye protection
- Cured composite: generally safe; uncured/cutting = hazard

---

## 6.4 Corrosion

*(See also Module 7.18.3 for full coverage)*

### Electrochemical Series (Galvanic Series)
Most active (anodic) → Least active (cathodic)
Magnesium → Zinc → Aluminium → Cadmium → Steel → Stainless Steel → Titanium → Copper → Gold/Platinum

**Galvanic corrosion rule**: anodic metal corrodes when coupled to cathodic metal in presence of electrolyte
- Large area cathode + small area anode = accelerated corrosion of anode
- Prevention: isolation (sealant, anodising), use compatible metals, drainage

---

## 6.5 Fasteners

### Bolts
- **AN (Air Force-Navy) / MS (Military Standard)**: most common US-origin aircraft bolts
- **NAS**: National Aerospace Standard — higher tolerance
- Grade identification: head markings indicate strength
  - AN bolt: plain head (no marking) = standard strength
  - Dash number: bolt length in 1/8 inch increments
- Standard thread: UNC (Unified National Coarse), UNF (Unified National Fine)
- Fine thread: stronger, preferred where vibration present

**Close-tolerance bolts**: used where shear loads predominate — marked with triangle on head

### Nuts
- **Plain hex nut**: requires lock wiring or lock washer
- **Castle nut (castellated)**: with cotter pin — self-locking via mechanical means
- **Self-locking nuts**:
  - **Elastic stop nut (Nylock)**: nylon insert — single use only
  - **All-metal (Stover/Philidas)**: deformed thread — reusable, for high-temperature
- **Anchor nuts / Nut plates**: fixed to structure, accessible from one side

### Washers
- **Plain washer**: distribute load, prevent surface damage
- **Lock washer**: spring or tabbed — prevent rotation
- **Shakeproof washer**: star/serrated — positive locking

### Rivets
**Solid rivets (MS20470/20426)**:
- Materials: 2117-T4 (AD, most common), 2024-T4 (DD), 5056 (B, magnesium alloy)
- **Head types**: universal (AN470), countersunk 100° (AN426), brazier
- **Identification by head marking**: dash (-) = 2117, dimple = 2117, raised dot = 2024, raised cross = 2024-T31

**Rivet diameter selection**: 3× skin thickness (minimum rule)
**Rivet spacing**: min 3× diameter edge distance; 3–8× diameter pitch

**Blind rivets (pop rivets)**:
- NAS1398/1399, CR3200 series — where back access not available
- Structural blind rivets: stronger than pop rivets — cherry/huck type
- Cannot replace solid rivets in primary structure without engineering approval

### Inspection of Rivets
- Good shop head: 1.5× diameter wide, 0.5× diameter high
- Loose rivet: turns, tilts
- Driven too hard: cracked
- Wrong size: oversized or undersized hole

---

## 6.6 Pipes, Unions and Flexible Hoses

### Rigid Tubing
- Materials: 5052-O aluminium (low pressure), stainless steel (high pressure/temperature), titanium (weight critical)
- Identified by: OD and wall thickness
- **Flared fittings** (AN/MS): 37° flare angle — hydraulic/pneumatic
- **Flareless fittings** (Ermeto/Parker): ferrule bites into tube — high pressure applications

### Flexible Hoses
- **MIL-H-8794**: low-pressure (fuel, oil, air)
- **MIL-H-6000**: medium pressure
- **MIL-H-5593**: high-pressure hydraulic
- **Parker/Aeroquip**: common commercial types
- Identification: dash number = hose ID in 1/16 inch; time limit markings
- **Shelf life** vs **service life**: check manufacturing date and max service period (typically 4–6 years service)

### Springs, Bearings, Gears
- **Springs**: compression, extension, torsion — inspect for cracks, set (permanent deformation), corrosion
- **Ball bearings**: check for play, noise, contamination, pitting
- **Roller bearings**: cylindrical, tapered — used where thrust and radial loads exist
- **Plain/journal bearings**: bronze/PTFE lined — inspect for wear, scoring, clearance

---

## 6.7 Cables and Turnbuckles

### Control Cables
- **7×7**: 49 wire, flexible — general control use
- **7×19**: 133 wire, extra flexible — pulleys with tight bend radius
- Material: carbon steel (galvanised) or stainless steel

**Inspection**:
- Broken wires: 1 broken wire per 3 cable diameters = reject
- Corrosion, kinks, birdcage, core protrusion = reject
- Minimum cable diameter check

**Turnbuckles**:
- Used to adjust cable tension
- Safety: minimum **4 threads** must show through barrel safety hole after adjustment
- Lock with: safety wire (two methods — single wire / double wrap), or clip (Tinnerman)

---

## 6.8 Springs, Bearings, Transmission Elements

### Bearings
- **Ball bearings**: radial and thrust loads — most common
- **Roller bearings**: heavy radial loads
- **Taper roller**: combined radial + axial (thrust) — wheel bearings, gearboxes
- **Needle bearings**: high radial load in small space

**Bearing inspection**:
- Radial play, axial play: measure with dial gauge
- Noise: spin test — smooth vs rough/gritty
- Lubrication: correct type and quantity critical

---

## Key Exam Traps — Module 6

1. **2024-T3 and 7075-T6** = most common structural aluminium alloys in aircraft
2. **4130 steel** = chrome-moly = most common aircraft steel tube material
3. **Magnesium**: lightest structural metal but highly flammable — Class D fire
4. **Titanium**: NOT magnetic — cannot use magnetic particle NDT
5. **Galvanic series**: aluminium corrodes when in contact with copper/steel + electrolyte
6. **Self-locking Nylock nut**: nylon insert — SINGLE USE ONLY (replace each time)
7. **All-metal self-locking nut**: can be reused — used in high-temperature areas
8. **Solid rivet**: minimum edge distance = 2–3× diameter; shop head = 1.5D × 0.5D
9. **7×19 cable** = most flexible (133 wires) — used on tight-radius pulleys
10. **Turnbuckle**: minimum 4 threads showing after adjustment
11. **Hose shelf life ≠ service life** — check manufacturing date code on hose
12. **Alclad**: aluminium alloy + pure aluminium cladding for corrosion protection
13. **CFRP carbon fibres are electrically conductive** — ESD and short-circuit hazard
14. **Coin tap test**: dull thud = delamination in composite
15. **AN bolt head**: no dash markings = standard; triangle = close tolerance

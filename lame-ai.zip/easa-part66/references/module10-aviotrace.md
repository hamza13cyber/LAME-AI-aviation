# Module 10 — Aviation Legislation (B1 & B2)
## Source: Aviotrace Swiss Cat. B1/B2, Edition 10/05/2022 Rev. 05

---

## 10.1 Regulatory Framework

### 10.1.1 ICAO (International Civil Aviation Organisation)
- UN agency — established at Chicago Convention, **December 1944**
- 54 founding nations
- Sets international standards (SARPs — Standards And Recommended Practices)
- Published in **Annexes** to the Chicago Convention (19 Annexes)
- Annex 1: Personnel Licensing | Annex 6: Aircraft Operation | Annex 8: Airworthiness

### 10.1.2 European Commission Role
- EU legislation applies to EASA member states
- Basic Regulation: **EU 2018/1139** (replaces 216/2008)
- Commission issues **Implementing Rules** (legally binding)

### 10.1.3 JAA (Joint Aviation Authorities)
- Predecessor to EASA — pan-European, but not legally binding
- JAR-66 became Part-66 under EASA
- JAA dissolved after EASA took over

### 10.1.4 EASA (European Union Aviation Safety Agency)
- Established 2002, based in Cologne, Germany
- Issues **Certifications Specifications (CS)** and **AMC/GM** (non-binding guidance)
- Core regulations: Part-21, Part-M, Part-145, Part-66, Part-147

### 10.1.5 Role of Member States and NAA
- **NAA** (National Aviation Authority): implements EASA rules at national level
- Can issue licences, conduct oversight, handle appeals
- Switzerland: **FOCA** (Federal Office of Civil Aviation) / BAZL

### 10.1.6 Structure of Rules
- **Basic Regulation** (EU Parliament/Council) → top level
- **Implementing Rules** (Commission) → legally binding details
- **AMC** (Acceptable Means of Compliance) → EASA guidance, non-binding
- **GM** (Guidance Material) → explanatory, non-binding

### 10.1.7 Relationship Between Parts
```
Part-21 → Aircraft/product design and production
Part-M  → Continuing airworthiness management
Part-145 → Maintenance organisations (AMO)
Part-66  → Certifying staff (licences)
Part-147 → Training organisations (MTO)
```

### 10.1.8 FOCA (Switzerland)
- Swiss national authority
- Applies EASA rules + Swiss national regulations
- Issues Swiss-EASA Part-66 licences

---

## 10.2 Part-66 Certifying Staff

### 10.2.1 General Description
- Defines requirements for **Aircraft Maintenance Licence (AML)**
- Licence categories: A, B1, B2, B3, C

### 10.2.2 Part-66 Structure
- **Section A**: Technical requirements (modules, experience, exams)
- **Section B**: Procedures for competent authorities

### 10.2.3 Section A — Technical Requirements

**Licence Categories**:
| Category | Scope |
|----------|-------|
| A | Line maintenance — limited certifications |
| B1 | Line + base maintenance — mechanical |
| B2 | Line + base maintenance — avionics/electrical |
| B3 | Piston engine non-pressurised aircraft |
| C | Base maintenance — management (no hands-on) |

**Experience Requirements**:
- B1/B2 with approved training (Part-147): **2 years** practical experience
- B1/B2 without approved training: **5 years** practical experience
- A category: 1 year of experience

**Exam Requirements**:
- Written multi-choice exams per module
- Pass mark: **75%** for all modules
- No negative marking

**Type Rating**:
- After B1/B2 licence, must complete aircraft type training for specific aircraft types
- Training: theoretical + practical + on-the-job training (OJT)
- Leads to **Type Rating endorsement** on licence

**Privileges**:
- B1/B2: can issue **Certificate of Release to Service (CRS)** after maintenance
- Limited to scope of licence (mechanical or avionics)
- CRS = release of aircraft or component to service after maintenance

**Recent Changes**:
- Basic examinations valid for **3 years** from pass date for licence application
- Experience must be within **10 years** of licence application

---

## 10.3 Approved Maintenance Organisations (AMO)

### 10.3.1 Part-145 Overview
- Governs organisations that carry out maintenance on commercial aircraft
- Must be approved by competent authority

### 10.3.2 Part-M Subpart F
- For **non-commercial** aircraft maintenance organisations
- Lighter approval regime than Part-145

### 10.3.3 Part-145 Structure
Key requirements:
- Facilities: hangar, workshop, office space
- Personnel: **Accountable Manager**, Quality Manager, certifying staff
- Tools and equipment: calibrated, approved
- Maintenance data: current, approved (AMM, SRM, CMM, etc.)
- **Quality system**: internal audit, feedback, corrective action
- MOE (Maintenance Organisation Exposition) — describes all procedures

**Scope of work**:
- A ratings: aircraft categories (A1, A2, A3, A4 — turbine/piston/large/small)
- B ratings: engines
- C ratings: components
- D ratings: specialized services (NDT, welding)

---

## 10.4 Air Operations

### 10.4.1 Air-OPS (EU No 965/2012)
- Governs commercial air transport operations
- Operators must hold **AOC** (Air Operator Certificate)

### 10.4.3 MEL/CDL
- **MEL** (Minimum Equipment List): approved list of items that may be inoperative for dispatch
- Based on MMEL (Master MEL) from aircraft manufacturer / EASA
- **CDL** (Configuration Deviation List): permitted missing external parts

### 10.4.5 AOC (Air Operator Certificate)
- Required for commercial air transport operations
- Issued by NAA after assessment of operator's capability

### 10.4.6 ETOPS
- Extended range Twin engine OPerationS
- Allows twin-engine aircraft to fly routes >60 min from diversion airport
- Requires specific approval, maintenance programme, crew training

---

## 10.5 Certification of Aircraft, Parts and Appliances

### 10.5.1-10.5.2 Part-21 Overview
- Governs design and production of aircraft, engines, propellers, parts
- Key certificates: **Type Certificate (TC)**, **Supplemental Type Certificate (STC)**

### 10.5.8 Certificate of Airworthiness (CofA)
- Issued by NAA after aircraft shown to conform to approved type design
- Must be kept valid through continued airworthiness actions
- **Restricted CofA**: for aircraft not meeting full standards

### 10.5.9 Certificate of Registration
- Identifies aircraft nationality and registration mark

---

## 10.6 Continuing Airworthiness

### 10.6.3 Part-M Overview
- Ensures aircraft maintained in airworthy condition throughout service life
- Responsibilities shared between: owner/operator, CAMO, AMO

### 10.6.6 Part-M Subpart B — Accountability
- **Owner/operator** is responsible for continued airworthiness
- May delegate to **CAMO** (Continuing Airworthiness Management Organisation)

### 10.6.7 Subpart C — Continuing Airworthiness
- **AMP** (Aircraft Maintenance Programme): planned maintenance tasks + intervals
- Based on MPD (Maintenance Planning Document) from manufacturer
- Must be approved by competent authority

Key documents:
- **AD** (Airworthiness Directive): mandatory — must be complied with
- **SB** (Service Bulletin): manufacturer recommendation — may or may not be mandatory
- **AMM** (Aircraft Maintenance Manual): step-by-step maintenance procedures
- **SRM** (Structural Repair Manual): approved repair data
- **IPC** (Illustrated Parts Catalogue): part numbers, configurations
- **CMM** (Component Maintenance Manual): overhaul of individual components

### 10.6.12 Certificate of Release to Service (CRS)
- Issued by certifying staff (B1/B2) after completing maintenance
- Required before aircraft can be returned to service
- **EASA Form 1**: used for components (equivalent to FAA 8130-3)
- Content of CRS: identity of work done, date, regulatory basis, signature + licence number

---

## 10.7 National Regulations (Switzerland)

### Key Swiss Ordinances
- **LFV** (SR 748.01): Air Navigation Ordinance — main Swiss aviation law
- **VLIp** (SR 748.127.2): Aircraft maintenance personnel licences
- **VLIb** (SR 748.127.4): Maintenance organisation approvals
- **VLL** (SR 748.215.1): Aircraft airworthiness ordinance

---

## Key Exam Traps — Module 10

1. **ICAO founded 1944 in Chicago** — not 1947 (that was when convention entered into force)
2. **EASA is based in Cologne, Germany** — not Brussels
3. **AMC is non-binding** — only the Basic Regulation and Implementing Rules are binding
4. **Pass mark = 75%** for ALL Part-66 modules — no exceptions
5. **B2 licence = avionics/electrical** (not mechanical)
6. **CRS must be issued before aircraft returns to service** — not after
7. **AD = mandatory; SB = normally not mandatory** (unless adopted as AD)
8. **EASA Form 1 = component release** (CRS is for aircraft)
9. **CAMO ≠ AMO** — CAMO manages airworthiness, AMO performs maintenance
10. **MEL is based on MMEL** — operator's MEL cannot be less restrictive than MMEL
11. **B1/B2 with Part-147 training** → 2 years experience; **without** → 5 years
12. **Category C** = base maintenance management — no hands-on certifications

# Module 7.04 — Avionic General Test Equipment (B2)
## Source: Aviotrace Swiss Cat. B2, Edition 31/07/2013 Rev. 01

---

## 7.4.1 Introduction
Avionics test equipment is critical for verifying accuracy and reliability of all aircraft avionics systems. Used for:
- Ramp maintenance (line)
- Base maintenance (hangar)
- Regulatory certification

Main test sets covered:
1. Air data test set
2. Transponder/DME/TCAS test set
3. VOR/ILS/VHF Communications test set
4. FDR/CVR operational checks
5. Fuel capacitance/quantity test set

---

## 7.4.2 Air Data Test Set

### Types
- **Portable**: ABS wheeled case, rainproof, may have remote/hand terminals
- **Rack/table-top**: more precise, more features
- **Hand-held**: most compact, limited functions, includes hand-operated pump

### Tests Performed
- Static system test
- Pitot system test
- Leak tests
- Mach tests
- Altitude and airspeed switch test
- EPR (Engine Pressure Ratio) test
- Vertical speed test

### Key Operating Points
- Calibration is **software-based**, automatic — no mechanical adjustments
- Calibration factors may be **password protected**
- Requires external pressure/vacuum supply (some have internal pump)
- **Altitude correction**: position of test set relative to aircraft sensors must be known
  - On-aircraft: positive correction (test set lower than sensors)
  - Off-aircraft: negative correction (component lower than test set)

### Test Procedures
**Static system test**: controls rate of climb to selected altitude; at end, returns to local atmospheric pressure automatically

**Pitot system test**: reference parameter is airspeed (not altitude); controlled rate to target speed

**Leak tests**:
- Altitude leak → connect to **static port**
- Airspeed leak → connect to **pitot probe**
- Must fully vent test set and aircraft to atmosphere before starting
- Allow temperature/pressure stabilization (up to **5 minutes** in some tests)

**Mach test**: set target Mach value; alter altitude and check airspeed adjusts to keep Mach constant

**EPR test**: EPR = ratio of turbine discharge total pressure to intake total pressure; enter target EPR, verify indicator reading, then conduct leak rate test

### Pitot-Static Adaptor Kit
- Color-coded to identify static vs pitot ports
- Red warning flags attached
- PVC pipes, pneumatic connections, suction fixing stands
- Special design to protect aircraft ports from damage

---

## 7.4.3 Transponder/DME/TCAS Test Set

### System Principles (Brief)

**Transponder**:
- Receives ground radar on **1030 MHz**
- Replies on **1090 MHz** to Secondary Surveillance Radar (SSR)
- Pilot sets 4-digit squawk code (allocated by ATC)
- Modes: A (identity), C (altitude), S (extended data)
- **Do NOT dial 77XX, 76XX, 75XX** during testing (emergency/hijack codes)

**DME (Distance Measuring Equipment)**:
- Operates in **L-band**: 962–1213 MHz
- Aircraft transmits pulses → ground station replies on ±63 MHz
- Ground station delay: **50 μs**
- Measures **slant distance** (not ground distance) — error increases overhead
- Displays in nautical miles

**TCAS (Traffic Collision Avoidance System)**:
- Aircraft-to-aircraft interrogation via Mode S transponder
- Scans ~**15 nautical miles** radius
- Traffic Advisory (TA): visual + aural "Traffic, traffic"
- Resolution Advisory (RA): "Climb, climb" / "Descend, descend"
- Can simulate up to **4 intruding aircraft**

### Transponder Test Setup
- Tripod with remote antenna at **same height** as aircraft transponder antenna
- Test antenna distance from aircraft antenna: ~**21 inches (53.34 cm)** (indicated on coaxial cable)
- Bearing between antennas: not critical

### Transponder Tests
- Transmitter peak power (FREQ/PWR switch → PWR)
- Transponder frequency (deviation from 1090 MHz, expressed in MHz)
- **Receiver sensitivity / MTL** (Minimum Trigger Level): reduce signal until 90% reply → read MTL in dBm
  - Sensitivity difference between A/C CODE and A/C ALT modes must be **≤1.0 dBm**
- Percentage reply operation
- Ident tone and pulse output
- Reply delay, correct reply code, pulse timing, pulse spacing
- Altitude code (Baro set to 29.92 inHg → Numerical Readout in thousands of feet using Gray Daytex Code)
- Receiver and decoder limits
- SLS (Side Lobe Suppression) operation
- Mode A, C and S

### DME Tests
- Transmitter peak power and frequency (FREQ/PWR switch → PWR; reads in kW)
- DME frequency: check crystal tolerance (note: ± signs on XMTR FREQ dial are **reversed** in DME mode)
- Distance operation: lock on at programmed range (nautical miles)
- Ground Speed (GS) and Time-To-Go (TTG) calculations
- PRF (Pulse Repetition Frequency): Track PRF (locked, 0–30 setting) vs Search PRF (30–300 setting)
- Ident tone: **1350 Hz** heard through audio system
- Test frequency: initially set to **108.00 MHz**

### TCAS Ramp Test
- Test antenna within **50 feet (15.25 m)** and line of sight with top AND bottom antennas
- Use fuselage to block line of sight when testing individual antennas
- Aircraft configured for **weight off wheels**
- Tests: static/dynamic target simulation, intruder closing/climbing/diving

---

## 7.4.4 VOR/ILS Communications Test Set

### System Principles

**VOR (VHF Omnidirectional Range)**:
- Frequency: **108.00–117.95 MHz** (VHF band)
- Rotating antenna: 30 revolutions/second → provides 30 Hz AM signal
- Ground transmits fixed 30 Hz FM reference signal (same phase all directions)
- Phase difference between FM reference and AM signal = **magnetic bearing** from beacon
- Fixed frequency for most test sets: **108.00 MHz** (some also test at 112.80 MHz)

**ILS (Instrument Landing System)**:
- **Localizer**: runway centerline, VHF **108.10–111.95 MHz** (odd decimal channels)
- **Glide-slope**: descent path, paired UHF frequency
- Both use DDM (Difference in Depth of Modulation): 90 Hz and 150 Hz tones
  - **90 Hz dominant** = left of runway / above glide path
  - **150 Hz dominant** = right of runway / below glide path
  - DDM = 0 = on centerline/glide path
- **Marker beacons**: all on **75 MHz**
  - Outer marker: ~7 nm from threshold
  - Middle marker: ~0.5 nm from threshold
  - Different tone/code per marker

**ELT (Emergency Locator Transmitter)**:
- Self-contained, self-powered
- Activated by impact (g-switch) or manually from cockpit
- Transmits on international emergency frequencies

### VOR/ILS Test Set Features
- Fixed extendable antenna — most tests done with set standing in cockpit
- TO/FROM switch for checking indicator
- VOR bearing selector: 0° to 360°
- Output RF attenuator for receiver sensitivity tests
- Localizer DDM control (stepped)
- Glide-slope DDM control (stepped)
- Modulation switch (tone selection)

### VOR Ramp Test (Key Points)
- Test at 117.9 MHz; OBS set to 000°
- At 5° thumb wheel: HSI shows 1 DOT left (2 DOTS on 5-dot display)
- At 10°: HSI shows 2 DOTS/5 DOTS left
- Rotating 30 Hz VAR PHASE control fully CCW → LOC flag appears (invalid)

### Localizer Test (Key Points)
- Battery test voltage: ~15V acceptable; **<12V unacceptable**
- DDM 0.093 right → 60% of 2-dot deviation right
- DDM 0.155 right → 2 DOTS/5 DOTS right
- DDM 0.2 right → full-scale deflection right
- DDM = 90 → full-scale + LOC flag reappears
- 1020 Hz tone test for audio check

### Glide-Slope Test (Key Points)
- G/S paired frequency: 108.1 MHz LOC → 334.7 MHz G/S
- DDM 0.091 right → 1 DOT up (2.5 DOTS on 5-dot display)
- DDM 0.175 right → 2 DOTS/5 DOTS up
- DDM 0.4 right → full-scale deflection up
- DDM = 150 → full-scale + G/S flag appears

### Markers Test (Key Points)
- Marker frequency: **75 MHz**
- 400 Hz → outer marker (blue lamp)
- 1300 Hz → middle marker (amber lamp)
- 3000 Hz → inner marker (white lamp)
- HI/LO sensitivity switch test: increase 10 dB to illuminate on LOW sensitivity

### ELT Inspection
Three aspects to check:
1. **Battery**: no corrosion, approved type, **expiry date not passed**
2. **Activation**: test using applied force in indicated direction; can use wattmeter or VHF receiver on emergency frequency
3. **Signal strength**: test set placed ~**6 inches (15 cm)** from ELT antenna; audible signal heard in AM radio

---

## 7.4.5 FDR/CVR Operational Checks

**FDR** (Flight Data Recorder): records all aircraft system data correlated with flight parameters
**CVR** (Cockpit Voice Recorder): records all cockpit voice communications

Both are "black boxes" — designed to survive crashes (fire-resistant, impact-resistant)

### FDR Operational Check
Purpose: failure-finding task — verifies FDR is active and recording each parameter in normal range; verifies electrical interfaces

Key items:
- Control of recording tape (label check for date of last substitution)
- Substitution of recording tape

**Replace FDR tape when**:
- Less than **20 hours** remaining
- Tape used up, broken, or in use for **1 year**
- After heavy landing or high turbulence encounter

### CVR Operational Check
- Checks performed via cockpit microphone control panel
- Panel also allows erasure of previous recordings

---

## 7.4.6 Fuel Capacitance/Quantity Test Set

### Operating Principle
- Aircraft fuel gauging uses **capacitance measurement**
- Capacitor between plates filled with fuel, air, or both
- Capacitance value depends on **dielectric constant** of material between plates
- Total capacitance ∝ amount of fuel in tank
- Multiple tank units connected **in parallel** — compensates for attitude changes and fuel surging
- **Reference/compensating capacitor**: fully immersed in fuel — compensates for permittivity changes with different fuel specs

### Bridge Circuit
- Tank capacitance fed to **bridge rectifier circuit** (115V, 400 Hz)
- Bridge compares tank capacitance vs reference capacitance
- Unbalanced bridge → error signal → drives fuel quantity indicator
- Modern systems: signals fed to fuel quantity processor → corrected for density → digital display

### Test Set Capabilities
- Measure capacitance of single or multiple tank units
- Measure total capacitance of fuel probes + wiring
- Check compensating units
- Simulate capacitance to calibrate fuel quantity gauges
- Measure insulation resistance of tank units and wiring
- Fault diagnosis and isolation

Can also test: **oil and water** capacitive gauging systems (any AC capacitive fluid system)

---

## Key Exam Traps — Module 7.4

1. **Transponder receives on 1030 MHz, replies on 1090 MHz**
2. **DME measures SLANT distance** — error is maximum when directly overhead
3. **DME ground delay = 50 μs**
4. **TCAS scan range ≈ 15 nautical miles**
5. **Do NOT use 7500/7600/7700 transponder codes during testing**
6. **ILS: 90 Hz = left/above; 150 Hz = right/below**
7. **All marker beacons transmit on 75 MHz** — differentiated by code and tone
8. **Air data test: vent to atmosphere first; allow 5 min stabilization for accurate tests**
9. **FDR tape replacement: <20 hours remaining, or 1 year service, or after heavy landing**
10. **Fuel gauging uses capacitance** (not resistance or inductance)
11. **ELT battery check: no corrosion + approved type + not expired**
12. **Transponder antenna spacing ≈ 21 inches / 53.34 cm**

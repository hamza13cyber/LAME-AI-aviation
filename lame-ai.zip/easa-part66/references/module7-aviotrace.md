# Module 7 — Maintenance Practices (B2)
## Sources: Aviotrace Swiss Cat. B2 Ed. 31/07/2013, FAA AMT Handbook General (FAA-H-8083-30B)

---

## 7.1 Aircraft and Workshop Safety

### 7.1.1 Introduction
- Maintenance environment hazards: electrical, chemical, mechanical, fire, noise, radiation
- Personal Protective Equipment (PPE): mandatory per task
- MSDS/SDS (Material Safety Data Sheet): required for all chemicals on site

### 7.1.2 Safety Regulations
- EASA Part-145: AMO safety requirements
- COSHH (Control of Substances Hazardous to Health)
- Lockout/Tagout (LOTO): isolate energy before maintenance — install tag + lock
- Confined space entry: requires permit, atmospheric testing, standby person
- Working at height: harness, barriers, fall arrest systems

### 7.1.3 Gas and Cylinders
- **Colour coding** (EASA/European):
  - Oxygen: **White** body (never use with oil/grease → fire/explosion)
  - Nitrogen: **Black** body with black/white top (used for pressurisation tests)
  - CO₂: **Grey**
  - Compressed air: **Grey** body
- Storage: upright, chained/secured, away from heat sources
- Valve: open slowly, never force, always use correct regulator
- **Oxygen and oil = explosive hazard** — critical rule

### 7.1.4 Lubricants
- MIL-PRF-5606: mineral-based hydraulic fluid (red) — incompatible with 5606-free systems
- MIL-PRF-83282: synthetic, fire-resistant (red) — compatible with most seals
- Greases: MIL-PRF-23827 (general), MIL-G-81322 (wheel bearings)
- Oil: turbine engine oil (MIL-PRF-23699), piston engine (MIL-L-22851)
- Never mix different fluid types — seal/material compatibility critical

### 7.1.5 Hydraulic Fluids
- **Skydrol (purple)**: phosphate ester, fire-resistant — corrosive to skin and some metals
- **Mineral hydraulic fluid**: petroleum-based, red colour
- Never mix Skydrol with mineral fluid — incompatible seals
- Skydrol spill: wash immediately, neutralise with sodium bicarbonate

### 7.1.6 Chemical Substances
- Chromate primers: carcinogenic — use respirator, gloves, do not sand dry
- MEK (Methyl Ethyl Ketone): degreasing, highly flammable
- Adhesives and sealants: pot life and cure time critical — temperature and humidity affect cure
- Proper disposal: hazardous waste regulations

### 7.1.7 Safety Signs (ISO 7010)
- **Red**: prohibition (circle with bar — no smoking, no entry)
- **Yellow/Amber**: warning/caution (triangle — hazard present)
- **Blue**: mandatory (circle — must wear PPE)
- **Green**: safe condition (rectangle — first aid, exit)

### 7.1.9 Fires
Fire triangle: **Fuel + Oxygen + Heat** — remove any one to extinguish

| Class | Type | Extinguisher |
|-------|------|-------------|
| A | Solids (wood, paper, fabric) | Water, CO₂, foam, dry powder |
| B | Liquids (fuel, oil, paint) | CO₂, foam, dry powder (NOT water) |
| C | Gas (LPG, hydrogen) | Dry powder, CO₂ (shut off supply first) |
| D | Metals (magnesium, titanium) | Dry sand/special powder (NOT water) |
| E/F | Electrical | CO₂, dry powder (NOT water or foam) |

**Aircraft fires**: most use Halon (BCF) — being phased out for HFCs. CO₂ also common.

---

## 7.2 Workshop Practices

### 7.2.3 Calibration of Tools and Equipment
- All measuring tools must be calibrated at specified intervals
- Calibration label: shows date, next due date, certificate number
- Calibration standards: traceable to national/international standards (BIPM)
- Out-of-calibration tool: must be removed from service immediately, work done may need re-inspection
- Torque wrenches: calibrate every 12 months or after overload/drop

### 7.2.5 Dimensions for Workmanship
- SI units used in EASA documentation
- Imperial units (inches, pounds) still common in US-origin documents
- Mixed unit awareness critical to avoid errors

---

## 7.3 Tools

### 7.3.1 Common Hand Tools
**Torque Wrenches**:
- **Click type**: preset torque, click when reached — most common
- **Beam type**: pointer indicates torque on scale
- **Digital**: electronic display
- **Dial indicator type**: reads directly from dial face
- Apply torque smoothly and steadily — do not jerk
- Torque values from AMM, always in specific units (Nm, lb·in, lb·ft)

**Screwdrivers**:
- Flathead, Phillips, Pozidriv, Torx, Frearson — match head type exactly
- Never substitute — stripped heads are a maintenance defect

**Pliers/Cutters**:
- Slip-joint, needle-nose, locking (Vise-Grip), diagonal cutters
- Safety wire pliers: for twisting safety wire

**Files**: coarseness — bastard (coarse), second cut (medium), smooth (fine)
- Never use without handle

### 7.3.3 Precision Measuring Tools
**Vernier Caliper**:
- Reads to **0.02 mm** (or 0.001 inch)
- Measures: OD, ID, depth, step
- Zero check before use

**Micrometer (Outside)**:
- Reads to **0.01 mm** (or 0.0001 inch with vernier)
- Anvil, spindle, sleeve, thimble, ratchet
- Calibrate with gauge blocks; check zero with standard

**Dial Gauge (Test Indicator)**:
- Reads to 0.01 mm or 0.001 inch
- Used for: runout, flatness, bore measurement, valve clearance

**Feeler Gauge**:
- Set of blades for gap measurement
- Use: valve clearances, spark plug gaps, bearing clearances

### 7.3.4 Lubrication Equipment
- Grease guns: cartridge, bulk, pistol type
- Apply per AMM specification — over-greasing as harmful as under-greasing
- Oil can / pressure oilers for specific points
- Lube charts must be followed per schedule

### 7.3.5 Electrical General Test Equipment
**Multimeter (DMM)**:
- Measures: DC/AC voltage, current, resistance, continuity, diode
- Never measure resistance in live circuit
- Set correct range before connecting

**Oscilloscope**:
- Displays waveform shape vs time
- Measures: frequency, period, amplitude, phase
- Used for: signal analysis, troubleshooting avionics

**Insulation Resistance Tester (Megger)**:
- Tests insulation integrity — applies high voltage (250V, 500V, 1000V)
- Minimum acceptable reading: typically **1 MΩ** minimum per EASA standards
- Do not megger connected components — disconnect first

**Continuity Tester**: simple go/no-go for wire breaks

---

## 7.5 Engineering Drawings, Diagrams and Standards

### 7.5.1 Drawing Types
- **Detail drawing**: single part, fully dimensioned
- **Assembly drawing**: shows how parts fit together
- **Installation drawing**: how assembly installs in aircraft
- **Schematic diagram**: function/logic, not physical location
- **Block diagram**: system overview, signal flow
- **Wiring diagram**: actual wire routing and connections

### 7.5.7 ATA 100 / ATA iSpec 2200
- Standard chapter numbering for aircraft documentation
- Examples:
  - **ATA 21**: Air Conditioning
  - **ATA 24**: Electrical Power
  - **ATA 27**: Flight Controls
  - **ATA 29**: Hydraulic Power
  - **ATA 31**: Instruments
  - **ATA 32**: Landing Gear
  - **ATA 34**: Navigation
  - **ATA 36**: Pneumatic
  - **ATA 51**: Structures
  - **ATA 71**: Power Plant
- AMM, IPC, SRM all reference ATA chapters

---

## 7.6 Fits and Clearances

### Manufacturing Tolerances
- **Tolerance**: permissible variation in a dimension
- **Clearance fit**: shaft smaller than hole (running/sliding fits)
- **Interference fit** (press fit): shaft larger than hole — requires force/heat to assemble
- **Transition fit**: may be either clearance or interference

### Precision Measurement
- **Gauge blocks**: primary calibration standard
- **Plug gauges**: GO / NO-GO for hole diameters
- **Ring gauges**: for shaft diameters

---

## 7.7 Electrical Wiring Interconnection System (EWIS)

### 7.7.1 Continuity Testing
- Check for breaks in conductors
- Use low-voltage continuity tester or DMM on resistance setting
- Bell out: trace wire from end to end confirming connection

### 7.7.2 Insulation Testing
- Megger test: detects insulation breakdown
- Minimum: **1 MΩ** (typically higher per aircraft standard)
- Temperature affects readings: correct for temperature per charts

### 7.7.3 Bonding
- Purpose: prevent static buildup, provide return path, reduce EMI
- Bonding lead resistance: typically **<0.005 Ω** (5 mΩ) maximum
- Test with bonding tester (low-resistance ohmmeter, milliohm range)
- Inspect: secure connections, no corrosion, adequate cross-section

### 7.7.4 Crimp Tools
- Use correct die for wire gauge and connector type
- M22520 series tooling for mil-spec connectors
- Calibrated crimp tool required — uncalibrated tool = unacceptable
- Setting: per wire gauge and insulation OD

### 7.7.5 Testing Crimp Joints
- Pull test: minimum force specified per gauge (e.g., 16 AWG = ~50 lbf)
- Visual: no exposed conductor, no insulation trapped, correct insertion depth
- Resistance test: low resistance through joint

### 7.7.8 Wire Types and Identification
- **AWG** (American Wire Gauge): lower number = thicker
  - Common aircraft: 22, 20, 18, 16, 14, 12, 10, 8, 4, 2, 1/0
- Wire marking: every 380mm (15 inches) — FROM/TO connector designation
- High-temp wires: PTFE, Kapton insulation (avionics bays, engines)
- Coaxial: for RF signals — cannot be repaired, must replace

### 7.7.9 Wiring Inspection
- Chafing against structure: most common defect
- Minimum bend radius: typically 10× wire OD
- Separation from hot pipes/fluid lines: per AMM
- Approved repairs only — splice kits per aircraft standards

### 7.7.10 Wiring Protection
- Conduit: rigid (metallic) or flexible
- Clamps: proper spacing (every 400–600mm typically)
- Sleeving: heat-shrink or braided for protection
- Routing away from: hot zones, sharp edges, control cables

### 7.7.11 EWIS Inspection Criteria (from EASA/FAA AC 25.1701)
- Age-related degradation: insulation cracking, brittleness
- Arc tracking: carbon deposits along insulation surface
- Moisture ingress in connectors: clean with approved solvents
- Contamination: fuel, hydraulic fluid on wiring = deterioration hazard

---

## 7.15 Welding, Brazing, Soldering and Bonding

### 7.15.3 Soldering
- **Soft solder**: tin-lead or lead-free (RoHS), melting point ~180–220°C
- Flux: removes oxides, prevents re-oxidation during heating
- Aircraft solder: 60/40 or 63/37 tin-lead (not lead-free for most aviation)
- **Good joint**: shiny, concave fillet, smooth surface
- **Cold (dry) joint**: dull, grainy, rough — high resistance → unacceptable

### 7.15.4 Soldering Inspection
- Visual: shiny, complete coverage, correct shape
- Pull test where applicable
- Insulation undamaged by heat
- No solder bridges between adjacent pads

---

## 7.16 Aircraft Weight and Balance

### 7.16.1 Centre of Gravity
- **Datum**: reference point from which all measurements taken (often forward tip of fuselage or nose)
- **Arm**: horizontal distance from datum to item
- **Moment**: weight × arm
- **CG**: total moment ÷ total weight
- CG must remain within published forward and aft limits at all times

### 7.16.2 Moment Calculation
- Moment = Weight (kg or lb) × Arm (m or inches)
- Example: 80 kg passenger at 3.5m arm = 280 kg·m moment
- Total CG = Sum of moments / Total weight

### 7.16.4 Weighing Procedure
1. Aircraft in rigging position (level per levelling points)
2. Standard weighing: fuel tanks empty OR full to tabs (per manual)
3. Scales at each gear (nose or tailwheel + mains)
4. All doors, panels, access covers installed as per BEW definition
5. Subtract tare weight of equipment
6. Calculate: BEW (Basic Empty Weight) + CG arm

### 7.16.6 Effect of Incorrect CG
- **Too far forward**: nose-heavy, controls feel heavy, excessive trim drag, may limit nose-up authority
- **Too far aft**: tail-heavy, reduced stability, risk of unrecoverable pitch-up, most dangerous

---

## 7.17 Aircraft Handling and Storage

### 7.17.1 Taxiing Safety
- Follow ground controller instructions
- Wingtip clearances: walkers required in tight areas
- Maximum taxi speed limits per AOM
- No-taxi zones during engine run

### 7.17.2 Towing
- Tow bar limits: max angle before nosewheel overrun — mark on aircraft
- Tow speed: walking pace (typically <5 mph/8 km/h)
- Ground crew: minimum 2 persons (driver + wing walkers)
- Anti-rotation pin or bypass pin for nosewheel steering
- Brakes: must work before towing begins

### 7.17.3 Jacking
- Three-point jacking: nose and two main jack points (or tail)
- Jack pads: correct fit, prevent slipping
- Safety lock: jack collar/safety lock engaged once at height
- Maximum wind speed for jacking: typically 35 kts (check AMM)
- Keep as low as possible for safety

### 7.17.4 Chocking and Securing
- Chocks: placed fore and aft of main gear wheels
- Mooring: nose and main gear tie-down rings
- Control locks: elevator, aileron, rudder locked when parked
- Pitot covers, static port covers, intake blanks: installed

### 7.17.5 Storage
- **Short-term** (up to 30 days): engine preservation oil, pitot/static covers
- **Long-term** (>30 days): dehumidifiers, special engine preservation, corrosion inhibitor in fuel
- Hangar storage preferred; outdoor: corrosion protection required

### 7.17.6 Refuelling/Defuelling
- Bonding: ground aircraft to refuel vehicle before opening caps
- No ignition sources within 15m (50ft) of fuel vent outlets
- Fuel type: check placard AND delivery note match
- Defuel: depressurize fuel system first, drain per manual

### 7.17.7 De-icing/Anti-icing
- **De-icing** (Type I fluid): removes existing ice/snow — orange, unthickened
- **Anti-icing** (Type II, III, IV): prevents re-freezing — thickened, green/colourless
- **Holdover time**: max time anti-ice fluid effective before re-application needed
- Clean aircraft principle: no ice/snow on critical surfaces before departure
- Check all control surface gaps after de-icing

### 7.17.8 Ground Power
- External power: GPU (Ground Power Unit) — check voltage/frequency before connecting
- 28V DC or 115V AC / 400 Hz depending on aircraft
- Hydraulic ground power: check fluid compatibility before connecting
- Pneumatic: ground cart or APU bleed

---

## 7.18 Disassembly, Inspection, Repair and Assembly

### 7.18.1 Types of Defects
- **Crack**: most serious — requires immediate action, may propagate
- **Corrosion**: surface, pitting, intergranular, exfoliation, galvanic, stress corrosion
- **Dent**: assess depth, area, location — limits in SRM
- **Scratch**: assess depth relative to skin thickness
- **Delamination** (composites): detect by coin tap, ultrasonic, or thermography

### 7.18.2 Visual Inspection
- Adequate lighting: minimum 500 lux per EASA (1000 lux for NDT)
- Magnifying glass: 10× for small defects
- Mirrors, borescope for inaccessible areas
- Cleanliness: surfaces must be clean before inspection

### 7.18.3 Corrosion
**Types**:
- **Surface corrosion**: uniform oxidation — general surface attack
- **Pitting corrosion**: localised pits — common on aluminium
- **Intergranular**: along grain boundaries — hard to detect visually
- **Exfoliation**: layer separation — visible as blistering/peeling
- **Galvanic corrosion**: dissimilar metals in contact with electrolyte
- **Stress corrosion**: combination of tensile stress and corrosive environment
- **Fretting corrosion**: micro-movement between mating surfaces

**Treatment**:
1. Clean and strip protective coating
2. Assess severity (light, moderate, severe per SRM)
3. Remove: mechanical (scotch brite, abrasive), chemical (alodine/chromate)
4. Treat: apply inhibitor (alodine, zinc chromate primer)
5. Re-protect: prime and topcoat

**Prevention**: proper drainage, sealants, dissimilar metal isolation

### 7.18.5 Non-Destructive Testing (NDT) Techniques

| Method | Detects | Principle | Limitations |
|--------|---------|-----------|------------|
| **Visual (VT)** | Surface defects | Direct observation / optical aids | Surface only |
| **Dye Penetrant (PT)** | Surface cracks | Capillary action of fluorescent/visible dye | Non-porous surfaces only |
| **Magnetic Particle (MT)** | Surface/near-surface cracks | Magnetic field disrupted by defects | Ferromagnetic metals only |
| **Eddy Current (ET)** | Surface/near-surface cracks, thickness, conductivity | Induced electrical currents disrupted by defects | Conductive metals only |
| **Ultrasonic (UT)** | Subsurface cracks, bonding, thickness | Sound wave reflection/attenuation | Needs couplant, skilled operator |
| **Radiography (RT)** | Subsurface defects, assembly errors | X-ray/gamma-ray absorption | Radiation hazard, slow |
| **Thermography** | Delamination in composites | Heat diffusion patterns | |

**Dye Penetrant Procedure** (6 steps):
1. Pre-clean surface (solvent or vapour degrease)
2. Apply penetrant (dwell time per spec — 10–30 min typically)
3. Remove excess penetrant
4. Apply developer (dry or wet)
5. Inspect (UV light for fluorescent, white light for visible)
6. Post-clean

### 7.18.6 Disassembly/Reassembly
- Always follow AMM sequence
- Mark components before removal (orientation, position)
- Safety precautions: systems depressurized, electrical isolated
- Preserve threaded holes: clean, lubricate per spec
- Reassembly: correct torque, safety devices, function check

### 7.18.7 Troubleshooting
- Systematic approach: confirm fault → identify possible causes → test → isolate → rectify → verify
- Use FCOM, AMM, FIM (Fault Isolation Manual)
- BITE (Built-In Test Equipment): check BITE codes first
- Do not assume — verify with test equipment

---

## 7.19 Abnormal Events

### 7.19.1 Lightning Strike Inspection
After lightning strike:
- Inspect entry/exit points: burning, pitting, discolouration
- Check composite panels: de-lamination, disbonding
- Inspect: antennas, static dischargers, navigation lights
- Check avionics: BITE test all systems, check for false memory
- Fuel system check: vent caps, probes, bonding
- Document all findings

### 7.19.2 HIRF
- High Intensity Radiated Fields from external sources (radar, TV, radio)
- Post-HIRF inspection: check for induced faults, run BITE

---

## 7.20 Maintenance Procedures

### 7.20.1 Maintenance Planning
**Scheduled maintenance checks**:
- **A Check**: ~500 FH, overnight — visual inspection, fluid checks, minor repairs
- **B Check**: ~1000 FH (often combined with A)
- **C Check**: ~18–24 months, 2–6 weeks — extensive structural inspection
- **D Check (Heavy Maintenance)**: ~6–12 years, complete overhaul, strip paint

**Documentation types**:
- **AMM**: step-by-step procedures
- **MPD**: planned tasks and intervals
- **CMM**: component overhaul
- **SRM**: structural repairs
- **IPC**: illustrated parts catalogue
- **SB** (Service Bulletin): manufacturer recommendation
- **AD** (Airworthiness Directive): mandatory, regulatory

### 7.20.4 Certification / Release to Service
- **CRS (Certificate of Release to Service)**: mandatory before return to service
- Issued by: authorised certifying staff (Part-66 B1/B2 licence holder)
- Contains: aircraft/component identity, work scope, regulation reference, date, licence number
- **EASA Form 1**: for components (equivalent to FAA 8130-3)
- Incomplete maintenance: must be documented, deferred items on MEL

---

## Key Exam Traps — Module 7

1. **Oxygen + oil = fire/explosion** — never use oil/grease with oxygen
2. **Class D fire (metals)** = dry sand/special powder — NEVER water
3. **Calibration tool out of date**: remove from service + review all work done
4. **Torque wrench**: calibrate every 12 months or after overload
5. **Bonding resistance**: typically **<5 mΩ** (<0.005 Ω)
6. **Megger minimum**: typically **1 MΩ** insulation resistance
7. **CG too far aft** = most dangerous — may become uncontrollable
8. **Tow speed** = walking pace only (~5 mph max)
9. **Type I de-icing = orange** (unthickened); Type IV = green (thickened, longest holdover)
10. **Dye penetrant**: only works on **non-porous surfaces** (not on composites normally)
11. **Magnetic particle**: only **ferromagnetic metals** (not aluminium, titanium, composites)
12. **Eddy current**: only **conductive metals**
13. **Cold solder joint**: dull/grainy = high resistance = reject
14. **EASA Form 1** = component release; CRS = aircraft release
15. **AWG wire**: lower number = **thicker** wire

# Module 5 — Digital Techniques & Electronic Instrument Systems (B2)
## Source: Aviotrace Swiss Cat. B2, Edition 31/07/2014 Rev. 02

---

## 5.1 Electronic Instrument Systems

### 5.1.1 Typical Arrangements and Layouts
- EFIS (Electronic Flight Instrument System): replaces traditional analogue instruments
- Components: EADI (Electronic Attitude Director Indicator), EHSI (Electronic Horizontal Situation Indicator), Symbol Generator, Display Control Panel
- ECAM (Electronic Centralized Aircraft Monitor) — Airbus: monitors aircraft systems, displays warnings, synoptic pages
- EICAS (Engine Indication and Crew Alerting System) — Boeing: primary + secondary engine displays
- FMS (Flight Management System): combines navigation, performance, and guidance
- ACARS (Aircraft Communications Addressing and Reporting System): digital datalink

---

## 5.2 Numbering Systems

### 5.2.1 Binary, Octal, Hexadecimal
- **Binary**: base 2 (0,1) — used in all digital systems
- **Octal**: base 8 (0–7) — groups of 3 binary digits
- **Hexadecimal**: base 16 (0–9, A–F) — groups of 4 binary digits
- **BCD** (Binary Coded Decimal): each decimal digit encoded in 4 bits
- **Gray code**: only 1 bit changes between adjacent values — used in encoders, shaft position sensors

### 5.2.2 Conversions
- Decimal → Binary: repeated division by 2
- Binary → Hex: group bits in fours from right
- Binary → Octal: group bits in threes from right

### 5.2.2 Arithmetic Operations
- **Two's complement**: method for representing negative binary numbers
  - Invert all bits (one's complement) then add 1
  - Allows subtraction using addition circuits
- **Overflow**: result exceeds available bit width
- **Floating point**: IEEE 754 — sign bit, exponent, mantissa

---

## 5.3 Data Conversion

### 5.3.1 Analog vs Digital
- Analogue: continuous signal, infinite resolution but susceptible to noise
- Digital: discrete levels, more noise-immune, easier to process/store

### 5.3.2 ADC / DAC
**ADC (Analogue to Digital Converter)**:
- Process: Sampling → Quantization → Encoding
- **Nyquist theorem**: sampling rate ≥ 2 × highest signal frequency (fs ≥ 2fmax)
- **Aliasing**: distortion caused by insufficient sampling rate
- Resolution: determined by number of bits (n bits = 2ⁿ levels)
- Types: successive approximation (most common in avionics), flash, sigma-delta

**DAC (Digital to Analogue Converter)**:
- Types: R-2R ladder network (most common), binary weighted resistor
- Errors: offset error, gain error, non-linearity, missing codes

**Key values to remember**:
- 8-bit ADC → 256 levels
- 12-bit ADC → 4096 levels
- 16-bit ADC → 65536 levels

---

## 5.4 Data Buses

### ARINC 429
- Standard for commercial aircraft data transmission
- **Unidirectional**: ONE transmitter, up to 20 receivers
- **Speed**: Low speed = 12.5 kbps, High speed = 100 kbps
- 32-bit word: Label (8 bits) + SDI (2 bits) + Data (19 bits) + SSM (2 bits) + Parity (1 bit)
- Differential signal (twisted pair): +10V / -10V / 0V (null)
- Used on: A320, B737, B747, most commercial aircraft

### ARINC 629
- Used on **Boeing 777 only**
- **Bidirectional**: multiple transmitters and receivers
- Speed: 2 Mbps
- Current mode coupling (no direct electrical connection)

### MIL-STD-1553
- Military standard
- **Bidirectional**: Bus Controller + Remote Terminals + Bus Monitor
- Speed: 1 Mbps
- Uses transformer coupling

### AFDX (ARINC 664 Part 7)
- **Avionics Full DupleX switched Ethernet**
- Based on Ethernet (100 Mbps)
- **Bidirectional**, switched network
- Virtual links with guaranteed bandwidth
- Used on: A380, A350, B787

### CAN Bus
- Controller Area Network
- Up to 1 Mbps
- Multi-master, collision detection (CSMA/CD)
- Common in automotive; some aircraft secondary systems

### COMPARISON TABLE
| Bus | Speed | Direction | Aircraft |
|-----|-------|-----------|---------|
| ARINC 429 | 12.5/100 kbps | Unidirectional | Most commercial |
| ARINC 629 | 2 Mbps | Bidirectional | B777 |
| MIL-STD-1553 | 1 Mbps | Bidirectional | Military |
| AFDX | 100 Mbps | Bidirectional | A380, A350, B787 |

---

## 5.5 Logic Circuits

### 5.5.A.1 Common Logic Gates
| Gate | Symbol | Function | Truth Table |
|------|--------|----------|-------------|
| AND | • | Output = 1 only if ALL inputs = 1 | 0·0=0, 0·1=0, 1·1=1 |
| OR | + | Output = 1 if ANY input = 1 | 0+0=0, 0+1=1, 1+1=1 |
| NOT | ¬ | Inverts input | 0→1, 1→0 |
| NAND | (AND+NOT) | Universal gate | Opposite of AND |
| NOR | (OR+NOT) | Universal gate | Opposite of OR |
| XOR | ⊕ | Output = 1 if inputs DIFFERENT | 0⊕0=0, 0⊕1=1, 1⊕1=0 |
| XNOR | | Output = 1 if inputs SAME | Opposite of XOR |

**Universal gates**: NAND and NOR can each implement any Boolean function

### De Morgan's Theorems
- `NOT(A AND B)` = `(NOT A) OR (NOT B)` → NAND = inverted AND
- `NOT(A OR B)` = `(NOT A) AND (NOT B)` → NOR = inverted OR

### 5.5.A.2 Applications in Aircraft
- Landing gear warning logic (squat switches, throttle position)
- Fire detection voting circuits (2-of-3 logic)
- FADEC (Full Authority Digital Engine Control) protection logic

### 5.5.B.1 Sequential Logic / Flip-Flops
- **SR flip-flop**: Set-Reset. Invalid state: S=R=1
- **D flip-flop**: Data/Delay. Output follows D on clock edge
- **JK flip-flop**: Eliminates SR invalid state. J=K=1 → toggle
- **T flip-flop**: Toggle. Used in binary counters

**Registers**:
- SIPO (Serial In Parallel Out)
- PISO (Parallel In Serial Out)
- SISO (Serial In Serial Out) — shift register / delay line

**Counters**:
- **Ripple (asynchronous)**: output of one FF clocks the next. Simple but slow (propagation delay accumulates)
- **Synchronous**: all FFs clocked simultaneously. Faster, more complex

---

## 5.6 Basic Computer Structure

### 5.6.B.1 Computer Terminology
- **CPU**: Central Processing Unit — ALU + Control Unit
- **ALU**: Arithmetic Logic Unit — performs calculations and logic
- **RAM**: Random Access Memory — volatile, read/write
- **ROM**: Read Only Memory — non-volatile (EPROM, EEPROM, Flash)
- **Bus**: shared communication path — Address bus, Data bus, Control bus
- **Cache**: fast memory between CPU and RAM

### 5.6.B.2 Microcomputer Layout
- Address bus: unidirectional, CPU selects memory location
- Data bus: bidirectional, carries actual data
- Control bus: read/write signals, interrupt signals, clock

---

## 5.7 Microprocessors

### 5.7.1 Functions
- Fetch instruction from memory
- Decode instruction
- Execute instruction (ALU operation or data move)
- Increment program counter

### 5.7.2 Microprocessor Elements
- **Control Unit**: sequences operations, generates control signals
- **Clock Generator**: synchronizes all operations (MHz/GHz frequency)
- **Instruction Decoder**: interprets opcode, determines action
- **ALU**: ADD, SUB, AND, OR, XOR, shifts, comparisons
- **Registers**: temporary storage inside CPU (accumulator, index, stack pointer, program counter)

---

## 5.8 Integrated Circuits

### 5.8.1 Encoders and Decoders
- **Encoder**: converts multiple inputs to binary code output (2ⁿ inputs → n outputs)
- **Decoder**: converts binary code to individual outputs (n inputs → 2ⁿ outputs)
- **Priority encoder**: if multiple inputs active, highest priority wins

### 5.8.2 Encoder Types
- **Mechanical**: shaft encoder (uses Gray code to avoid glitches)
- **Optical**: light interrupted by rotating disc
- **Magnetic**: Hall effect sensors

### 5.8.3 Integration Scales
- SSI: Small Scale Integration (<10 gates)
- MSI: Medium Scale Integration (10–100 gates)
- LSI: Large Scale Integration (100–10,000 gates)
- VLSI: Very Large Scale Integration (>10,000 gates) — modern processors

---

## 5.9 Multiplexing

### 5.9.1 Operation and Application
- **Multiplexer (MUX)**: many inputs, one output — selects one input based on select lines
- **Demultiplexer (DEMUX)**: one input, many outputs — routes to selected output
- **Purpose in aircraft**: reduce wiring weight, share transmission medium

**Types**:
- TDM (Time Division Multiplexing): time slots allocated to each channel
- FDM (Frequency Division Multiplexing): different frequency bands

---

## 5.10 Fiber Optics

### 5.10.1 Advantages vs Electrical Wire
**Advantages**:
- Immune to EMI/RFI
- Lightweight, smaller diameter
- High bandwidth (GHz)
- No electrical sparks — safe near fuel
- Secure (difficult to tap)
- No ground loops

**Disadvantages**:
- Fragile (bend radius must be respected)
- Difficult to repair in field
- More expensive connectors
- Cannot carry electrical power

### 5.10.2 Fiber Optic Data Bus
- Core (glass/plastic) surrounded by cladding (lower refractive index)
- Total internal reflection keeps light inside core
- **Single-mode**: thin core (~9 μm), long distance, higher bandwidth
- **Multi-mode**: larger core (~50–62.5 μm), shorter distance, easier to connect

### 5.10.3 Key Terms
- **Attenuation**: signal loss per unit length (dB/km)
- **Numerical Aperture (NA)**: acceptance angle for light entry
- **Dispersion**: pulse broadening over distance

### 5.10.4 Terminations
- Connectors: ST (push-twist), SC (push-pull), LC (small form factor)
- Cleaving: clean cut required for low-loss splice

### 5.10.5 Couplers and Terminals
- **Coupler**: splits or combines optical signals
- **Control terminal**: processes and routes data
- **Remote terminal**: end-device on the bus

### 5.10.6 Aircraft Applications
- AFDX backbone on A380/B787
- Fly-by-light (experimental)
- Avionics bay interconnects
- Entertainment systems

---

## 5.11 Electronic Displays

### 5.11.1 Display Types
**CRT (Cathode Ray Tube)**:
- Electron gun, deflection plates/coils, phosphor screen
- High voltage required (>10kV), heavy, bulky
- Older EFIS systems (1980s–1990s)

**LED (Light Emitting Diode)**:
- Semiconductor p-n junction emits light when forward biased
- Low power, long life, fast response
- Used in backlighting, annunciators

**LCD (Liquid Crystal Display)**:
- Liquid crystals between polarizing filters, backlit by LEDs
- Low power, flat, lightweight
- Standard on modern glass cockpit displays
- Passive vs Active matrix (TFT = Thin Film Transistor — active, better response)

**OLED** (modern):
- Self-illuminating, no backlight needed
- Better contrast ratio than LCD

---

## 5.12 Electrostatic Sensitive Devices (ESD)

### 5.12.1 Special Handling
- CMOS, FET, and MOSFET devices are most sensitive
- ESD damage can occur at voltages below human perception:
  - Human feels static at ~3,000 V
  - CMOS damage can occur at **<100 V**
- **Label**: yellow triangle with hand symbol

### 5.12.2 Anti-Static Protection
**Equipment**:
- Wrist strap (1 MΩ resistor in series for safety)
- ESD mat (conductive, grounded)
- ESD bag/packaging (silver/pink conductive)
- Ionizer (neutralizes charge in area)

**Procedures**:
- Always ground yourself before handling
- Keep components in ESD packaging until needed
- Avoid synthetic clothing on the job
- Do not touch component pins directly
- Store in conductive foam or trays

---

## 5.13 Software Management Control

### 5.13.1 DO-178B / DO-178C Software Levels
Failure condition → Software Level:

| Level | Failure Condition | Verification Required |
|-------|------------------|-----------------------|
| A | **Catastrophic** | Maximum rigor — independent review |
| B | **Hazardous** | High rigor |
| C | **Major** | Moderate rigor |
| D | **Minor** | Basic rigor |
| E | **No safety effect** | No specific requirements |

**DO-254**: Hardware equivalent of DO-178 (for FPGAs, ASICs)

**Key principle**: Unauthorized software changes to airborne systems can have catastrophic consequences. Only EASA-approved software modifications are permitted.

---

## 5.14 Electromagnetic Environment

### 5.14.1 EMC, EMI, HIRF, Lightning

**EMC** (Electromagnetic Compatibility): ability to function without interference

**EMI** (Electromagnetic Interference):
- Conducted: travels through wires
- Radiated: travels through air
- Mitigation: shielding, filtering, bonding, separation, twisted pairs

**HIRF** (High Intensity Radiated Fields):
- From ground radar, TV stations, radio transmitters
- Aircraft must be certified to operate in HIRF environment
- Metallic fuselage provides natural shielding
- Composite aircraft need added shielding (conductive mesh)

**Lightning protection**:
- Aircraft is designed as a Faraday cage
- Current path: strike point → fuselage → exit point
- Static dischargers: prevent charge buildup on trailing edges
- Equipment protected by surge suppressors and filters

**Bonding**: electrically connecting metal parts to provide common ground, prevent sparks

---

## 5.15 Typical Electronic/Digital Aircraft Systems

### 5.15.1 ACARS (Aircraft Communications Addressing and Reporting System)
- Digital datalink between aircraft and ground stations/airline operations
- Uses VHF, HF, or SATCOM
- Transmits: OOOI times (Out-Off-On-In), fuel reports, maintenance data
- ARINC 724B standard

### 5.15.2 Other Digital Systems
- **FMS**: navigation database, performance calculation, route management
- **TCAS**: see Module 7.4 — aircraft-to-aircraft interrogation via Mode S transponder
- **EGPWS** (Enhanced Ground Proximity Warning System): uses GPS + terrain database
- **ADS-B** (Automatic Dependent Surveillance–Broadcast): GPS position transmitted to ATC and other aircraft (1090 MHz)
- **BITE** (Built-In Test Equipment): self-test capability in LRUs

---

## Key Exam Traps — Module 5

1. **ARINC 429 is UNIDIRECTIONAL** — one transmitter only
2. **ARINC 629 is BIDIRECTIONAL** — B777 only
3. **DO-178B Level A = Catastrophic** (most critical, most testing required)
4. **Nyquist**: sampling must be ≥ 2× signal frequency
5. **ESD damage** occurs BELOW human perception threshold
6. **Gray code** = only 1 bit changes between adjacent values
7. **NAND/NOR** are universal gates — can build any function
8. **JK flip-flop** eliminates invalid state of SR flip-flop
9. **AFDX** is Ethernet-based — used A380, A350, B787
10. **Single-mode fiber** = thin core, long distance; **multi-mode** = thick core, short distance

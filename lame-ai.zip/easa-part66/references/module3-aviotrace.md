# Module 3 — Electrical Fundamentals (B2)
## Source: Aviotrace Swiss Cat. B2, Edition 29/10/2010 Rev. 00

---

## 3.1 Electron Theory
- Atom: nucleus (protons+neutrons) + electrons in shells
- Valence electrons determine conductivity
- **Conductors**: 1–3 valence electrons (copper, aluminium, silver)
- **Insulators**: 5–8 valence electrons (glass, rubber, teflon)
- **Semiconductors**: 4 valence electrons (silicon, germanium)
- Ions: atoms that have gained or lost electrons (positive/negative charge)

---

## 3.2 Static Electricity
- Static charge builds by friction (triboelectric effect)
- Like charges repel, unlike charges attract
- **Coulomb's Law**: F = k·Q₁·Q₂/r² — force between charges
- Unit of charge: **Coulomb (C)**
- Electrostatic discharge (ESD) — hazard to electronics

---

## 3.3 Electrical Terminology
| Term | Symbol | Unit | Definition |
|------|--------|------|------------|
| Voltage (EMF) | V or E | Volt (V) | Electromotive force / potential difference |
| Current | I | Ampere (A) | Flow of charge (coulombs/second) |
| Resistance | R | Ohm (Ω) | Opposition to current flow |
| Power | P | Watt (W) | Rate of energy consumption |
| Energy | W | Joule (J) | Power × Time |

---

## 3.4 Generation of Electricity
Methods of producing EMF:
- **Light**: photovoltaic (solar) cells
- **Heat**: thermocouples (Seebeck effect) — used in EGT measurement in aircraft
- **Friction**: triboelectric (static)
- **Pressure**: piezoelectric effect (crystal microphones, knock sensors)
- **Chemical**: batteries and cells
- **Magnetism + Motion**: generators (most common in aircraft)

---

## 3.5 DC Sources of Electricity

### Primary Cells (non-rechargeable)
- Chemical energy → electrical energy (irreversible)
- Example: zinc-carbon, alkaline

### Secondary Cells (rechargeable)
**Lead-Acid Battery**:
- Plates: lead (Pb) and lead dioxide (PbO₂) in dilute sulphuric acid
- Nominal cell voltage: **2V** (6-cell = 12V)
- Specific gravity of electrolyte: **1.265–1.280** (fully charged)
- Discharged state: ~1.15 (both plates become lead sulphate)
- Precaution: produces **hydrogen gas** during charging → ventilation required

**Nickel-Cadmium (NiCd)**:
- Plates: nickel hydroxide and cadmium in **potassium hydroxide (KOH)** electrolyte
- Nominal cell voltage: **1.2V**
- More stable discharge curve than lead-acid
- Used in aircraft: start batteries, emergency systems
- **Memory effect** if not fully discharged before recharging
- Electrolyte level checked with distilled water only

**Thermocouples**:
- Two dissimilar metals joined — produce voltage proportional to temperature difference
- Aircraft use: EGT (Exhaust Gas Temperature), CHT
- Common types: chromel-alumel (K-type), iron-constantan (J-type)

**Photo-cells**: light → current (solar panels, light sensors)

### Cells in Series and Parallel
- **Series**: voltages add, capacity (Ah) stays same
- **Parallel**: voltages stay same, capacity adds

### Internal Resistance
- Reduces terminal voltage under load
- Terminal voltage = EMF − (I × r_internal)
- Higher current draw → greater voltage drop

---

## 3.6 DC Circuits

### Ohm's Law
**V = I × R** (and rearrangements: I = V/R, R = V/I)

### Kirchhoff's Laws
**KVL** (Voltage): Sum of voltages around any closed loop = 0
**KCL** (Current): Sum of currents entering a node = sum leaving

### Calculations
- Series circuit: same current, voltages add, resistances add
- Parallel circuit: same voltage, currents add, use reciprocal formula for resistance

---

## 3.7 Resistance/Resistor

### Factors Affecting Resistance
R = ρ·L/A where:
- ρ = resistivity of material
- L = length (longer = more resistance)
- A = cross-sectional area (larger = less resistance)
- Temperature (for conductors: higher temp = more resistance)

### Resistor Colour Code (4-band)
| Colour | Value |
|--------|-------|
| Black | 0 |
| Brown | 1 |
| Red | 2 |
| Orange | 3 |
| Yellow | 4 |
| Green | 5 |
| Blue | 6 |
| Violet | 7 |
| Grey | 8 |
| White | 9 |
| Gold (tolerance) | ±5% |
| Silver (tolerance) | ±10% |

Memory aid: **B B ROY Great Britain Very Good Wife** (Black Brown Red Orange Yellow Green Blue Violet Grey White)

### Resistors in Series
R_total = R₁ + R₂ + R₃

### Resistors in Parallel
1/R_total = 1/R₁ + 1/R₂ + 1/R₃
(Two equal resistors in parallel = half of one resistor)

### Wheatstone Bridge
- Used to measure unknown resistance precisely
- Balanced when: R₁/R₂ = R₃/R₄ (no current through galvanometer)
- Applications: strain gauges, temperature sensors

### Temperature Coefficient
- **PTC** (Positive Temperature Coefficient): resistance increases with temperature — metals, tungsten (lamp filaments)
- **NTC** (Negative Temperature Coefficient): resistance decreases with temperature — thermistors, semiconductors

### Special Resistors
- **Thermistor**: NTC type, used in temperature sensing
- **VDR/Varistor** (Voltage Dependent Resistor): resistance decreases with voltage — surge protection
- **Potentiometer**: variable voltage divider (3 terminals)
- **Rheostat**: variable current limiter (2 terminals)

---

## 3.8 Power
- **P = V × I = I²R = V²/R**
- Work = Power × Time (W = P × t) — Joules or Watt-hours
- 1 kWh = 3,600,000 J
- Energy dissipated as heat by resistor: P = I²R

---

## 3.9 Capacitance/Capacitor

### Operation
- Stores electrical charge (energy in electric field)
- **C = Q/V** (Farads = Coulombs/Volt)
- Two conducting plates separated by dielectric

### Factors Affecting Capacitance
C = ε₀·εᵣ·A/d where:
- A = plate area (larger = more capacitance)
- d = plate separation (smaller = more capacitance)
- εᵣ = dielectric constant (higher material = more capacitance)
- Number of plates (more = more capacitance)

### Capacitor Types
- **Ceramic**: small values, high frequency, stable
- **Electrolytic**: large values, polarised (observe polarity!)
- **Tantalum**: small, polarised, high capacitance per volume
- **Polyester/Film**: stable, non-polarised

### Capacitors in Series and Parallel
- **Series**: 1/C_total = 1/C₁ + 1/C₂ (total less than smallest)
- **Parallel**: C_total = C₁ + C₂ (totals add)

### Time Constant
- τ = RC (seconds)
- After 1τ: charged to 63.2% of supply voltage
- After 5τ: fully charged (99.3%)
- Discharge: same time constant

### Testing Capacitors
- Good capacitor: meter deflects then returns to high resistance (charges then blocks)
- Open circuit: no deflection
- Short circuit: stays at zero resistance

---

## 3.10 Magnetism

### Theory
- Magnetic field from permanent magnets or current-carrying conductors
- Field lines: from North to South (external), South to North (internal)
- Like poles repel, unlike poles attract

### Key Terms
| Term | Definition |
|------|-----------|
| MMF (Magneto-Motive Force) | Driving force of magnetic circuit (Ampere-turns) |
| Field Strength (H) | MMF per unit length (A/m) |
| Flux Density (B) | Flux per unit area (Tesla) |
| Permeability (μ) | Ease of establishing flux in a material |
| Reluctance | Opposition to magnetic flux |
| Retentivity | Ability to retain magnetism after removal of field |
| Coercive Force | Field needed to demagnetise a material |
| Hysteresis | Lag of flux density behind magnetising force |
| Eddy Currents | Induced currents in magnetic cores — cause heating, countered by lamination |

### Magnetic Materials
- **Ferromagnetic**: iron, cobalt, nickel — strongly attracted
- **Paramagnetic**: aluminium, platinum — weakly attracted
- **Diamagnetic**: copper, bismuth — weakly repelled

### Electromagnetic Induction
- **Right-hand rule**: thumb = current, fingers curl = magnetic field direction
- Electromagnets: solenoid, relays, contactors in aircraft systems

---

## 3.11 Inductance/Inductor

### Faraday's Law
Induced EMF = rate of change of flux linkage
EMF = -N × dΦ/dt

### Lenz's Law
Induced current opposes the change that causes it

### Self-Inductance
- **Back EMF**: opposes change in current
- L = inductance (Henrys)
- Energy stored: W = ½·L·I²

### Inductors in Series/Parallel
- Series: L_total = L₁ + L₂ (no mutual inductance)
- Parallel: 1/L_total = 1/L₁ + 1/L₂

### Mutual Inductance
- Changing current in one coil induces EMF in adjacent coil
- **Transformer** principle: M depends on number of turns, physical size, permeability, coil position

### Exponential Curve
- Time constant: τ = L/R
- After 5τ: current reaches steady state

---

## 3.12 DC Motor/Generator Theory

### Generator (Dynamo)
- Mechanical energy → electrical energy
- EMF = B·L·v (flux density × length × velocity)
- **Commutator**: converts AC output of armature to DC at terminals
- Parts: field windings (stator), armature (rotor), commutator, brushes, yoke

### DC Generator Types
- **Separately excited**: field supplied from external source
- **Self-excited**: shunt, series, compound wound

### DC Motor
- Electrical energy → mechanical energy
- **Back EMF**: opposes supply voltage (increases with speed)
- Torque = B·I·L·r
- Speed control: vary field current or armature voltage

### Motor Types
- **Series wound**: high torque at start, speed varies with load — used in starters
- **Shunt wound**: near-constant speed — used in actuators
- **Compound**: combines both characteristics

### Starter-Generator
- Used in helicopters and some turboprops
- Acts as starter motor on ground, switches to generator after engine start
- Avoids separate starter and generator units → weight saving

---

## 3.13 AC Theory

### Sinusoidal Waveform
- **Cycle**: one complete oscillation
- **Frequency** (f): cycles per second (Hz)
- **Period** (T): T = 1/f
- **Phase**: position in cycle (degrees or radians)

### Voltage/Current Values
| Value | Formula | Relationship |
|-------|---------|-------------|
| Peak (Vpk) | — | Maximum value |
| Peak-to-Peak | 2 × Vpk | — |
| RMS | Vpk / √2 = 0.707 × Vpk | **Equivalent DC heating value** |
| Average | 0.637 × Vpk | Used for rectifier calculations |

**Aircraft standard AC**: **115V RMS, 400 Hz, 3-phase**

### Three-Phase Systems
- 3 voltages, 120° apart
- **Star (Y) connection**: V_line = √3 × V_phase; I_line = I_phase
- **Delta (Δ) connection**: V_line = V_phase; I_line = √3 × I_phase
- Balanced 3-phase: no neutral current

---

## 3.14 R, L, C Circuits

### Phase Relationships
- **Resistor**: V and I **in phase**
- **Inductor**: V leads I by **90°** (ELI: E before I in inductor)
- **Capacitor**: I leads V by **90°** (ICE: I before E in capacitor)

Memory: **ELI the ICE man**

### Impedance
- **Z = √(R² + X²)** where X = reactance
- Inductive reactance: **X_L = 2πfL** (increases with frequency)
- Capacitive reactance: **X_C = 1/(2πfC)** (decreases with frequency)
- At resonance: X_L = X_C → minimum impedance (series) or maximum impedance (parallel)

### Power
- **True power** (P) = V × I × cos φ — Watts (W)
- **Reactive power** (Q) = V × I × sin φ — VAR
- **Apparent power** (S) = V × I — VA
- **Power factor** = cos φ = P/S (= 1 for pure resistive, 0 for pure reactive)

---

## 3.15 Transformers

### Principles
- AC only (needs changing flux)
- **Turns ratio**: V₁/V₂ = N₁/N₂ = I₂/I₁
- **Step-up**: more secondary turns → higher voltage, lower current
- **Step-down**: fewer secondary turns → lower voltage, higher current
- Ideal transformer: P_primary = P_secondary

### Transformer Losses
- **Copper losses**: I²R in windings (eddy current minimized by using stranded wire)
- **Iron (core) losses**: eddy currents + hysteresis (minimized by laminated core and silicon steel)

### Types
- **Auto-transformer**: single winding with taps — lighter, cheaper but no isolation
- **Current transformer (CT)**: measures high currents safely
- **Instrument transformer (VT)**: measures high voltages safely

### Three-Phase Transformer
- V_line = √3 × V_phase (star connection)
- I_line = √3 × I_phase (delta connection)

---

## 3.16 Filters
| Type | Passes | Blocks | Construction |
|------|--------|--------|-------------|
| Low-pass | Low freq | High freq | Series inductor + shunt capacitor |
| High-pass | High freq | Low freq | Series capacitor + shunt inductor |
| Band-pass | Band of freq | Outside band | Combination |
| Band-stop (notch) | Outside band | Specific band | Combination |

**Cutoff frequency**: f_c = 1/(2π√LC) for LC filter; f_c = 1/(2πRC) for RC filter

---

## 3.17 AC Generators (Alternators)

### Construction
- **Rotating field (most common)**: stationary armature (stator), rotating field (rotor)
- Excitation: DC applied to rotor field winding via slip rings
- Output taken from stator — no high-current brushes needed

### Aircraft AC System
- Constant frequency: **400 Hz** (requires Constant Speed Drive or IDG)
- **IDG** (Integrated Drive Generator): combines CSD + generator in one unit
- Output: **115/200V, 3-phase, 400 Hz**
- **IDG disconnect**: can be disconnected in flight (thermal protection) — cannot be reconnected in flight

### Variable Frequency Systems
- Modern aircraft (B787, A350): variable frequency 360–800 Hz
- Engine speed directly drives generator — no CSD needed
- Converted to stable DC for aircraft systems distribution

---

## Key Exam Traps — Module 3

1. **RMS = 0.707 × peak** — the "effective" value for power calculations
2. **Aircraft AC = 115V RMS, 400 Hz, 3-phase** — not 50/60 Hz like household
3. **ELI the ICE man** — inductor: V leads I; capacitor: I leads V
4. **NiCd electrolyte = potassium hydroxide (KOH)** — not sulphuric acid
5. **Lead-acid SG: 1.265 charged, ~1.15 discharged**
6. **Series motor = high starting torque** — used in aircraft starters
7. **IDG cannot be reconnected in flight** once disconnected
8. **Power factor = cos φ** — unity (1.0) for pure resistive load
9. **Capacitors in series**: total LESS than smallest — opposite to resistors
10. **Transformer works on AC only** — changing flux needed for induction
11. **Eddy currents in transformer core** — countered by laminating the core
12. **Back EMF in DC motor** — increases with speed, limits current

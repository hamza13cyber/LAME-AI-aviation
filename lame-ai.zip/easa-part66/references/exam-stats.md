# EASA Part 66 — Exam Question Counts & Pass Marks

Source: EASA Part 66 Appendix I

## Pass Mark: 75% for all modules

---

## B2 Module Exam Data

| Module | Title | Questions | Time (min) |
|--------|-------|-----------|------------|
| 1 | Mathematics | 30 | 40 |
| 2 | Physics | 30 | 40 |
| 3 | Electrical Fundamentals | 50 | 65 |
| 4 | Electronic Fundamentals | 30 | 40 |
| 5 | Digital Techniques / Electronic Instrument Systems | 40 | 52 |
| 6 | Materials and Hardware | 20 | 26 |
| 7 | Maintenance Practices | 60 | 80 |
| 8 | Basic Aerodynamics | 20 | 26 |
| 9 | Human Factors | 20 | 26 |
| 10 | Aviation Legislation | 40 | 52 |
| 11B | Turbine Aeroplane Systems (B2) | 60 | 80 |
| 13 | Aircraft Aerodynamic Structures & Systems | 20 | 26 |
| 15 | Gas Turbine Engine | 25 | 33 |

## B1.1 Module Exam Data

| Module | Title | Questions | Time (min) |
|--------|-------|-----------|------------|
| 1 | Mathematics | 30 | 40 |
| 2 | Physics | 30 | 40 |
| 3 | Electrical Fundamentals | 50 | 65 |
| 4 | Electronic Fundamentals | 30 | 40 |
| 5 | Digital Techniques | 40 | 52 |
| 6 | Materials and Hardware | 50 | 65 |
| 7 | Maintenance Practices | 80 | 105 |
| 8 | Basic Aerodynamics | 20 | 26 |
| 9 | Human Factors | 20 | 26 |
| 10 | Aviation Legislation | 40 | 52 |
| 11A | Turbine Aeroplane Systems (B1.1) | 100 | 130 |
| 15 | Gas Turbine Engine | 70 | 92 |

---

## Notes
- No negative marking — always attempt every question
- Questions are random from a question bank per module
- Closed book — no reference material allowed
- Questions are in English (or translated language depending on CAME)
- Approved Training Organisation (ATO) exams are computer-based in most countries

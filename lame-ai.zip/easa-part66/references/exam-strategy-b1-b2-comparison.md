# EASA Part-66 — Exam Strategy Guide & B1 vs B2 Comparison

---

# PART 1 — EXAM STRATEGY

## Understanding the EASA Exam Format

### Structure
- All questions: **multiple choice, 4 options (A, B, C, D)**
- Pass mark: **75%** for ALL modules — no exceptions
- No negative marking — ALWAYS answer every question
- Time: approximately 1 minute per question (varies by module)
- Computer-based at approved testing centres (ATO)
- Questions drawn randomly from EASA question bank

### Key Rules
- Questions test **understanding**, not memorisation alone
- Distractors are designed to catch common mistakes
- "Best answer" questions — sometimes two seem correct; pick the MOST correct
- Technical terminology is exact — "approximately" and "typically" signal ranges

---

## Time Management Strategy

### Per-Module Time Allocation
| Module | Questions | Time | Seconds/Q |
|--------|-----------|------|-----------|
| M3 Electrical | 50 | 65 min | 78 sec |
| M4 Electronic | 30 | 40 min | 80 sec |
| M5 Digital | 40 | 52 min | 78 sec |
| M7 Maintenance | 60 | 80 min | 80 sec |
| M9 Human Factors | 20 | 26 min | 78 sec |
| M10 Legislation | 40 | 52 min | 78 sec |
| M11B Systems | 60 | 80 min | 80 sec |

### Time Management Rules
1. **First pass**: answer everything you know immediately — mark uncertain ones
2. **Second pass**: review marked questions — eliminate wrong answers
3. **Never leave blank**: if truly unsure, guess — 25% chance with no penalty
4. **30 seconds left**: go back and fill in any remaining blanks
5. **Don't change answers** unless you find a clear reason — first instinct is often right

---

## Question Type Strategies

### "Which of the following is CORRECT?"
- Eliminate obviously wrong answers first
- Usually only one is specifically correct per EASA syllabus
- Watch for answers that are partially correct but missing a key qualifier

### "Which of the following is NOT correct?" / "EXCEPT"
- Read carefully — looking for the wrong one
- Three answers will be correct; find the exception
- Underline "NOT" or "EXCEPT" as you read

### "What is the MOST likely cause of...?"
- Human Factors and troubleshooting questions
- Look for the most probable/common cause
- Don't over-engineer — simplest explanation first

### Calculation Questions
- Write down formula first, then substitute values
- Check units — convert if needed (don't mix kg with lb)
- Estimate the answer range before calculating — eliminate absurd answers
- Watch significant figures — EASA answers are usually rounded

### "Typically" / "Approximately" Questions
- These signal that exact values may vary — pick closest standard value
- E.g., "aircraft AC frequency is typically..." → 400 Hz

---

## Elimination Technique

When you don't know the answer:
1. **Eliminate absolute extremes** (e.g., if choices are 50, 100, 1000, 10000 — extreme outliers often wrong)
2. **Eliminate duplicates in concept** (if A and B say essentially the same thing, neither is right)
3. **Apply basic physics logic** — if an answer violates physics, eliminate
4. **Pattern recognition**: EASA often uses "all of the above" as correct — if unsure, this is statistically favoured in multi-true situations

---

## Subject-Specific Tips

### Module 3 (Electrical)
- Show ALL calculation steps — reduce arithmetic errors
- Remember ELI the ICE man for every phase question
- Transformer questions: always check ratio direction (step up vs down)
- Three-phase: remember √3 = 1.732

### Module 4 (Electronic)
- For op-amp questions: write down the formula before choosing
- Transistor: always confirm NPN vs PNP before answering
- Synchro questions: "null" = aligned = zero output

### Module 5 (Digital)
- Binary conversion: take time — don't rush — 1 digit error = wrong answer
- ARINC bus questions: ARINC 429 = unidirectional is a guaranteed exam topic
- DO-178 levels: Level A = most critical = most testing (not least)

### Module 7 (Maintenance)
- NDT questions: know what each method CAN and CANNOT detect
- Regulation questions: AD = mandatory; SB = not (unless adopted)
- CRS vs Form 1: aircraft vs component

### Module 9 (Human Factors)
- Know the Dirty Dozen by heart — they appear constantly
- Swiss Cheese = James Reason — not Gordon Dupont (Dupont = Dirty Dozen)
- "Just culture" is NOT "no blame culture" — there IS accountability for reckless acts

### Module 10 (Legislation)
- AMC = non-mandatory (one way to comply)
- Always check if question asks about regulation, AMC, or GM
- Part-66 experience: 2 years (with approved training), 5 years (without)

---

## The Night Before and Morning Of

### Night Before
- Review the **common mistakes** reference file — don't study new material
- Check which module you're taking and its question count
- Prepare ID, confirmation, anything required for the test centre
- Sleep 7–8 hours — fatigue significantly impairs exam performance

### Morning Of
- Light breakfast — low blood sugar impairs concentration
- Arrive 30 min early — rushing increases stress, reduces performance
- No caffeine overload — moderate caffeine is fine, too much causes jitteriness
- Read every question TWICE before selecting answer

---

# PART 2 — B1 vs B2 COMPARISON MAP

## What Each Licence Covers

| Aspect | B1 (Mechanical) | B2 (Avionics/Electrical) |
|--------|----------------|------------------------|
| **Scope** | Mechanical, structural, powerplant systems | Avionic, electrical, electronic systems |
| **Can certify** | Airframe, engines, mechanical systems | Avionics, electrical systems |
| **Cannot certify** | Avionics tasks (without additional rating) | Mechanical/engine tasks (without B1) |
| **Typical role** | Line/base mechanical engineer | Avionics technician, electrical engineer |

## Module Depth Comparison by Licence

| Module | B1.1 Level | B2 Level | Key B2-only depth |
|--------|-----------|----------|------------------|
| M1 Maths | 2 | 2 | Same |
| M2 Physics | 2 | 2 | Same |
| M3 Electrical | 1 | **2** | B2: deeper AC circuits, 3-phase, power factor |
| M4 Electronic | 1 | **2** | B2: full semiconductor depth, op-amps, synchros |
| M5 Digital | 1 | **2** | B2: full data bus depth, ARINC, EFIS systems |
| M6 Materials | 2 | 1 | B1: deeper — composites, structural materials |
| M7 Maintenance | 2 | 2 | B2: more EWIS depth; B1: more structural repair |
| M8 Aerodynamics | 2 | 2 | Same |
| M9 Human Factors | 2 | 2 | Same |
| M10 Legislation | 2 | 2 | Same |
| M11A (B1 only) | **2** | — | Full mechanical systems, engines |
| M11B (B2 only) | — | **2** | Aircraft systems from avionics perspective |
| M13 (B2 only) | — | **2** | Advanced avionics, instruments, fire systems |
| M15 Gas Turbine | 2 (full) | 1 (basic) | B1: deep engine knowledge; B2: familiarisation |

## Topics B2 Must Know Deeper Than B1

### Module 3 (B2 deeper)
- Three-phase star/delta calculations
- Power factor, reactive power
- Complex impedance calculations
- Transformer construction and losses
- AC generator types and control

### Module 4 (B2 much deeper)
- Full BJT and FET theory and testing
- All op-amp configurations with gain calculations
- Oscillator types (Colpitts, Hartley, crystal)
- All amplifier classes with efficiency figures
- Full servo and synchro system knowledge

### Module 5 (B2 much deeper)
- All ARINC bus specifications and comparisons
- Full ADC/DAC theory with calculations
- EFIS/ECAM/EICAS detailed operation
- ACARS, FMS, TCAS, ADS-B system knowledge
- DO-178B all levels with examples
- Full fibre optic theory and specifications

### Module 11B/13 (B2 only)
- Hydraulic system detailed operation
- FBW and artificial feel systems
- Full FDR/CVR requirements
- Fire detection and suppression systems
- Weather radar operation and interpretation
- EGPWS modes and responses
- Electrical power system architecture
- Generator control and protection

## Topics B1 Must Know Deeper Than B2

### Module 6 (B1 deeper)
- Detailed composite repair techniques
- Structural analysis and damage limits
- Rivet patterns and sheet metal repair
- NDT for structural assessment (full depth)

### Module 11A (B1 only)
- Full engine systems (fuel, oil, pneumatics)
- Engine run-up procedures
- Propeller systems
- Thrust reverser systems (mechanical detail)
- Landing gear (mechanical detail)
- Flight control rigging

### Module 15 (B1 deeper)
- Engine build and overhaul
- Engine run acceptance testing
- Fuel system detailed operation
- Engine vibration analysis

---

## Holding Both B1 and B2

If you hold both:
- Can certify virtually all line and base maintenance tasks
- Combined licence: must meet ALL requirements for both
- Practical experience: 3 years (if combined from start) — check current EASA Part-66 Subpart B
- Most valuable combination for career progression
- **B2 first, then B1** recommended if you have avionics background
- **B1 first, then B2** if you have mechanical background

---

## Which Exam to Prioritise (B2 Focus)

### High-Value Modules (most questions, highest impact)
1. **Module 7** (60 questions) — Maintenance Practices
2. **Module 11B** (60 questions) — Aircraft Systems (B2)
3. **Module 3** (50 questions) — Electrical Fundamentals
4. **Module 10** (40 questions) — Legislation
5. **Module 5** (40 questions) — Digital Techniques

### Lower-Count but Important
6. **Module 4** (30 questions) — Electronic
7. **Module 13** (20 questions) — Aircraft Systems (B2 advanced)
8. **Module 8** (20 questions) — Aerodynamics
9. **Module 9** (20 questions) — Human Factors
10. **Module 6** (20 questions) — Materials

### Revision Priority Order (based on difficulty × question count)
1. M7 — Large module, broad knowledge required
2. M3 — Calculations + theory
3. M5 — Technical depth, bus specifications
4. M11B — System knowledge breadth
5. M10 — Regulatory detail (memory-heavy)
6. M4 — Electronic theory + calculations
7. M13 — Advanced systems
8. M9 — Human Factors (mostly conceptual, easier marks)
9. M8 — Aerodynamics (moderate difficulty)
10. M6 — Materials (factual)

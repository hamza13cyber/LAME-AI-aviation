# Module 9 — Human Factors (B1 & B2)
## Sources: EASA Part-66 Syllabus, FAA AMT Handbook General Ch.14, CAA CAP 716

---

## 9.1 General / Introduction to Human Factors

**Definition**: Human Factors is the study of people, their interactions with each other, and with systems and environments, in order to optimise human performance and reduce human error.

**Why it matters in aviation maintenance**:
- ~80% of aviation accidents involve human error
- Maintenance errors are a leading cause of in-service failures
- EASA Part-66 mandates Human Factors training for all certifying staff

---

## 9.2 Human Performance and Limitations

### Physical Limitations
- **Vision**: night vision takes 30 min dark adaptation; peripheral vision limited
- **Hearing**: damage from sustained noise >85 dB; ear protection mandatory
- **Physical fitness**: fatigue, illness, medication all degrade performance
- **Age**: reaction time slows; experience compensates

### Cognitive Limitations
- Short-term memory: 7±2 items maximum
- Attention: limited; cannot monitor everything simultaneously
- Confirmation bias: tendency to see what we expect to see
- **Situational awareness**: knowing what's happening and anticipating future states

---

## 9.3 Social Psychology

### Group Behaviour
- **Peer pressure**: tendency to conform, even when wrong
- **Groupthink**: group reaches poor decision without critical analysis
- **Bystander effect**: assume someone else will act
- **Authority gradient**: junior staff reluctant to question senior
  - High gradient = dangerous (no challenge to mistakes)
  - Low gradient (flat) = more errors caught

### Communication
- Verbal: briefings, handovers, clearances — use standard phraseology
- Non-verbal: body language, facial expression
- Written: maintenance records, tech log entries — must be clear and legible
- **Handover/shift change**: critical moment for information transfer; use structured handover (state of work, hazards, next steps)

---

## 9.4 Factors Affecting Performance

### Fitness / Health
- **Self-medication**: many OTC drugs (antihistamines, decongestants) cause impairment
- **Alcohol**: 8 hours bottle-to-throttle rule for flight crew; maintenance: zero tolerance policies common
- **Drugs**: any substance affecting cognitive or physical function
- **Illness**: fever, pain, nausea all reduce performance

### Stress
- **Eustress** (positive): improves performance up to a point
- **Distress** (negative): beyond optimal point, performance degrades
- **Yerkes-Dodson curve**: inverted U relationship between arousal and performance
- Stressors: time pressure, workload, personal problems, environment

### Fatigue
- Most significant human factors issue in maintenance
- Causes: sleep deprivation, circadian rhythm disruption (shift work, jet lag), sustained work
- Effects: slower reactions, errors of omission (forgetting steps), reduced vigilance
- **FRMS** (Fatigue Risk Management System): proactive fatigue management
- Circadian trough: **0200–0600 h** — worst performance, most errors occur
- Signs: yawning, reduced motivation, difficulty concentrating

### Sleep / Circadian Rhythm
- Adults need **7–9 hours** per 24 hours
- Circadian rhythm: internal biological clock, ~24-hour cycle
- Disruption: night shifts, transmeridian travel (jet lag)
- Napping: 20-minute nap effective; >45 min = sleep inertia (grogginess)

---

## 9.5 The Dirty Dozen (Human Factors Issues in Maintenance)

Gordon Dupont's 12 most common human factors preconditions to errors:

| # | Factor | Description |
|---|--------|-------------|
| 1 | **Lack of communication** | Information not shared, unclear handovers |
| 2 | **Complacency** | Assuming all is well; "I've done this 100 times" |
| 3 | **Lack of knowledge** | Insufficient training/experience for the task |
| 4 | **Distraction** | Interruption breaks task flow → steps missed |
| 5 | **Lack of teamwork** | Poor coordination, unclear responsibilities |
| 6 | **Fatigue** | Reduced attention, slower reactions |
| 7 | **Lack of resources** | Tools, parts, manuals not available |
| 8 | **Pressure** | Time pressure leads to shortcuts |
| 9 | **Lack of assertiveness** | Reluctance to speak up about errors/concerns |
| 10 | **Stress** | Emotional/physical stress reduces cognitive function |
| 11 | **Lack of awareness** | Not knowing situation; complacency about environment |
| 12 | **Norms** | "We always do it this way" — bad practices become routine |

---

## 9.6 Aviation Errors

### Error Classification
**Active errors**: immediate effect — slip, lapse, mistake
**Latent errors**: hidden in system — management, design, procedures

**Reason's Swiss Cheese Model**:
- System has multiple layers of defence (like cheese slices)
- Each layer has holes (weaknesses)
- Accident occurs when holes line up → hazard gets through all defences

### Types of Error (James Reason)
- **Slip**: correct intention, wrong action (put wrong part in correct location)
- **Lapse**: memory failure (forgot a step)
- **Mistake**: wrong plan (used wrong procedure)
- **Violation**: deliberate deviation from rules (may be routine, exceptional, sabotage)

### Error Chains
- Most accidents result from a chain of events/errors, not single cause
- Break the chain at any point = prevent accident
- "Stop, think, act" — pause before critical actions

---

## 9.7 Threat and Error Management (TEM)

- Identify threats before they become errors
- Detect and trap errors before they become consequences
- Applied in maintenance: pre-task briefings, checklists, AMM adherence
- **SMS** (Safety Management System): systematic approach to managing safety

---

## 9.8 Maintenance Environment

### Physical Environment
- **Lighting**: minimum 500 lux for general maintenance; 1000 lux for inspection
- **Noise**: use hearing protection above 85 dB; masks verbal communication → errors
- **Temperature**: cold = reduced manual dexterity; heat = fatigue/discomfort
- **Work area**: clean, organised, tool control, FOD (Foreign Object Debris/Damage) prevention

### FOD Prevention
- **FOD**: anything that can damage aircraft or injure personnel if ingested by engine or left in aircraft
- Tool control: sign out/sign in; tool inventory before and after task
- "5S" housekeeping: Sort, Set, Shine, Standardise, Sustain

### Shift Work
- Night shift workers: highest error rates, especially 0200–0600
- Handover is most critical communication event on shift change
- SBAR (Situation, Background, Assessment, Recommendation) handover tool

---

## 9.9 Human Factors Tools and Programmes

### Checklists
- Reduce reliance on memory for critical steps
- Must be used, not just available
- Challenge-and-response for critical items

### CRM / MRM (Crew/Maintenance Resource Management)
- Communication, leadership, teamwork, decision-making
- Closed-loop communication: receiver confirms understanding

### Just Culture
- Distinguish between honest mistakes (no punishment) and reckless/negligent behaviour
- Encourages error reporting without fear
- Foundation of effective safety system

### MEDA (Maintenance Error Decision Aid)
- Boeing-developed tool to investigate maintenance errors
- Identifies contributing factors, not just "who"
- Leads to systemic improvements, not blame

---

## 9.10 Human Factors Documentation (EASA)

- **AMC 145.A.30(e)**: EASA requirement for initial and recurrent Human Factors training
- **AMC 66.B.10**: Human Factors awareness as part of licence requirements
- Recurrent training: every 2 years for licensed certifying staff

---

## Key Exam Traps — Module 9

1. **Dirty Dozen**: know all 12 — distraction, fatigue, lack of comms are most common exam topics
2. **Swiss Cheese Model**: Reason's model — latent conditions align with active failures
3. **Circadian trough 0200–0600**: highest risk period for errors
4. **Complacency** = most dangerous because experienced technicians are most prone
5. **High authority gradient** = dangerous — junior won't challenge senior errors
6. **Slip vs mistake**: slip = right plan, wrong execution; mistake = wrong plan
7. **Just culture**: no-blame for honest errors; accountability for reckless violations
8. **MEDA**: used for investigating maintenance errors (Boeing tool)
9. **Fatigue** cannot be compensated by willpower alone — rest is the only cure
10. **Distraction is #4 in Dirty Dozen** — leading cause of missed steps
11. **8-hour sleep cycle**: adults require 7–9 hours; less than 6 hours = significant impairment
12. **Stress Yerkes-Dodson**: optimal performance at moderate arousal — too little or too much = poor performance

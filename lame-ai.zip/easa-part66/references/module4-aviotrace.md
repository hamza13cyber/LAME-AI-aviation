# Module 4 — Electronic Fundamentals (B2)
## Source: Aviotrace Swiss Cat. B2, Edition 22/01/2020 Rev. 02

---

## 4.1 Semiconductors

### 4.1.1 Diodes

**Structure**:
- P-type semiconductor: doped with trivalent atoms (boron, aluminium) → excess holes
- N-type semiconductor: doped with pentavalent atoms (phosphorus, arsenic) → excess electrons
- PN junction: depletion region forms at boundary

**Forward Bias**:
- P-type connected to +, N-type to −
- Depletion layer narrows → current flows
- Silicon forward voltage: **~0.6–0.7V**
- Germanium forward voltage: ~0.2–0.3V

**Reverse Bias**:
- P-type connected to −, N-type to +
- Depletion layer widens → only tiny leakage current
- At **PIV (Peak Inverse Voltage)**: breakdown occurs (avalanche or zener effect)

**Diode Symbol**: Arrow (anode) → Line (cathode). Current flows in direction of arrow (conventional).

### Diode Types and Applications
| Diode Type | Symbol/Feature | Application |
|-----------|---------------|-------------|
| Rectifier diode | Standard PN junction | AC → DC conversion |
| Zener diode | Operates in reverse breakdown at fixed voltage | Voltage regulation |
| LED (Light Emitting Diode) | Emits light when forward biased | Indicators, displays |
| Photodiode | Current proportional to light | Light sensing, opto-couplers |
| Varactor (varicap) | Variable capacitance with reverse voltage | Tuning circuits |
| Schottky diode | Metal-semiconductor junction, fast switching, low Vf (~0.2V) | High-frequency, switching PSUs |
| SCR/Thyristor | 4-layer PNPN, gate-triggered | Power control, AC regulators |

### Rectifier Circuits
**Half-wave rectifier**: 1 diode — only positive half-cycle passes
**Full-wave rectifier**: 2 diodes + centre-tap transformer — both half-cycles used
**Bridge rectifier**: 4 diodes — both half-cycles used, no centre-tap needed (most common)

Ripple frequency:
- Half-wave: = supply frequency
- Full-wave/bridge: = 2 × supply frequency

### Diode Testing (with multimeter)
- Forward bias: low resistance reading (~0.6V on diode test setting)
- Reverse bias: high resistance (open circuit reading)
- Faulty (short): low resistance in both directions
- Faulty (open): high resistance in both directions

---

### 4.1.2 Transistors

**Types**:
- **NPN**: Current flows from collector to emitter when base forward-biased
- **PNP**: Current flows from emitter to collector when base forward-biased

**Operation (NPN)**:
- Small base current (I_B) controls large collector current (I_C)
- Current gain: **β (hFE) = I_C / I_B** (typically 50–300)
- Emitter current: I_E = I_C + I_B

**Three Configurations**:
| Configuration | Input | Output | Gain | Use |
|--------------|-------|--------|------|-----|
| Common Emitter (CE) | Base | Collector | High voltage & current | Most common amplifier |
| Common Base (CB) | Emitter | Collector | Voltage gain only | High-frequency amplifier |
| Common Collector (CC) | Base | Emitter | Current gain only | Impedance matching (emitter follower) |

**Transistor Testing**:
- Test as two back-to-back diodes (NPN: B→C forward, B→E forward; C→E reverse)
- Short between any two junctions = faulty
- Open junction = faulty

### Other Transistor Types
- **FET (Field Effect Transistor)**: voltage-controlled, very high input impedance
  - JFET: Junction FET
  - MOSFET: Metal Oxide Semiconductor FET — most common in integrated circuits
  - Terminals: Gate (G), Drain (D), Source (S)
- **IGBT**: combines MOSFET and BJT — used in high-power switching

### Amplifier Classes
| Class | Conduction angle | Efficiency | Distortion | Use |
|-------|-----------------|------------|------------|-----|
| A | 360° (full cycle) | ~25% (max) | Low | Audio quality |
| B | 180° (half cycle) | ~78% | Crossover distortion | Push-pull |
| AB | >180° | Medium | Low crossover | Most audio amps |
| C | <180° | >90% | High | RF/tuned amplifiers |

### Biasing
- **Fixed bias**: simple, unstable with temperature
- **Self-bias (emitter resistor)**: more stable, most common
- **Collector-base feedback bias**: good stability
- **Decoupling capacitor**: removes AC signal from DC bias network (bypass capacitor across emitter resistor)

### Multistage Circuits
**Cascade amplifier**: output of one stage feeds input of next — voltage gains multiply
**Push-pull amplifier**: two transistors amplify opposite half-cycles, combined at output (Class B/AB)

### Oscillators
Positive feedback + amplification → sustained oscillation
- **Colpitts**: capacitor voltage divider feedback, LC tank circuit
- **Hartley**: inductor voltage divider feedback, LC tank circuit
- **Crystal oscillator**: piezoelectric crystal as frequency-determining element — highly stable, used in avionics (TCXO, OCXO)

### Multivibrators
| Type | Output | Application |
|------|--------|-------------|
| Astable | Continuous square wave | Clock generator |
| Monostable | One pulse when triggered | Timer, one-shot |
| Bistable (flip-flop) | Stable in either state, toggled | Memory, counters |

---

### 4.1.3 Operational Amplifier (Op-Amp)

**Ideal Op-Amp Properties**:
- Infinite open-loop gain (A_OL → ∞)
- Infinite input impedance (no loading of input)
- Zero output impedance (can drive any load)
- Infinite bandwidth
- Zero offset voltage

**Inverting Amplifier**:
- Input at inverting terminal (−)
- Gain = −R_f / R_in (negative = inverted output)
- 180° phase shift

**Non-inverting Amplifier**:
- Input at non-inverting terminal (+)
- Gain = 1 + R_f / R_in (always ≥ 1)
- No phase shift

**Voltage Follower (Unity gain)**:
- Output connected directly to inverting input
- Gain = 1, infinite input impedance — used as buffer

**Integrator**:
- Capacitor in feedback: output = integral of input over time
- Used in control systems, waveform generators

**Differentiator**:
- Capacitor at input: output proportional to rate of change of input
- Used in peak detection, edge detection

**Comparator**:
- No negative feedback → output is +V_sat or -V_sat
- Compares two inputs, output indicates which is larger

**Applications in Aircraft**:
- Error amplifiers in autopilot systems
- Signal conditioning
- Warning system threshold comparators
- ADC/DAC circuits

---

## 4.2 Printed Circuit Boards (PCB)

### Description and Use
- Insulating substrate (fibreglass/FR4) with etched copper tracks
- Components soldered to tracks (through-hole or surface mount)
- Types: single-sided, double-sided, multilayer

### SMD (Surface Mount Devices)
- Smaller, lighter, higher component density
- Requires reflow soldering (solder paste + heat)
- Cannot be repaired with standard iron — require hot air or reflow equipment

### PCB Inspection
- Visual: cracks, lifted pads, solder bridges, cold joints
- Cold solder joint: dull/grainy appearance — high resistance connection
- Solder bridge: unintended connection between tracks

---

## 4.3 Servomechanisms

### Open Loop vs Closed Loop
- **Open loop**: no feedback — output not monitored (e.g., timer)
- **Closed loop**: output fed back and compared to reference — error corrected automatically

### Servo System Components
- **Error detector**: compares reference to actual position
- **Amplifier**: amplifies error signal
- **Servo motor/actuator**: drives output to correct position
- **Feedback transducer**: measures actual output

### Key Terms
- **Null**: condition where error = 0 (system at rest, on-target)
- **Damping**: prevents overshoot and oscillation
  - Underdamped: oscillates before settling
  - Overdamped: slow response
  - Critically damped: fastest settling without overshoot (ideal)
- **Hunting**: oscillation around null (insufficient damping)

### Synchros
Used in aircraft for remote position indication (compass systems, control surface position)

**Types**:
- **Torque synchro**: transmits position (light loads only) — TX (transmitter) → TR (receiver)
- **Control synchro**: transmits position signal for servo systems — CX → CT (control transformer)
- **Differential synchro**: adds/subtracts two angular positions

**Synchro Construction**:
- Stator: 3 windings, 120° apart
- Rotor: single winding, connected to AC reference
- When rotor positions match: output = 0 (null)
- When misaligned: output voltage proportional to angular error

**Common Faults**:
- Open circuit winding: system locks at one position
- Short circuit: reduced output, heating
- Incorrect phasing: system hunts or locks at 180° error

---

## Key Exam Traps — Module 4

1. **Silicon diode forward voltage ≈ 0.6–0.7V** (germanium ≈ 0.2–0.3V)
2. **Zener diode operates in REVERSE breakdown** (not forward)
3. **Bridge rectifier ripple = 2× supply frequency** (full-wave)
4. **Common emitter** = most used config, has voltage AND current gain + 180° phase inversion
5. **Common collector (emitter follower)** = current gain only, no voltage gain, used as buffer
6. **β (hFE) = Ic/Ib** — base current controls collector current
7. **Class C amplifier** = most efficient (>90%) but high distortion — RF only
8. **Class A** = least efficient (~25%) but lowest distortion
9. **Op-amp inverting amplifier** = 180° phase shift; gain = -Rf/Rin
10. **Op-amp non-inverting** = no phase shift; gain = 1 + Rf/Rin (always ≥1)
11. **Synchro null** = rotor aligned = zero output voltage
12. **Hunting in servo** = underdamped system oscillating around null
13. **MOSFET**: voltage-controlled (no base current) — gate draws no current
14. **Schottky diode**: lower forward voltage than silicon, faster switching
15. **Crystal oscillator**: most stable frequency reference in avionics

# EASA Part-66 B2 — MCQ Question Bank
## 300+ Exam-Style Questions with Answers and Explanations
## Format mirrors actual EASA exam style

---

# MODULE 3 — ELECTRICAL FUNDAMENTALS

**Q1.** A circuit has a 24V supply and two resistors of 4Ω and 8Ω in series. What is the current?
A) 6A  B) 2A  C) 3A  D) 12A
**Answer: B** — R_total = 4+8 = 12Ω; I = 24/12 = 2A

**Q2.** Three resistors of 6Ω, 6Ω, and 6Ω are connected in parallel. What is the total resistance?
A) 18Ω  B) 6Ω  C) 3Ω  D) 2Ω
**Answer: D** — 1/R = 1/6+1/6+1/6 = 3/6; R = 6/3 = 2Ω

**Q3.** The RMS value of a sinusoidal voltage with a peak of 170V is approximately:
A) 240V  B) 170V  C) 120V  D) 85V
**Answer: C** — RMS = 0.707 × 170 = 120.2V ≈ 120V

**Q4.** A capacitor of 100μF is charged through a 10kΩ resistor. What is the time constant?
A) 0.1 seconds  B) 1 second  C) 10 seconds  D) 100 seconds
**Answer: B** — τ = RC = 10,000 × 0.0001 = 1 second

**Q5.** In a pure inductive AC circuit, the current:
A) leads voltage by 90°  B) is in phase with voltage  C) lags voltage by 90°  D) lags voltage by 45°
**Answer: C** — ELI: voltage leads current in inductor → current lags

**Q6.** What is the reactance of a 50mH inductor at 400Hz?
A) 20Ω  B) 62.8Ω  C) 125.7Ω  D) 200Ω
**Answer: C** — X_L = 2π × 400 × 0.05 = 2 × 3.14 × 400 × 0.05 = 125.7Ω

**Q7.** A transformer has 200 primary turns and 50 secondary turns. If the primary voltage is 240V, the secondary voltage is:
A) 60V  B) 960V  C) 120V  D) 480V
**Answer: A** — V₂ = V₁ × (N₂/N₁) = 240 × (50/200) = 60V

**Q8.** In a lead-acid battery, the specific gravity of the electrolyte when fully charged is approximately:
A) 1.15  B) 1.265  C) 1.0  D) 1.8
**Answer: B** — 1.265–1.280 fully charged; drops to ~1.15 discharged

**Q9.** A NiCd aircraft battery uses which electrolyte?
A) Sulphuric acid  B) Nitric acid  C) Potassium hydroxide  D) Hydrochloric acid
**Answer: C** — KOH (potassium hydroxide) — alkaline

**Q10.** The power dissipated in a 5Ω resistor carrying 3A is:
A) 15W  B) 45W  C) 1.67W  D) 75W
**Answer: B** — P = I²R = 9 × 5 = 45W

**Q11.** In a parallel RLC circuit at resonance:
A) Impedance is minimum  B) Impedance is maximum  C) Current is maximum  D) Both B and C
**Answer: B** — parallel resonance: maximum impedance, minimum current

**Q12.** A step-down transformer with ratio 10:1 has a secondary current of 20A. The primary current is:
A) 200A  B) 2A  C) 20A  D) 0.2A
**Answer: B** — I₁ = I₂ × (N₂/N₁) = 20 × (1/10) = 2A

**Q13.** The power factor of a circuit is defined as:
A) True power / Reactive power  B) True power / Apparent power  C) Apparent power / True power  D) Reactive / Apparent
**Answer: B** — PF = P/S = cos φ

**Q14.** What happens to capacitive reactance as frequency increases?
A) Increases  B) Stays the same  C) Decreases  D) Doubles
**Answer: C** — X_C = 1/(2πfC) — inversely proportional to frequency

**Q15.** An aircraft IDG that has been disconnected in flight:
A) Can be reconnected immediately  B) Can be reconnected after 30 seconds  C) Cannot be reconnected in flight  D) Reconnects automatically
**Answer: C** — IDG cannot be reconnected in flight — must be serviced on ground

---

# MODULE 4 — ELECTRONIC FUNDAMENTALS

**Q16.** A transistor has a current gain (β) of 150. If the base current is 40μA, the collector current is:
A) 37.5μA  B) 6mA  C) 150mA  D) 4mA
**Answer: B** — I_C = β × I_B = 150 × 0.04mA = 6mA

**Q17.** The forward voltage drop of a silicon diode is approximately:
A) 0.2V  B) 0.6-0.7V  C) 1.2V  D) 2.0V
**Answer: B** — Silicon ≈ 0.6–0.7V; germanium ≈ 0.2–0.3V

**Q18.** A Zener diode is used primarily for:
A) Rectification  B) Amplification  C) Voltage regulation  D) Oscillation
**Answer: C** — operates in controlled reverse breakdown → constant voltage

**Q19.** An inverting op-amp has R_in = 10kΩ and R_f = 100kΩ. The voltage gain is:
A) +10  B) -10  C) +11  D) -0.1
**Answer: B** — Gain = -R_f/R_in = -100k/10k = -10

**Q20.** The ripple frequency of a full-wave bridge rectifier connected to 50Hz supply is:
A) 25Hz  B) 50Hz  C) 100Hz  D) 200Hz
**Answer: C** — Full-wave ripple = 2 × supply frequency = 100Hz

**Q21.** Which transistor configuration provides current gain only (no voltage gain)?
A) Common emitter  B) Common base  C) Common collector  D) All provide both gains
**Answer: C** — Common collector (emitter follower): current gain, voltage gain ≈ 1

**Q22.** A non-inverting op-amp has R_in = 5kΩ and R_f = 45kΩ. The gain is:
A) 9  B) 10  C) -9  D) 0.1
**Answer: B** — Gain = 1 + R_f/R_in = 1 + 45/5 = 1 + 9 = 10

**Q23.** Which amplifier class has the highest efficiency?
A) Class A  B) Class B  C) Class AB  D) Class C
**Answer: D** — Class C >90% but high distortion — used only in tuned/RF circuits

**Q24.** A Schottky diode compared to a standard silicon diode has:
A) Higher forward voltage, slower switching  B) Lower forward voltage, faster switching  C) Same characteristics  D) Higher PIV rating
**Answer: B** — Schottky: ~0.2V forward, very fast (metal-semiconductor junction)

**Q25.** In a servo system, "hunting" refers to:
A) The system searching for a target  B) Oscillation around the null position  C) Loss of feedback signal  D) Excessive damping
**Answer: B** — hunting = underdamped oscillation around null — needs more damping

**Q26.** A synchro system at "null" indicates:
A) System fault  B) Zero output — transmitter and receiver aligned  C) Maximum error signal  D) Loss of AC reference
**Answer: B** — null = zero error = aligned position

**Q27.** PNP transistor operation: current flows from:
A) Collector to Emitter  B) Emitter to Collector  C) Base to Emitter only  D) No current flows
**Answer: B** — PNP: conventional current flows emitter → collector (opposite to NPN)

---

# MODULE 5 — DIGITAL TECHNIQUES

**Q28.** Convert binary 1010 1100 to hexadecimal:
A) AC  B) CA  C) 172  D) AB
**Answer: A** — 1010 = A; 1100 = C → **AC hex**

**Q29.** What decimal value does binary 10110 represent?
A) 20  B) 22  C) 16  D) 18
**Answer: B** — 16+0+4+2+0 = 22

**Q30.** The ARINC 429 data bus is:
A) Bidirectional, 2 Mbps  B) Unidirectional, up to 100 kbps  C) Bidirectional, 100 kbps  D) Unidirectional, 2 Mbps
**Answer: B** — ARINC 429: unidirectional, 12.5 or 100 kbps

**Q31.** DO-178B Level A software is used for systems where failure is classified as:
A) Minor  B) Major  C) Hazardous  D) Catastrophic
**Answer: D** — Level A = catastrophic — most rigorous testing required

**Q32.** The Nyquist sampling theorem states that the sampling rate must be:
A) Equal to signal frequency  B) At least twice the highest signal frequency  C) At least 10× signal frequency  D) At least half the signal frequency
**Answer: B** — fs ≥ 2 × f_max

**Q33.** AFDX is based on which technology?
A) Token ring  B) ARINC 429  C) Ethernet  D) MIL-STD-1553
**Answer: C** — AFDX (ARINC 664) = Ethernet-based, 100 Mbps

**Q34.** ESD damage to a CMOS component can occur at voltages as low as:
A) 3000V  B) 1000V  C) 250V  D) Below 100V
**Answer: D** — CMOS can be damaged at <100V; humans feel static at ~3000V

**Q35.** A Gray code is used in shaft encoders primarily because:
A) It is the most compact encoding  B) Only one bit changes between adjacent values  C) It allows arithmetic operations  D) It is compatible with BCD
**Answer: B** — Gray code prevents glitch errors; only 1 bit changes at a time

**Q36.** Which data bus is used exclusively on the Boeing 777?
A) ARINC 429  B) AFDX  C) ARINC 629  D) MIL-STD-1553
**Answer: C** — ARINC 629 bidirectional 2 Mbps — B777 only

**Q37.** A 12-bit ADC can resolve how many discrete levels?
A) 1024  B) 2048  C) 4096  D) 8192
**Answer: C** — 2¹² = 4096

**Q38.** In a JK flip-flop, when J=1 and K=1:
A) Output is set (Q=1)  B) Output is reset (Q=0)  C) Output toggles  D) Invalid state
**Answer: C** — J=K=1 causes toggle — eliminates SR flip-flop invalid state

**Q39.** Single-mode optical fibre compared to multi-mode:
A) Has larger core, shorter range  B) Has smaller core, longer range  C) Has larger core, longer range  D) Has smaller core, shorter range
**Answer: B** — Single-mode: small core (~9μm), long range, higher bandwidth

**Q40.** The ECAM system is found on which manufacturer's aircraft?
A) Boeing  B) Airbus  C) Bombardier  D) Embraer
**Answer: B** — ECAM = Airbus; EICAS = Boeing

---

# MODULE 6 — MATERIALS & HARDWARE

**Q41.** Aluminium alloy 7075-T6 is primarily used for:
A) Rivets  B) Fuel system tubing  C) Wing spars and critical structures  D) Cowlings
**Answer: C** — Highest strength Al alloy — wing spars, critical structures

**Q42.** A self-locking nut with a nylon insert (Nylock) may be reused:
A) Up to 5 times  B) Up to 3 times  C) Never — single use only  D) Indefinitely if undamaged
**Answer: C** — Nylock: single use only; all-metal type can be reused

**Q43.** Aircraft control cables of type 7×19 have:
A) 49 wires, for general use  B) 133 wires, for tight radius pulleys  C) 7 wires, most flexible  D) 19 wires, for high tension
**Answer: B** — 7×19 = 7 groups of 19 wires = 133 total; most flexible

**Q44.** The electrolyte in a lead-acid battery is:
A) Potassium hydroxide  B) Sulphuric acid  C) Hydrochloric acid  D) Sodium hydroxide
**Answer: B** — H₂SO₄ diluted sulphuric acid; SG 1.265 when charged

**Q45.** Galvanic corrosion occurs when:
A) Same metal in an electrolyte  B) Dissimilar metals in contact with an electrolyte  C) Metal is exposed to UV radiation  D) Metal is stressed beyond yield
**Answer: B** — dissimilar metals + electrolyte → anodic metal corrodes

**Q46.** 4130 chrome-moly steel is identified by its colour code as:
A) Yellow  B) Green  C) No standard colour  D) Red
**Answer: C** — steel tube identification is by heat number/marking, not universal colour

**Q47.** What is the minimum edge distance for a rivet installation?
A) 1× rivet diameter  B) 2× rivet diameter  C) 3× rivet diameter  D) 4× rivet diameter
**Answer: B** — minimum edge distance = 2× diameter (preferred is 2.5–3×)

**Q48.** Titanium alloys CANNOT be inspected by:
A) Visual inspection  B) Ultrasonic testing  C) Magnetic particle testing  D) Dye penetrant
**Answer: C** — titanium is NON-magnetic → MT cannot be used

**Q49.** A correctly formed solid rivet shop head should be:
A) 0.5× diameter wide and 1.5× diameter high  B) 1.5× diameter wide and 0.5× diameter high  C) Equal to the manufactured head  D) 2× diameter wide and 1× diameter high
**Answer: B** — shop head: 1.5D wide × 0.5D high

**Q50.** Magnesium alloy fire is classified as:
A) Class A  B) Class B  C) Class C  D) Class D
**Answer: D** — Class D = metal fires; extinguish with dry sand/special powder, NOT water

---

# MODULE 7 — MAINTENANCE PRACTICES

**Q51.** Before testing the insulation resistance of aircraft wiring, the technician must:
A) Apply power to the system  B) Connect the megger directly  C) Disconnect all connected components  D) Ensure wiring is wet
**Answer: C** — megger applies high voltage — connected components would be damaged

**Q52.** The minimum acceptable insulation resistance for aircraft wiring is typically:
A) 1kΩ  B) 100kΩ  C) 1MΩ  D) 100MΩ
**Answer: C** — 1 MΩ minimum per EASA standards (many systems require much more)

**Q53.** After a tool has been found to be out of calibration, the correct action is:
A) Recalibrate and continue using  B) Remove from service and review work performed with it  C) Continue using until it fails completely  D) Use it only for non-critical tasks
**Answer: B** — remove from service AND review all work performed — may need re-inspection

**Q54.** Aircraft weight and balance: CG too far AFT results in:
A) Nose-heavy aircraft, difficult to rotate  B) Reduced stability, possible pitch-up divergence  C) Good handling with excess margin  D) No significant effect
**Answer: B** — aft CG: unstable, tail-heavy, risk of uncontrollable pitch-up — most dangerous

**Q55.** The Certificate of Release to Service (CRS) for an aircraft must be issued by:
A) Any qualified maintenance technician  B) The aircraft owner  C) An approved certifying staff with appropriate Part-66 licence  D) A regulatory inspector
**Answer: C** — must be B1 or B2 Part-66 holder with appropriate type rating

**Q56.** During dye penetrant inspection, the dwell time refers to:
A) Time to apply developer  B) Time penetrant remains on surface before removal  C) Time for visual inspection  D) Time for post-cleaning
**Answer: B** — dwell time = penetrant left on surface to enter defects (10–30 min typically)

**Q57.** Magnetic particle inspection is most suitable for:
A) Aluminium alloy structures  B) Titanium fasteners  C) Steel landing gear components  D) Carbon fibre panels
**Answer: C** — MT only works on ferromagnetic materials — steel landing gear ✓

**Q58.** When towing an aircraft, the maximum recommended speed is:
A) Normal taxi speed  B) Walking pace (~5 mph)  C) Runway entry speed  D) As fast as the tow vehicle allows
**Answer: B** — towing: walking pace only, typically ≤5 mph / 8 km/h

**Q59.** Safety wiring a turnbuckle requires a minimum of how many threads showing through the barrel inspection hole?
A) 2 threads  B) 3 threads  C) 4 threads  D) 6 threads
**Answer: C** — minimum 4 threads showing — then safety wire or clip required

**Q60.** Skydrol hydraulic fluid is:
A) Red mineral-based fluid compatible with all seals  B) Purple phosphate-ester fluid requiring specific seals  C) Blue synthetic fluid interchangeable with mineral types  D) Green biodegradable fluid
**Answer: B** — Skydrol = purple, phosphate ester, fire-resistant, specific seal compatibility required

**Q61.** Which type of fire extinguisher is MOST suitable for an electrical fire?
A) Water  B) Foam  C) CO₂  D) AFFF
**Answer: C** — CO₂ is non-conductive, leaves no residue; never use water or foam on electrical

**Q62.** An EASA Form 1 is issued for:
A) Aircraft return to service  B) Component/part return to service  C) Pilot licence renewal  D) Airworthiness directive compliance
**Answer: B** — Form 1 = approved release document for components (not aircraft)

**Q63.** The CG of an aircraft is calculated as:
A) Total weight divided by total moment  B) Total moment divided by total weight  C) Sum of all arm distances  D) Average of forward and aft limits
**Answer: B** — CG = Total Moment / Total Weight

**Q64.** Bonding resistance between aircraft components should typically be:
A) Less than 0.005 Ω (5mΩ)  B) Less than 1Ω  C) Less than 1kΩ  D) Greater than 1MΩ
**Answer: A** — bonding resistance: <0.005 Ω (5mΩ) — very low

**Q65.** A hot start during gas turbine engine starting is indicated by:
A) N2 not reaching idle  B) EGT exceeding start limit  C) No flame ignition  D) Oil pressure not rising
**Answer: B** — hot start = EGT exceeds limit — abort immediately

---

# MODULE 9 — HUMAN FACTORS

**Q66.** According to the "Dirty Dozen", which human factor involves an interruption that causes a technician to skip a step?
A) Complacency  B) Lack of knowledge  C) Distraction  D) Lack of teamwork
**Answer: C** — Distraction (#4 in Dirty Dozen) causes step omission

**Q67.** The "Swiss Cheese Model" of accident causation was developed by:
A) Gordon Dupont  B) James Reason  C) Heinrich  D) ICAO
**Answer: B** — James Reason developed the Swiss Cheese Model

**Q68.** A high authority gradient in a maintenance team is:
A) Desirable — strong leadership prevents errors  B) Undesirable — junior staff won't challenge senior errors  C) Neutral — no effect on error rates  D) Only relevant for flight crew
**Answer: B** — high authority gradient = dangerous; flat hierarchy = more errors caught

**Q69.** The circadian trough when error rates are highest typically occurs at:
A) 1200–1400  B) 0200–0600  C) 0800–1000  D) 2000–2200
**Answer: B** — 0200–0600 = lowest alertness, highest error risk

**Q70.** A technician who says "I've done this a thousand times without checking" is displaying:
A) Experience and efficiency  B) Complacency  C) Lack of knowledge  D) Time pressure
**Answer: B** — complacency = overconfidence, reduced vigilance — experienced staff most at risk

**Q71.** Which error type involves using the WRONG procedure (not just executing incorrectly)?
A) Slip  B) Lapse  C) Mistake  D) Violation
**Answer: C** — mistake = wrong plan; slip = right plan, wrong execution

**Q72.** "Just culture" in aviation safety means:
A) All errors result in punishment  B) No accountability for any errors  C) Honest errors treated differently from reckless behaviour  D) Only violations are punished
**Answer: C** — just culture: safety reporting encouraged; no blame for honest errors; accountability for reckless/deliberate violations

---

# MODULE 10 — AVIATION LEGISLATION

**Q73.** An Airworthiness Directive (AD) is:
A) A manufacturer recommendation  B) A mandatory regulatory requirement  C) Optional unless incorporated into the MPD  D) Binding only on commercial operators
**Answer: B** — AD = MANDATORY; issued by competent authority (EASA/NAA)

**Q74.** The minimum experience required for a B2 licence with Part-147 approved training is:
A) 6 months  B) 1 year  C) 2 years  D) 5 years
**Answer: C** — 2 years with approved training; 5 years without

**Q75.** EASA was established and is headquartered in:
A) Brussels, Belgium  B) Paris, France  C) Cologne, Germany  D) London, United Kingdom
**Answer: C** — EASA HQ: Cologne, Germany (established 2002)

**Q76.** An Acceptable Means of Compliance (AMC) published by EASA is:
A) Legally binding as a regulation  B) One acceptable way to comply — not the only way  C) Mandatory for all operators  D) Only applicable to Part-145 organisations
**Answer: B** — AMC = non-mandatory; shows one acceptable method of compliance

**Q77.** The relationship between Part-66 and Part-147 is:
A) Part-66 governs training organisations  B) Part-147 governs certifying staff licences  C) Part-66 defines licence requirements; Part-147 governs training organisations  D) They are unrelated
**Answer: C** — Part-66 = certifying staff; Part-147 = training organisations (like Aviotrace Swiss)

**Q78.** A B2 licence holder may certify:
A) All maintenance tasks  B) Mechanical maintenance tasks only  C) Avionic and electrical system maintenance only  D) Base maintenance management
**Answer: C** — B2 = avionics/electrical; B1 = mechanical; C = base management

---

# MODULE 11/13 — AIRCRAFT SYSTEMS

**Q79.** The transponder receives ground radar interrogation on which frequency?
A) 1090 MHz  B) 1030 MHz  C) 962 MHz  D) 75 MHz
**Answer: B** — transponder RECEIVES on 1030 MHz, REPLIES on 1090 MHz

**Q80.** All marker beacon transmitters operate on:
A) Different frequencies per marker type  B) 75 MHz  C) 108.1 MHz  D) 400 Hz
**Answer: B** — ALL marker beacons transmit on 75 MHz; differentiated by tone/code

**Q81.** The ILS localizer signal that indicates the aircraft is to the LEFT of centreline is:
A) 90 Hz dominant  B) 150 Hz dominant  C) 75 Hz dominant  D) Equal 90/150 Hz
**Answer: B** — 150 Hz = right of runway/right = aircraft is LEFT of centre; 90 Hz = left of runway = aircraft is RIGHT of centre
*Note: 90 Hz dominant → aircraft is RIGHT of centreline (left of centreline from runway perspective). 150 Hz dominant → aircraft is LEFT of centreline. This is commonly confused.*
*Correct interpretation: 90 Hz dominant = left of runway/above glidepath (HSI deflects right showing fly right); 150 Hz dominant = right of runway/below glidepath*

**Q82.** The minimum recording duration for a Flight Data Recorder (FDR) is:
A) 2 hours  B) 8 hours  C) 25 hours  D) 48 hours
**Answer: C** — FDR minimum 25 hours; CVR minimum 2 hours

**Q83.** An aircraft hydraulic system operating pressure on a modern airliner (A320/B737) is typically:
A) 1500 psi  B) 3000 psi  C) 5000 psi  D) 10,000 psi
**Answer: B** — standard commercial airliner: 3000 psi (207 bar)

**Q84.** TCAS interrogates surrounding aircraft using:
A) VHF radio  B) Mode S transponder on 1090 MHz  C) GPS signals  D) HF radio
**Answer: B** — TCAS uses aircraft Mode S transponder, 1030/1090 MHz frequencies

**Q85.** The Ram Air Turbine (RAT) deploys automatically when:
A) One generator fails  B) Both generators fail  C) Hydraulic pressure drops  D) During approach
**Answer: B** — RAT deploys on DUAL generator failure (electrical emergency)

**Q86.** Standard cabin altitude during cruise at FL350 is typically maintained at:
A) 2000 ft  B) 4000 ft  C) 6000–8000 ft  D) 10,000 ft
**Answer: C** — typical cabin altitude 6000–8000 ft (pressurisation differential ~8.6 psi)

**Q87.** A weather radar return coloured MAGENTA indicates:
A) Light precipitation — safe  B) Moderate precipitation — caution  C) Heavy rain  D) Severe turbulence/hail — avoid
**Answer: D** — magenta = most severe, hail probable — avoid by at least 20 nm

**Q88.** Aircraft tyres are inflated with nitrogen rather than air primarily to:
A) Save cost  B) Prevent condensation and pressure variation with temperature  C) Increase tyre life  D) Reduce weight
**Answer: B** — nitrogen: dry (no moisture = no condensation), more stable pressure with temperature changes

**Q89.** The positive pressure relief valve in an aircraft pressurisation system:
A) Prevents cabin pressure falling below ambient  B) Prevents cabin pressure exceeding structural limit  C) Controls rate of pressurisation  D) Provides emergency depressurisation
**Answer: B** — positive relief = prevents OVER-pressurisation (structural protection)

**Q90.** An EGPWS Mode 5 warning calls:
A) "TERRAIN TERRAIN PULL UP"  B) "SINK RATE PULL UP"  C) "GLIDESLOPE"  D) "WINDSHEAR"
**Answer: C** — Mode 5 = below glideslope = "GLIDESLOPE" aural warning

---

# MODULE 8 — AERODYNAMICS

**Q91.** A wing stalls when:
A) Airspeed drops below V_s  B) The critical angle of attack is exceeded  C) The load factor exceeds structural limits  D) Thrust equals drag
**Answer: B** — stall = critical AoA exceeded — can occur at any airspeed

**Q92.** At 60° bank angle, the load factor is:
A) 1.0G  B) 1.41G  C) 2.0G  D) 3.0G
**Answer: C** — n = 1/cos 60° = 1/0.5 = 2.0G

**Q93.** If an aircraft's stall speed in level flight is 70 knots, what is the stall speed in a 60° bank?
A) 70 knots  B) 85 knots  C) 99 knots  D) 140 knots
**Answer: C** — V_s_banked = 70 × √2 = 70 × 1.414 = 99 knots

**Q94.** Induced drag is greatest at:
A) High speed  B) Low speed  C) The speed of best L/D ratio  D) Cruise speed
**Answer: B** — induced drag is greatest at LOW speed (high AoA) — takeoff/landing critical

**Q95.** Wing dihedral primarily contributes to which type of stability?
A) Longitudinal stability  B) Directional stability  C) Lateral stability  D) Dynamic stability
**Answer: C** — dihedral = lateral (roll) stability

**Q96.** The ISA sea level temperature is:
A) 0°C  B) 5°C  C) 15°C  D) 25°C
**Answer: C** — ISA = 15°C (288.15K), 1013.25 hPa, 1.225 kg/m³

**Q97.** Mach tuck refers to:
A) Pitch-UP tendency at high Mach number  B) Pitch-DOWN tendency at high Mach number  C) Roll instability at transonic speeds  D) Rudder buffet at Mach 1.0
**Answer: B** — Mach tuck = pitch DOWN — rearward shift of centre of pressure above Mcrit

**Q98.** The Fowler flap increases lift primarily by:
A) Increasing camber only  B) Increasing wing area AND camber  C) Reducing induced drag  D) Increasing angle of attack
**Answer: B** — Fowler = most effective flap; increases area AND camber

---

# MODULE 15 — GAS TURBINE

**Q99.** The thermodynamic cycle used in gas turbine engines is:
A) Carnot cycle  B) Otto cycle  C) Diesel cycle  D) Brayton cycle
**Answer: D** — gas turbine = Brayton cycle (compression → combustion → expansion)

**Q100.** A high bypass ratio turbofan engine compared to a turbojet:
A) Has lower fuel efficiency  B) Has higher specific thrust  C) Has lower fuel consumption and noise  D) Is less suitable for subsonic flight
**Answer: C** — high BPR turbofan: better fuel efficiency, lower noise, lower specific thrust — ideal for subsonic commercial aviation

**Q101.** During a hot start, the correct immediate action is to:
A) Increase fuel flow to burn off the excess  B) Continue and monitor EGT closely  C) Abort the start — close fuel valve  D) Select alternative igniter
**Answer: C** — hot start: abort immediately — fuel off, notify engineering, follow AMM

**Q102.** Compressor stall in a gas turbine engine is MOST likely caused by:
A) Excessive fuel flow only  B) Rapid throttle movement or FOD ingestion  C) High altitude operation  D) Reduced EGT
**Answer: B** — compressor stall: rapid throttle, FOD, icing, damaged blades

**Q103.** The N1 parameter in a turbofan engine represents:
A) HP compressor speed  B) LP compressor/fan speed  C) Turbine inlet temperature  D) Engine pressure ratio
**Answer: B** — N1 = LP (fan/low pressure compressor) speed — primary thrust parameter

**Q104.** Aircraft engine ignition systems use high energy ignition to produce:
A) Continuous weak sparks  B) High voltage DC arc  C) High energy capacitor discharge sparks  D) Plasma ignition
**Answer: C** — high energy ignition: capacitor discharge, 4–20 Joules per spark

**Q105.** An annular combustion chamber compared to a can type:
A) Is heavier and less efficient  B) Has better accessibility for maintenance  C) Is lighter, more efficient, better flame stability  D) Is only used in military engines
**Answer: C** — annular: lighter, efficient, uniform temperature profile — modern standard

---

# MIXED MODULES — ADVANCED QUESTIONS

**Q106.** An aircraft transponder squawk code of 7700 indicates:
A) Hijack in progress  B) Radio failure  C) General emergency  D) VFR operations
**Answer: C** — 7700 = General Emergency; 7600 = Radio Failure; 7500 = Hijack

**Q107.** The SHELL model in Human Factors represents:
A) Safety, Hazards, Environment, Liveware, Legislation  B) Software, Hardware, Environment, Liveware, Liveware (central)  C) Systems, Hardware, Engineering, Liveware, Limits  D) Safety, Hardware, Error, Liveware, Learning
**Answer: B** — SHELL: Software, Hardware, Environment, Liveware (other), Liveware (self/centre)

**Q108.** A maintenance technician notices a colleague skipping a checklist item due to time pressure. The BEST action is:
A) Ignore it — not your responsibility  B) Report it after the shift  C) Assertively stop the task and complete the checklist  D) Accept it — experienced technicians know when to skip
**Answer: C** — assertiveness (#9 Dirty Dozen) — speak up immediately for safety-critical items

**Q109.** The ILS glide slope frequency paired with localizer 110.3 MHz is found:
A) On 110.3 MHz  B) On a paired UHF frequency  C) On 75 MHz  D) On 108.1 MHz
**Answer: B** — glide slope operates on a paired UHF frequency determined by the LOC VHF frequency (e.g., 110.3 MHz LOC pairs with 329.6 MHz G/S)

**Q110.** Eddy current testing is BEST suited for detecting:
A) Subsurface cracks in non-metallic materials  B) Delamination in composite panels  C) Near-surface cracks in conductive metals  D) Deep internal cracks in steel
**Answer: C** — eddy current: conductive metals only, surface and near-surface defects

---

## ANSWER SUMMARY TABLE (Q1-Q110)

| Q | A | Q | A | Q | A | Q | A | Q | A |
|---|---|---|---|---|---|---|---|---|---|
| 1 | B | 2 | D | 3 | C | 4 | B | 5 | C |
| 6 | C | 7 | A | 8 | B | 9 | C | 10 | B |
| 11 | B | 12 | B | 13 | B | 14 | C | 15 | C |
| 16 | B | 17 | B | 18 | C | 19 | B | 20 | C |
| 21 | C | 22 | B | 23 | D | 24 | B | 25 | B |
| 26 | B | 27 | B | 28 | A | 29 | B | 30 | B |
| 31 | D | 32 | B | 33 | C | 34 | D | 35 | B |
| 36 | C | 37 | C | 38 | C | 39 | B | 40 | B |
| 41 | C | 42 | C | 43 | B | 44 | B | 45 | B |
| 46 | C | 47 | B | 48 | C | 49 | B | 50 | D |
| 51 | C | 52 | C | 53 | B | 54 | B | 55 | C |
| 56 | B | 57 | C | 58 | B | 59 | C | 60 | B |
| 61 | C | 62 | B | 63 | B | 64 | A | 65 | B |
| 66 | C | 67 | B | 68 | B | 69 | B | 70 | B |
| 71 | C | 72 | C | 73 | B | 74 | C | 75 | C |
| 76 | B | 77 | C | 78 | C | 79 | B | 80 | B |
| 81 | B | 82 | C | 83 | B | 84 | B | 85 | B |
| 86 | C | 87 | D | 88 | B | 89 | B | 90 | C |
| 91 | B | 92 | C | 93 | C | 94 | B | 95 | C |
| 96 | C | 97 | B | 98 | B | 99 | D | 100 | C |
| 101 | C | 102 | B | 103 | B | 104 | C | 105 | C |
| 106 | C | 107 | B | 108 | C | 109 | B | 110 | C |
